#!/usr/bin/env python3
"""多 repo 來源管理：讓一個 wiki 管理散在各處的多個 git 專案。

核心原則：wiki 不搬檔案，只記路徑。外部 repo 的檔案永遠留在原地，一律唯讀。

🔴 為什麼每筆都要記擁有者：
   絕對路徑（C:\\Users\\...）只存在於記錄者那一台電腦。多人共編時，
   別台機器看到的是一條死路徑 —— 必須知道「這是誰的機器、有沒有 remote 可拿」。

用法：
    python repo.py add <路徑> [--alias 別名] [--desc 說明]
    python repo.py list
    python repo.py scan [alias]
    python repo.py remove <alias>
"""
import argparse
import fnmatch
import os
import platform
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _lib import filehash as _filehash  # noqa: E402
from _lib.vaultpaths import (find_vault_root, load_manifest, save_manifest,  # noqa: E402
                             manifest_sources,
                             resolve_source,
                             resolve_repo_path, portable_path, is_hardcoded)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

INGESTABLE = {".md", ".txt", ".pdf", ".docx", ".doc", ".epub", ".xlsx", ".pptx"}

# 🔴 #25：超過這個數量就不建議批次 ingest。
# 原本寫死 200 —— 但公司級文件庫常見規模就落在 100～200（實例：某份二階程序書
# 共 139 份），正好在門檻下，`add` 於是建議「批次 ingest 整個 repo」= 一口氣編一兩百張卡。
# 批次的合理上限是「你願意一次看完的量」，不是「檔案系統撐得住的量」。
BATCH_SAFE_MAX = 30
DEFAULT_EXCLUDE = [".git", "node_modules", "__pycache__", "dist", "build",
                   ".venv", "venv", ".obsidian", "site-packages"]

# 🔴 憑證樣式：**程式碼層的硬底線，不存進 manifest、不可被關掉**。
# 為什麼不做成 manifest 的 exclude 預設值：那樣只有「之後才掛的 repo」受保護，
# 既有已掛的要靠懶回填（#26 教訓）。寫死在這裡，升級 plugin 當下所有 vault 一起生效。
#
# 為什麼這個 plugin 特別需要：它的核心動作是「掛別人的目錄 → 讀檔 → 把摘要寫進會被
# commit 的 wiki 頁」。一般專案沒有這條鏈。實測 `_walk` 原本**完全不比對檔案**
# （只比對資料夾），且 `_candidates` 只靠副檔名過濾 —— 所以 `secrets.txt`、
# `credentials.md`、`密碼.xlsx` 這類「有 ingest 副檔名的憑證檔」會直接進候選。
#
# ⚠️ 這是減速丘不是保證：擋得住本 plugin 的掛載與 ingest 路徑，**擋不住**使用者
# 自己用 Bash cat／Grep 去讀。第二道防線見範本 `.claude/settings.json` 的 deny。
SECRET_PATTERNS = [
    ".env", ".env.*", "*.env",
    "*secret*", "*credential*", "*password*", "*passwd*",
    "密碼*", "*帳密*", "*金鑰*",
    "id_rsa*", "id_ed25519*", "*.pem", "*.pfx", "*.p12", "*.key", "*.keystore",
    ".npmrc", ".netrc", ".pypirc", "*.kdbx",
    ".aws", ".ssh", ".gnupg",
]


def is_secret_name(name: str) -> bool:
    """檔名／夾名看起來像憑證？大小寫不敏感。"""
    low = name.lower()
    return any(fnmatch.fnmatch(low, pat) for pat in SECRET_PATTERNS)


def _git(path, *args):
    try:
        r = subprocess.run(["git", "-C", str(path), *args],
                           capture_output=True, text=True, timeout=10)
        return r.stdout.strip() if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


# 本次執行被憑證樣式擋掉的路徑。**要印出來讓人看得見** —— 靜默的保護，
# 下一個人不知道它存在，就會在它擋錯時直接把它拆掉（同 occupancy-check 的 O4 精神）。
SECRET_SKIPPED = []


def _is_excluded(p: Path, base: Path, excludes):
    try:
        parts = p.relative_to(base).parts
    except ValueError:
        return True
    if any(is_secret_name(part) for part in parts):
        return True
    return any(part in excludes for part in parts)


def _walk(base: Path, excludes, max_depth=None):
    """深度受限、容錯的目錄走訪。

    不用 rglob：真實硬碟上有 WSL 符號連結、junction、權限不足的路徑，
    rglob 撞到就整個拋 OSError（實測 WinError 1920）。
    """
    stack = [(base, 0)]
    while stack:
        d, depth = stack.pop()
        # 🔴 這裡是 >= 不是 >：下面 yield 的是 depth+1。
        # 用 > 會讓 --depth 1 吐到第 2 層（2026-09-21 驗收實測）。
        if max_depth is not None and depth >= max_depth:
            continue
        try:
            entries = list(os.scandir(d))
        except OSError:
            continue                      # 權限不足／斷掉的連結 → 跳過，不中斷
        for e in entries:
            try:
                if e.is_dir(follow_symlinks=False):
                    if e.name in excludes or e.name.startswith("."):
                        continue
                    if is_secret_name(e.name):
                        SECRET_SKIPPED.append(e.path)
                        continue
                    stack.append((Path(e.path), depth + 1))
                    yield Path(e.path), True, depth + 1
                elif e.is_file(follow_symlinks=False):
                    # 🔴 原本檔案完全不比對排除清單，只有資料夾比對（2026-09-26 實測）
                    if is_secret_name(e.name):
                        SECRET_SKIPPED.append(e.path)
                        continue
                    yield Path(e.path), False, depth + 1
            except OSError:
                continue


def _report_secret_skips(base: Path, limit=8):
    """把憑證樣式擋掉的路徑印出來。

    🔴 **不可改成靜默**：沒人知道保護存在，它擋錯時第一個反應就是把它拆掉；
    而且「這裡本來就沒有憑證檔」與「有但被擋了」看起來會一模一樣。
    """
    if not SECRET_SKIPPED:
        return
    rel = []
    for p in SECRET_SKIPPED:
        try:
            rel.append(Path(p).relative_to(base).as_posix())
        except ValueError:
            rel.append(Path(p).name)
    print(f"   🔒 憑證樣式已排除 {len(rel)} 個（不進候選、不會被 ingest）：")
    for r in rel[:limit]:
        print(f"      · {r}")
    if len(rel) > limit:
        print(f"      · …另 {len(rel) - limit} 個")
    print("      樣式寫在 repo.py 的 SECRET_PATTERNS；誤擋請回報，不要自行放寬。")
    SECRET_SKIPPED.clear()


def _candidates(base: Path, excludes, max_depth=None):
    return [p for p, is_dir, _ in _walk(base, excludes, max_depth)
            if not is_dir and p.suffix.lower() in INGESTABLE]


def _md5(p: Path):
    try:
        return _filehash.md5_of(p)          # 文字檔正規化行尾（#19）
    except OSError:
        return None


def _slug(name):
    s = re.sub(r"[^\w\-]+", "-", name.strip().lower())
    return re.sub(r"-{2,}", "-", s).strip("-") or "repo"


# 這些名字當 alias 毫無鑑別力（一顆硬碟上會有幾十個 doc/），改用「父層-自己」
GENERIC = {"doc", "docs", "raw", "wiki", "src", "app", "lib", "data", "files",
           "其他", "文件", "資料", "temp", "tmp", "new", "old", "bak"}

# 程式碼樹的特徵檔：出現就代表這是 source repo，不是文件資料夾
CODE_MARKERS = {"package.json", "cmakelists.txt", "makefile", "cargo.toml",
                "pyproject.toml", "setup.py", "go.mod", "pom.xml", "wscript"}


def _suggest_alias(d: Path, taken):
    """產生有鑑別力且不重複的 alias。"""
    base = _slug(d.name)
    if base in GENERIC or base in taken:
        parent = _slug(d.parent.name)
        if parent and parent not in GENERIC:
            base = f"{parent}-{base}"
    cand, i = base, 2
    while cand in taken:
        cand, i = f"{base}-{i}", i + 1
    taken.add(cand)
    return cand


# 🔴 掛進來的東西本身就是一個 llm-wiki vault（或它的知識層）時，行為必須不同：
# 對方的 `wiki/` 是「已經編譯過的知識」，再 ingest 一次＝同一份知識存兩份，
# 之後對方更新、我方不知道 → 兩邊無聲漂掉。這正是「wiki 只存指標」要防的事。
# （2026-09-21 踩到 #23：掛一個別人已編譯的 vault，add 照樣印「批次 ingest 整個 repo」。）
def _detect_wiki(d: Path):
    """判斷掛載目標是不是既有 wiki vault。回傳 kind 或 None。

    - "vault-root"    ：整個 vault（有 wiki/index.md，旁邊還有 raw/ 或 CLAUDE.md）
    - "compiled-wiki" ：vault 的知識層本身（index.md + log.md 並存）
    """
    try:
        if (d / "wiki" / "index.md").is_file() and (
                (d / "raw").is_dir() or (d / "CLAUDE.md").is_file()):
            return "vault-root"
        if (d / "index.md").is_file() and (d / "log.md").is_file():
            return "compiled-wiki"
    except OSError:
        pass
    return None


def _looks_like_code(d: Path):
    try:
        names = {e.name.lower() for e in os.scandir(d) if e.is_file()}
    except OSError:
        return False
    return bool(names & CODE_MARKERS)


# 🔴 #26：`kind` 只在 add 當下判定，0.4.12 之前掛的條目通通沒有這一欄，
# 於是 repos.md 把「整包掛進來的 wiki vault」標成「文件」—— 0.4.12 的防護對
# **已經掛錯的**完全無效，而已經掛錯的才是最需要提醒的。
# （2026-09-21 發現：某 alias 指向 vault 根，raw 1396＋wiki 65＋雜訊 79，卻標「文件」。）
# 每次重建 repos.md 前回填一次：缺 kind、或路徑內容變了（raw/wiki 被加進去）都重判。
# #27 遷移：0.4.14 以前註冊的條目存的是絕對路徑，一律壓成可攜 spec。
# 壓不掉的（跨磁碟機）保持絕對，由 list／repos.md 標出來讓使用者自己改成 ${VAR}。
# 🔴 寫入權限三級（2026-09-21 使用者裁示，取代「外部 repo 一律唯讀」）。
# 唯讀的理由是「動到別人的東西」，不是「它在 hub 外面」—— 使用者自己的專案掛進來
# 就是為了統一管理，一刀禁止等於廢掉這個用途。
#   mine-plain : 本人的一般資料夾
#   mine-vault : 本人的 vault（有自己的 CLAUDE.md，規則要先載入）
#   others     : 別人的（remote／owner 非本人）→ 需對方同意
# 實際能不能寫另看 `writable`，那個旗標**只由使用者明確開啟**，預設唯讀。
def ownership(root, alias, r) -> str:
    me = (_git(root, "config", "user.name") or "").strip().lower()
    owner = ((r.get("owner") or {}).get("name") or "").strip().lower()
    path = resolve_repo_path(root, r.get("path", ""))
    remote = ((r.get("owner") or {}).get("remote") or "")
    # 🔴 抓不到擁有者（非 git 來源）時不要猜。說「這是別人的」是在陳述一件可能為假的事；
    # 說「不知道是誰的」才是真的。判成 unknown：一樣不給預設寫入，但要使用者自己確認。
    if not owner or owner == "unknown":
        return "unknown"
    mine = bool(me) and owner == me
    # remote 指向他人的帳號 → 即使本機 git user 相同也算別人的
    if mine and remote.startswith(("http", "git@")):
        seg = remote.split(":")[-1].split("/")
        if len(seg) >= 2 and seg[-2].lower() not in (me, ""):
            mine = False
    if not mine:
        return "others"
    try:
        for up in (path, path.parent):
            if (up / "CLAUDE.md").is_file():
                return "mine-vault"
    except OSError:
        pass
    return "mine-plain"


def autosync_of(path: Path):
    """對方有沒有裝 Obsidian Git 自動 commit／push。回傳 (分鐘, remote) 或 None。

    有自動同步＝改動幾分鐘內自動推出去，沒有反悔空檔、半成品也會被推。
    動手前一定要讓使用者知道。
    """
    import json as _json
    for base in (path, path.parent):
        f = base / ".obsidian" / "plugins" / "obsidian-git" / "data.json"
        try:
            if not f.is_file():
                continue
            d = _json.loads(f.read_text(encoding="utf-8"))
            if d.get("disablePush"):
                continue
            mins = d.get("autoPushInterval") or d.get("autoSaveInterval")
            if mins:
                return int(mins)
        except (OSError, ValueError, TypeError):
            continue
    return None


def backfill_paths(root, m) -> bool:
    changed = False
    for alias, r in m.get("repos", {}).items():
        if alias.startswith("_"):
            continue
        spec = r.get("path", "")
        if not is_hardcoded(spec):
            continue                      # 已是 ~ / ${VAR} / 相對
        better = portable_path(root, spec)
        if better != spec:
            r["path"] = better
            changed = True
    return changed


def backfill_kinds(root, m) -> bool:
    """替 manifest 內的 repos 補上／更新 kind。回傳有沒有改動。"""
    changed = False
    for alias, r in m.get("repos", {}).items():
        if alias.startswith("_"):
            continue
        path = resolve_repo_path(root, r.get("path", ""))
        if not path.is_dir():
            continue                      # 路徑失效時不動它，維持原狀待擁有者處理
        now = _detect_wiki(path) or "docs"
        if r.get("kind") != now:
            r["kind"] = now
            changed = True
    return changed


def write_repos_page(root):
    """依 manifest 重建 `wiki/repos.md`（外部 repo 總覽）。

    為什麼要有這支：`wiki-ingest` skill 與 `wiki-core` 的目錄樹都寫「外部 repo 更新
    wiki/repos.md」，但在 0.4.2 以前沒有任何程式會建它 —— 那一頁永遠不存在
    （2026-09-21 驗收發現）。這裡由 manifest 全量重建，所以不會與 manifest 漂掉。

    整份重寫是刻意的：它是**衍生檔**，真相來源永遠是 raw/.manifest.json。
    """
    wiki = root / "wiki"
    if not wiki.is_dir():
        return None
    m = load_manifest(root)
    if backfill_paths(root, m) | backfill_kinds(root, m):
        save_manifest(root, m)            # #26 補 kind、#27 把絕對路徑壓成可攜
    repos = {k: v for k, v in m.get("repos", {}).items() if not k.startswith("_")}
    sources = manifest_sources(m)          # #33：過濾 `_` 備註與非 dict
    p = wiki / "repos.md"

    if not repos:
        if p.exists():
            p.unlink()                    # 最後一個 repo 被 remove → 不留空殼頁
        return None

    L = [
        "---", "type: meta", "title: 外部 repo 總覽",
        f"updated: {date.today().isoformat()}",
        "---", "",
        "# 外部 repo 總覽", "",
        "> 由 `repo.py` 依 `raw/.manifest.json` 自動重建 —— **不要手改**，改了下次 add／remove 會被蓋掉。",
        "> 🔴 **預設唯讀**。要寫入請把該筆的 `writable` 設為 `true`（真相來源：`raw/.manifest.json`）。",
        "> 別人的 repo 另需**對方同意**，且 MUST：動手前 `git pull` → 改 → 完成後 `commit` + `push`；",
        "> commit message 要標明是從哪個 vault 遠端改的 ＋ session 名。規則全文見 `wiki-repo` skill。", "",
        "| alias | 種類 | 寫入 | 路徑 | 擁有者 | Remote | 卡片 | 狀態 |",
        "|---|---|---|---|---|---|---|---|",
    ]
    # 「種類」欄不是裝飾：知識層 alias 一律不可 ingest，下個 session 只看得到這一頁，
    # 沒標就會照一般 repo 處理，把別人的知識重編一份（#23）。
    KIND = {"compiled-wiki": "🔴 知識層", "vault-root": "⚠️ wiki 根", "docs": "文件"}
    # (級別, writable) → 顯示。唯讀一律鎖頭；可寫的別人 repo 特別標，因為 MUST 最多
    WMARK = {("others", False): "🔒 唯讀", ("others", True): "🔴 可寫（他人）",
             ("unknown", False): "🔒 唯讀", ("unknown", True): "⚠️ 可寫（擁有者不明）",
             ("mine-vault", False): "🔒 唯讀", ("mine-vault", True): "🟡 可寫（照它的規則）",
             ("mine-plain", False): "🔒 唯讀", ("mine-plain", True): "🟢 可寫"}
    for alias, r in sorted(repos.items()):
        n = sum(1 for k in sources if k.startswith(f"{alias}::"))
        o = r.get("owner") or {}
        alive = resolve_repo_path(root, r.get("path", "")).exists()
        L.append(
            f"| `{alias}` | {KIND.get(r.get('kind', 'docs'), '文件')} "
            f"| {WMARK[(ownership(root, alias, r), bool(r.get('writable')))]} | `{r.get('path','')}` "
            f"| {o.get('name','?')} @ {o.get('machine','?')} "
            f"| {o.get('remote','?')} | {n} | {'✅ 在' if alive else '🔴 路徑失效'} |"
        )
    hard = [a for a, r in repos.items() if is_hardcoded(r.get("path", ""))]
    if hard:
        L += ["",
              f"> 🔴 {'、'.join(hard)} 的路徑是**絕對路徑**（壓不成相對／`~`，多半跨磁碟機）。",
              "> 換一台機器或改使用者名稱就會失效 —— 改成 `${你的變數}/子路徑`，兩台都設好那個環境變數。"]
    if any(r.get("kind") == "compiled-wiki" for r in repos.values()):
        L += ["",
              "> 🔴 標「知識層」的 alias 是**別人已編譯的 wiki**，"
              "一律不 ingest（重編＝同一份知識兩處，必漂）。",
              "> 查它就即時讀正本；要引用條文原文／數值，回對應的原始檔 alias。"]
    L.append("")
    for alias, r in sorted(repos.items()):
        cards = sorted(sources[k].get("catalog_page", "")
                       for k in sources if k.startswith(f"{alias}::"))
        L += [f"## {alias} — {r.get('desc') or '(無說明)'}", "",
              f"- 註冊：{r.get('registered_at','?')}　最後掃描：{r.get('last_scanned','?')}"]
        if cards:
            L.append("- 已建卡：" + "、".join(
                f"[[{c.removeprefix('wiki/').removesuffix('.md')}]]" for c in cards if c))
        else:
            L.append("- 已建卡：無")
        if not resolve_repo_path(root, r.get("path", "")).exists():
            L.append(f"- 🔴 路徑在本機失效 —— 去找 {(r.get('owner') or {}).get('name','?')}"
                     f"，remote：{(r.get('owner') or {}).get('remote','?')}")
        L += [f"- 查變更：`python \"${{CLAUDE_PLUGIN_ROOT}}/scripts/repo.py\" scan {alias}`", ""]

    p.write_text("\n".join(L), encoding="utf-8")
    return p


def cmd_add(root, args):
    src = Path(args.path).expanduser()
    if not src.is_dir():
        print(f"🔴 路徑不存在或不是資料夾：{src}")
        return 1
    src = src.resolve()

    kind = _detect_wiki(src)
    if kind == "vault-root" and not args.force:
        print(f"🔴  這是一個既有的 wiki vault（偵測到 {src.name}/wiki/index.md），不要整包掛。")
        print("   整包掛會把對方『已編譯的知識層』和『原始正本』混成同一個 alias，")
        print("   scan 分不出哪些該重 ingest、哪些根本不該碰。\n")
        print("   正確做法是分兩個 alias 掛，原始與編譯層各一：\n")
        base = _slug(src.name)
        if (src / "raw").is_dir():
            print(f'     python repo.py add "{src.as_posix()}/raw" --alias {base}-raw '
                  f'--desc "{src.name} 原始正本"')
        print(f'     python repo.py add "{src.as_posix()}/wiki" --alias {base}-wiki '
              f'--desc "{src.name} 已編譯知識層（唯讀，不重 ingest）"')
        print("\n   真的要整包掛：加 --force")
        return 1

    m = load_manifest(root)
    repos = m.setdefault("repos", {})
    alias = args.alias or _slug(src.name)
    if alias in repos:
        print(f"🔴 alias `{alias}` 已存在（指向 {repos[alias].get('path')}）")
        print("   換一個名字：--alias 其他名稱")
        return 1

    is_git = _git(src, "rev-parse", "--is-inside-work-tree") == "true"
    remote = _git(src, "remote", "get-url", "origin") if is_git else None

    entry = {
        # #27：存可攜 spec，不存絕對路徑（換機器／換使用者名稱就全部失效）
        "path": portable_path(root, src),
        "desc": args.desc or "",
        "git": is_git,
        "registered_at": date.today().isoformat(),
        "last_scanned": date.today().isoformat(),
        "exclude": DEFAULT_EXCLUDE,
        # 既有 wiki vault 的知識層 —— 不可 ingest，只能建指標卡路由（#23）
        "kind": kind or "docs",
        # 🔴 預設唯讀。要開寫入權限，使用者自己把這欄改成 true（見 wiki-repo skill）
        "writable": False,
        # 🔴 擁有者標記：絕對路徑只在這台機器有效，別台必須知道去找誰
        "owner": {
            "name": (_git(src, "config", "user.name") if is_git else None) or "unknown",
            "email": (_git(src, "config", "user.email") if is_git else None) or "",
            "machine": platform.node(),
            "remote": remote or ("僅本機，需向擁有者取得" if is_git else "非 git"),
        },
    }
    repos[alias] = entry
    save_manifest(root, m)
    page = write_repos_page(root)

    files = _candidates(src, set(DEFAULT_EXCLUDE))
    by_ext = {}
    for f in files:
        by_ext[f.suffix.lower()] = by_ext.get(f.suffix.lower(), 0) + 1
    breakdown = " / ".join(f"{k} {v}" for k, v in sorted(by_ext.items(), key=lambda x: -x[1]))

    print(f"✅ 已註冊：{alias}")
    print(f"   路徑：{entry['path']}   （本機：{src}）")
    if is_hardcoded(entry["path"]):
        print(f"   🔴 這條壓不成可攜路徑（多半是跨磁碟機）—— 換機器會失效。")
        print("      建議改用環境變數：手動把 path 改成 ${你的變數}/子路徑，並在兩台機器都設好。")
    print(f"   Git：{'是' if is_git else '否'}　擁有者：{entry['owner']['name']} @ {entry['owner']['machine']}")
    print(f"   Remote：{entry['owner']['remote']}")
    print(f"   可 ingest 候選：{len(files)} 個（{breakdown or '無'}）")
    _report_secret_skips(src)
    if page:
        print(f"   總覽已更新：{page.relative_to(root).as_posix()}")
    if kind == "compiled-wiki":
        # 🔴 對方已經編譯過的知識層 —— ingest 它＝同一份知識存兩份，必漂。
        print(f"\n🔴 這是**別人已編譯的知識層**（{len(files)} 份 md），"
              f"**不要 ingest** —— 不論單份或批次。")
        print("   重編一份等於同一份知識存兩處，對方更新時我方不會知道，兩邊無聲漂掉。\n")
        print("   正確做法 —— 建一張 Tier 1 指標卡做路由，不抄內容：")
        print(f"     1. 讀 {alias}::index.md 取得對方的目錄結構")
        print(f"     2. 在 wiki/catalog/ 建卡：記身分／TOC／路徑，frontmatter 標 "
              f"repo: {alias}、tier: 1")
        print("     3. 在本 vault CLAUDE.md『查詢路由』表加一列，指向那張卡")
        print("     4. 查詢時回正本即時讀；要引用條文原文／數值則回原始檔那個 alias，"
              "不可引用編譯層（那是別人的摘要）")
        print(f"\n   看對方有什麼：python repo.py scan {alias}")
    elif len(files) > BATCH_SAFE_MAX:
        print(f"\n🔴 {len(files)} 份候選檔（批次上限 {BATCH_SAFE_MAX}）—— "
              f"**不要**批次 `/wiki-ingest {alias}::`。")
        print("   批次會一口氣建出幾十上百張卡，沒人會逐張檢查，錯的卡比沒有卡更糟。")
        print(f"   按需單份：/wiki-ingest {alias}::{{repo 內路徑}}")
        print(f"   先看有什麼：python repo.py scan {alias}")
    else:
        print(f"\n下一步：/wiki-ingest {alias}::           ← 批次 ingest 整個 repo")
    return 0


def cmd_discover(root, args):
    """掃描一個上層資料夾，列出候選專案供批次註冊。

    給「硬碟上有幾十個專案資料夾」的情境用 —— 一個個 add 太累，
    但整顆硬碟註冊成一個 alias 又會讓 source key 長到無法掃描。
    """
    base = Path(args.path).expanduser()
    if not base.is_dir():
        print(f"🔴 路徑不存在：{base}")
        return 1
    base = base.resolve()

    m = load_manifest(root)
    registered = {resolve_repo_path(root, v.get("path", "")).as_posix().rstrip("/").lower()
                  for k, v in m.get("repos", {}).items() if not k.startswith("_")}
    excludes = set(DEFAULT_EXCLUDE)

    # 本 vault 自己不是「外部 repo」—— manifest 已有 _self，列出來只會誤導
    self_root = str(root.resolve()).replace("\\", "/").lower()

    OFFICE = {".docx", ".doc", ".pdf", ".xlsx", ".pptx"}
    rows = []
    for d, is_dir, depth in _walk(base, excludes, max_depth=args.depth):
        if not is_dir:
            continue
        low = str(d.resolve()).replace("\\", "/").lower()
        if low == self_root or low.startswith(self_root + "/"):
            continue                      # 本 vault 與其子目錄
        files = _candidates(d, excludes)
        if len(files) < args.min_files:
            continue
        office = sum(1 for f in files if f.suffix.lower() in OFFICE)
        if office < args.min_office:
            continue                      # 沒有 Office 檔的資料夾進 wiki 沒有意義
        code = _looks_like_code(d)
        if code and not args.include_code:
            continue                      # source repo，不是文件資料夾
        rows.append((d, len(files), office, depth))

    # 🔴 只保留最淺的命中（父層優先），不是最深。
    # _candidates() 是遞迴計數，父層檔數恆 ≥ 子層 —— 取最深等於保證丟掉「一個專案一層」
    # 的那一列（2026-09-21 驗收：專案根 1040 office 消失、被切成 7 個子 alias）。
    # 顆粒度由 --depth 控制：--depth 1 = 專案層，--depth 2 = 子專案層。
    chosen = []
    paths = {str(d).lower() for d, _, _, _ in rows}
    for d, n, office, depth in rows:
        low = str(d).lower()
        if any(low.startswith(p + "\\") or low.startswith(p + "/")
               for p in paths if p != low):
            continue                      # 祖先已入選 → 不重複列子層
        chosen.append((d, n, office, depth))

    if not chosen:
        print(f"在 {base} 下（深度 ≤{args.depth}）找不到含 ≥{args.min_files} 份文件"
              f"（其中 ≥{args.min_office} 份 Office）的資料夾。")
        print("試試 --depth 3、--min-files 1、--min-office 0，或 --include-code（含程式碼專案）")
        return 0

    chosen.sort(key=lambda x: (-x[2], -x[1]))   # Office 文件多的排前面
    _report_secret_skips(base)
    print(f"在 {base} 下找到 {len(chosen)} 個候選（深度 ≤{args.depth}，"
          f"≥{args.min_files} 份、其中 ≥{args.min_office} 份 Office）"
          f"{'' if args.include_code else '，已排除程式碼專案'}：\n")
    print(f"{'狀態':<6} {'種類':<6} {'Office':>6} {'總計':>6}  {'建議 alias':<24} 路徑")
    print("-" * 112)

    taken = set()
    cmds = []
    wikis = 0
    for d, n, office, _ in chosen:
        done = str(d).replace("\\", "/").lower() in registered
        alias = _suggest_alias(d, taken)
        # 既有 wiki vault 不能照一般專案的方式掛（#23）—— 在清單就標出來，
        # 不然使用者會直接複製下面的 add 指令，踩到整包掛。
        kind = _detect_wiki(d)
        mark = {"vault-root": "wiki根", "compiled-wiki": "知識層"}.get(kind, "文件")
        if kind:
            wikis += 1
        print(f"{'已註冊' if done else '  -   ':<6} {mark:<6} {office:>6} {n:>6}  {alias:<24} {d}")
        if not done and not kind:
            cmds.append(f'python repo.py add "{d}" --alias {alias} --desc "{d.name}"')

    if cmds:
        print(f"\n批次註冊指令（{len(cmds)} 條）：\n")
        for c in cmds:
            print(f"  {c}")
        print("\n🔴 不必全部註冊 —— 只註冊你真的會查的專案。Office 欄是 docx/pdf/xlsx/pptx 數量，"
              "通常那才是值得進 wiki 的東西。")
    if wikis:
        print(f"\n🔴 其中 {wikis} 個是既有 wiki vault（種類欄 wiki根／知識層），"
              "沒有產生 add 指令。")
        print("   那種要分兩個 alias 掛（raw 與 wiki 各一），知識層一律不 ingest、改建指標卡。")
        print("   直接對它跑 add 會擋下並印出正確指令。")
    return 0


def cmd_list(root, args):
    m = load_manifest(root)
    repos = {k: v for k, v in m.get("repos", {}).items() if not k.startswith("_")}
    sources = manifest_sources(m)          # #33：過濾 `_` 備註與非 dict
    if not repos:
        print("尚未註冊任何外部 repo。加入：python repo.py add <路徑>")
        return 0

    if backfill_paths(root, m) | backfill_kinds(root, m):
        save_manifest(root, m)            # #26 / #27
    KIND = {"compiled-wiki": "知識層", "vault-root": "wiki根", "docs": "文件"}
    WM = {("others", False): "唯讀", ("others", True): "可寫!他人",
          ("unknown", False): "唯讀", ("unknown", True): "可寫?不明",
          ("mine-vault", False): "唯讀", ("mine-vault", True): "可寫.vault",
          ("mine-plain", False): "唯讀", ("mine-plain", True): "可寫"}
    print(f"{'alias':<16} {'種類':<6} {'寫入':<10} {'卡':>4}  {'狀態':<6} {'擁有者':<12} 路徑")
    print("-" * 112)
    bad, hard, writable_others, autosync, unknown_owner = [], [], [], [], []
    for alias, r in sorted(repos.items()):
        n = sum(1 for k in sources if k.startswith(f"{alias}::"))
        alive = resolve_repo_path(root, r.get("path", "")).exists()
        owner = (r.get("owner") or {}).get("name", "?")
        k = r.get("kind", "docs")
        own, w = ownership(root, alias, r), bool(r.get("writable"))
        print(f"{alias:<16} {KIND.get(k, '文件'):<6} {WM[(own, w)]:<10} {n:>4} "
              f" {'✅ 在' if alive else '🔴 失效':<6} {owner:<12} {r.get('path','')}")
        if w:
            if own == "others":
                writable_others.append(alias)
            elif own == "unknown":
                unknown_owner.append(alias)
            mins = autosync_of(resolve_repo_path(root, r.get("path", ""))) if alive else None
            if mins:
                autosync.append((alias, mins, (r.get("owner") or {}).get("remote", "?")))
        if r.get("desc"):
            print(f"{'':<16}              {r['desc']}")
        if not alive:
            print(f"{'':<16}              ↳ remote: {(r.get('owner') or {}).get('remote','?')}")
        if k == "vault-root":
            bad.append(alias)
        if is_hardcoded(r.get("path", "")):
            hard.append(alias)
    if bad:
        print(f"\n🔴 {'、'.join(bad)} 是整包掛進來的 wiki vault —— "
              "原始正本與對方已編譯的知識層混在同一個 alias。")
        print("   拆成兩個：remove 後分別 add <路徑>/raw 與 <路徑>/wiki（知識層只建指標卡，不 ingest）。")
    if writable_others:
        print(f"\n🔴 {'、'.join(writable_others)} 是**別人的** repo 且已開放寫入。動它之前 MUST：")
        print("   ① 使用者說過對方同意（不可從「叫我改」推導）　② 先 `git pull`　"
              "③ 完成後 `commit` + `push`")
        print("   commit message 標明從哪個 vault 遠端改的 ＋ session 名（那是唯一的歸屬證據）。")
    if unknown_owner:
        print(f"\n⚠️ {'、'.join(unknown_owner)} 已開放寫入，但**抓不到擁有者**"
              "（非 git 來源，manifest 記 unknown）。")
        print("   工具無法判斷是你的還是別人的 —— 若是別人的，別人的那三個 MUST 同樣適用。")
    for alias, mins, remote in autosync:
        print(f"\n🔴 {alias} 有自動同步（每 {mins} 分鐘自動 commit／push → {remote}）。")
        print("   改動幾分鐘內就會推出去，沒有反悔空檔，**半成品也會被推** —— 動手前先告知使用者。")
    if hard:
        print(f"\n🔴 {'、'.join(hard)} 存的是絕對路徑，換機器會失效。"
              "改成 ${你的變數}/子路徑，兩台機器都設好那個環境變數。")
    return 0


def cmd_scan(root, args):
    m = load_manifest(root)
    repos = {k: v for k, v in m.get("repos", {}).items() if not k.startswith("_")}
    if args.alias:
        repos = {k: v for k, v in repos.items() if k == args.alias}
        if not repos:
            print(f"🔴 repo `{args.alias}` 未註冊")
            return 1
    sources = manifest_sources(m)          # #33：過濾 `_` 備註與非 dict
    rc = 0

    for alias, r in sorted(repos.items()):
        base = resolve_repo_path(root, r.get("path", ""))
        print(f"\n### {alias} — {r.get('desc') or '(無說明)'}")
        if not base.exists():
            owner = r.get("owner") or {}
            print(f"🔴 路徑失效：{base}")
            print(f"   這條路徑屬於 {owner.get('name','?')} @ {owner.get('machine','?')}")
            print(f"   remote：{owner.get('remote','?')}")
            print("   （不自動移除註冊 —— 可能只是換了機器）")
            rc = 1
            continue

        excludes = set(r.get("exclude") or DEFAULT_EXCLUDE)
        found = {str(p.relative_to(base)).replace("\\", "/") for p in _candidates(base, excludes)}
        known = {k.split("::", 1)[1]: v for k, v in sources.items() if k.startswith(f"{alias}::")}

        new = sorted(found - set(known))
        gone = sorted(set(known) - found)
        changed = []
        for rel, meta in known.items():
            if rel in found and meta.get("hash"):
                h = _md5(base / rel)
                if h and h != meta["hash"]:
                    changed.append(rel)

        if changed:
            print(f"🟡 變更 {len(changed)} 個（hash 不同，wiki 可能已過期）：")
            for x in changed[:10]:
                print(f"   ~ {x}")
        if new:
            print(f"🔵 新增 {len(new)} 個（未 ingest）：")
            for x in new[:10]:
                print(f"   + {x}")
            if len(new) > 10:
                print(f"   … 另有 {len(new)-10} 個")
        if gone:
            print(f"🔴 消失 {len(gone)} 個（manifest 有紀錄但檔案不在）：")
            for x in gone[:10]:
                print(f"   - {x}")
        if not (changed or new or gone):
            print("🟢 無變更")

        r["last_scanned"] = date.today().isoformat()

    save_manifest(root, m)
    write_repos_page(root)
    print("\n（只回報，不自動 ingest。要處理變更：/wiki-ingest {alias}::{路徑}）")
    return rc


def dangling_repos_refs(root):
    """`wiki/repos.md` 不在時，找出還連向它的 wiki 頁。

    刪衍生頁是刻意的（見 write_repos_page），但 hot.md／index.md 常留著 [[repos]]，
    刪完就變死連結，Obsidian 不會報錯、只會靜靜壞掉（2026-09-21 驗收 #14）。
    """
    wiki = root / "wiki"
    if not wiki.is_dir():
        return []
    pat = re.compile(r"\[\[repos(?=[|#\]])")
    out = []
    for f in sorted(wiki.rglob("*.md")):
        try:
            if pat.search(f.read_text(encoding="utf-8")):
                out.append(f.relative_to(root).as_posix())
        except OSError:
            pass
    return out


def cmd_remove(root, args):
    m = load_manifest(root)
    repos = m.get("repos", {})
    if args.alias not in repos:
        print(f"🔴 repo `{args.alias}` 未註冊")
        return 1
    n = sum(1 for k in manifest_sources(m) if k.startswith(f"{args.alias}::"))   # #33
    if n and not args.force:
        print(f"⚠️ `{args.alias}` 有 {n} 筆 ingest 紀錄，移除後這些 catalog 卡會指向失效來源。")
        print("   確定要移除 → 加 --force（只移除 repos 條目，保留 sources 與 catalog 卡）")
        return 1
    repos.pop(args.alias)
    save_manifest(root, m)
    write_repos_page(root)
    print(f"✅ 已移除 repo `{args.alias}`（保留 {n} 筆 sources 紀錄與 catalog 卡）")
    if not (root / "wiki" / "repos.md").exists():
        refs = dangling_repos_refs(root)
        if refs:
            print("🟡 最後一個外部 repo 已移除 → `wiki/repos.md` 一併刪除，"
                  "下列頁面的 [[repos]] 變成死連結，請清掉：")
            for f in refs:
                print(f"   · {f}")
    return 0


# 🔴 #31：重掛 alias（例如把整包掛的 vault 拆成 raw／wiki 兩個）時，source key 要跟著搬。
# 0.4.19 之前沒有這支，只能自己開 JSON 改 —— 而 skill 第一行就寫「不要手改 manifest」。
# 規則叫人別做的事，工具卻不提供替代方案，那條規則就一定會被違反。
# 🔴 #32：建卡的 manifest 登記（ingest Step 4）原本全靠手寫，漏了就是孤兒卡 ——
# 卡在、內容也對，但 scan 永遠不會說它過期。#28 加了偵測，這支負責預防。
def scope_of_key(key):
    """source key → scope：`alias::…` → alias；`raw/X/…` → X；其他 → None（要人指定）。"""
    if "::" in key:
        return key.split("::", 1)[0]
    parts = key.replace("\\", "/").split("/")
    if len(parts) >= 3 and parts[0] == "raw":
        return parts[1]
    return None


_FM_RE = re.compile(r"\A---\n(.*?)\n---\n", re.S)


def ensure_scope(card: Path, scope: str, force=False):
    """卡片 frontmatter 補 `scope:`。已有且 force=False → 不動，回 False。"""
    text = card.read_text(encoding="utf-8", errors="replace")
    m = _FM_RE.match(text)
    if not m:
        return False
    fm = m.group(1)
    has = re.search(r"(?m)^scope:", fm)
    if has and not force:
        return False
    line = f"scope: {scope}"
    fm2 = re.sub(r"(?m)^scope:.*$", line, fm) if has else fm + "\n" + line
    card.write_text(text[:m.start(1)] + fm2 + text[m.end(1):], encoding="utf-8", newline="\n")
    return True


CARD_PATH_KEYS = ("current_file", "source_file", "source_path")
_ABS_RE = re.compile(r"^[A-Za-z]:[\\/]|^/(?:Users|home|mnt|Volumes)/")


def _portable(root, repos, value):
    """絕對路徑 → `alias::rel`（在某個已註冊 repo 底下）或 `raw/…`（在本 vault 底下）。改不了回 None。"""
    v = value.replace("\\", "/")
    if not _ABS_RE.match(v):
        return None
    p = Path(v)
    best = None
    for alias, e in repos.items():
        if not isinstance(e, dict) or alias.startswith("_"):
            continue                      # `_note` 之類的人寫備註
        base = resolve_repo_path(root, e.get("path", ""))
        try:
            rel = p.resolve().relative_to(base.resolve()).as_posix()
        except (ValueError, OSError):
            continue
        if best is None or len(str(base)) > best[0]:
            best = (len(str(base)), f"{alias}::{rel}")
    if best:
        return best[1]
    try:
        return p.resolve().relative_to(Path(root).resolve()).as_posix()
    except (ValueError, OSError):
        return None


def cmd_fixpaths(root, args):
    """卡片 frontmatter 的絕對路徑改成可攜形式；`source_abs` 整行移除（它只能是絕對路徑）。"""
    m = load_manifest(root)
    repos = m.get("repos", {})
    cat = root / "wiki" / "catalog"
    changed, stuck = [], []
    for card in sorted(cat.glob("*.md")) if cat.is_dir() else []:
        text = card.read_text(encoding="utf-8", errors="replace")
        fm = _FM_RE.match(text)
        if not fm:
            continue
        body, edits = fm.group(1), []
        for key in CARD_PATH_KEYS:
            mk = re.search(rf'(?m)^{key}:[ \t]*"?([^"\n]+?)"?[ \t]*$', body)
            if not mk:
                continue
            new = _portable(root, repos, mk.group(1))
            if new:
                body = body[:mk.start()] + f'{key}: "{new}"' + body[mk.end():]
                edits.append(f"{key} → {new}")
            elif _ABS_RE.match(mk.group(1).replace("\\", "/")):
                stuck.append(f"{card.relative_to(root).as_posix()}: {key} 不在任何已註冊 repo 底下，請先 /wiki-repo add 或手改")
        if re.search(r"(?m)^source_abs:", body):
            body = re.sub(r"(?m)^source_abs:.*\n?", "", body)
            edits.append("移除 source_abs")
        if edits:
            rel = card.relative_to(root).as_posix()
            changed.append((rel, edits))
            if not args.dry_run:
                card.write_text(text[:fm.start(1)] + body + text[fm.end(1):], encoding="utf-8", newline="\n")
    tag = "會改" if args.dry_run else "已改"
    print(f"{tag} {len(changed)} 張；改不了 {len(stuck)} 處")
    for rel, edits in changed:
        print(f"  {rel}")
        for e in edits:
            print(f"     · {e}")
    for s_ in stuck:
        print(f"  ⚠️ {s_}")
    if changed and not args.dry_run:
        print("已寫入：" + "、".join(r for r, _ in changed))
    return 0


def cmd_scope(root, args):
    """回填缺 scope 的卡：依 manifest sources 的 catalog_page ↔ key 推導。"""
    m = load_manifest(root)
    done, skipped, unknown = [], [], []
    for key, e in manifest_sources(m).items():
        cp = e.get("catalog_page")
        if not cp:
            continue
        card = root / cp
        if not card.is_file():
            continue
        sc = args.scope or scope_of_key(key)
        if not sc:
            unknown.append(cp)
            continue
        if args.dry_run:
            text = card.read_text(encoding="utf-8", errors="replace")
            (skipped if re.search(r"(?m)^scope:", text[:2000]) else done).append(f"{cp} ← {sc}")
            continue
        (done if ensure_scope(card, sc, force=args.force) else skipped).append(f"{cp} ← {sc}")
    tag = "會補" if args.dry_run else "已補"
    print(f"{tag} {len(done)} 張；已有 scope 跳過 {len(skipped)} 張；推不出 scope {len(unknown)} 張")
    for d in done:
        print(f"  + {d}")
    for u in unknown:
        print(f"  ? {u}（key 不在 raw/<夾>/ 底下，用 --scope 指定）")
    if done and not args.dry_run:
        print("已寫入：" + "、".join(d.split(" ← ")[0] for d in done))
    return 0


def cmd_link(root, args):
    key = args.key
    card = Path(args.card)
    if not card.is_absolute():
        card = root / card
    if not card.is_file():
        print(f"🔴 卡片不存在：{args.card}")
        return 1
    rel_card = card.resolve().relative_to(root.resolve()).as_posix()

    tgt = resolve_source(root, key)
    if tgt is None:
        print(f"🔴 source key 的 alias 未註冊：{key}")
        return 1
    if not tgt.exists():
        print(f"🔴 source key 指向的檔案不存在：{key}")
        print(f"   解析為：{tgt}")
        return 1

    m = load_manifest(root)
    src = m.setdefault("sources", {})
    h = _md5(tgt)
    entry = src.get(key, {})
    was = bool(entry)
    entry.update({"hash": h, "ingested_at": date.today().isoformat(),
                  "catalog_page": rel_card, "tier": args.tier})
    if "::" in key:
        entry["repo"] = key.split("::", 1)[0]
    if args.topics:
        entry["topics_updated"] = [t.strip() for t in args.topics.split(",") if t.strip()]
    src[key] = entry
    save_manifest(root, m)
    write_repos_page(root)
    sc = args.scope or scope_of_key(key)
    sc_note = ""
    if sc:
        sc_note = "（frontmatter 已補）" if ensure_scope(card, sc) else "（frontmatter 已有）"
    print(f"✅ {'更新' if was else '登記'}：{key}")
    print(f"   卡片：{rel_card}")
    print(f"   hash：{h}　tier：{args.tier}　scope：{sc or '⚠️ 推不出，請在卡上手填'}{sc_note}")
    print("   scan 從現在起會在正本改動時報這張卡過期。")
    return 0


def cmd_rename(root, args):
    m = load_manifest(root)
    repos = m.setdefault("repos", {})
    old, new = args.old, args.new
    # 已被 remove 的 alias 仍可能殘留在 sources／doc_index 裡（remove 預設保留紀錄）。
    # 那正是最需要修的情況 —— 要求「old 必須已註冊」等於把工具擋在問題外面。
    orphan_mode = old not in repos
    if orphan_mode:
        refs = sum(1 for k in manifest_sources(m) if k.startswith(f"{old}::"))   # #33
        refs += sum(
            1 for e in m.get("doc_index", {}).values()
            if str(e.get("current_file", "")).startswith(f"{old}::")
            or any(str(h.get("file", "")).startswith(f"{old}::") for h in e.get("history", []))
        )
        if not refs:
            print(f"🔴 repo `{old}` 未註冊，且 sources／doc_index 也沒有任何 `{old}::` 紀錄")
            return 1
        print(f"⚠️ `{old}` 已不在 repos（大概被 remove 過），但還有 {refs} 處殘留紀錄 —— 只搬紀錄。")
    elif new in repos and new != old:
        # 正常改名才怕撞名；orphan 模式下「目標已註冊」正是我們要的（把殘留指回現有 alias）
        print(f"🔴 alias `{new}` 已存在（指向 {repos[new].get('path')}）")
        return 1
    strip = (args.strip_prefix or "").strip("/")
    strip = strip + "/" if strip else ""
    src = m.setdefault("sources", {})
    keys = [k for k in src if k.startswith(f"{old}::")]

    # 先全部試算，有任何一筆搬不動就整批不做 —— 半套的 manifest 比沒搬更難修
    plan, bad = [], []
    for k in keys:
        rel = k[len(old) + 2:]
        if strip:
            if not rel.startswith(strip):
                bad.append((k, f"不是以 `{strip}` 開頭，--strip-prefix 套不上"))
                continue
            rel = rel[len(strip):]
        nk = f"{new}::{rel}"
        if nk in src:
            bad.append((k, f"目標 key 已存在：{nk}"))
            continue
        plan.append((k, nk, src[k].get("catalog_page", "")))
    if bad:
        print(f"🔴 {len(bad)} 筆搬不動，整批中止（沒有動到 manifest）：")
        for k, why in bad:
            print(f"   · {k}\n     {why}")
        return 1

    if args.dry_run:
        print(f"（dry-run，沒有寫入）{old} → {new}"
              f"{'，去掉前綴 ' + strip if strip else ''}：{len(plan)} 筆 source key")
        for k, nk, _ in plan:
            print(f"   {k}\n → {nk}")
        return 0

    if not orphan_mode and repos[old].get("path") and new != old:
        repos[new] = repos.pop(old)
    for k, nk, _ in plan:
        v = src.pop(k)
        v["repo"] = new
        src[nk] = v

    # 🔴 sources 不是唯一存 source key 的地方 —— doc_index 的 current_file／history[].file
    # 也用同一個格式。只搬 sources 會留下指向已不存在 alias 的 doc_index，而且
    # 沒有任何檢查會看它 → 版次接替時會拿死路徑去比對。
    # （2026-09-21 實測發現：手動把 foo 拆成 foo-raw 後，doc_index 仍寫著 foo::…）
    def _mv(val):
        if not isinstance(val, str) or not val.startswith(f"{old}::"):
            return val, False
        rel = val[len(old) + 2:]
        if strip and rel.startswith(strip):
            rel = rel[len(strip):]
        return f"{new}::{rel}", True

    di_hits = 0
    for entry in m.get("doc_index", {}).values():
        entry["current_file"], hit = _mv(entry.get("current_file"))
        di_hits += hit
        for h in entry.get("history", []):
            h["file"], hit = _mv(h.get("file"))
            di_hits += hit
    save_manifest(root, m)
    write_repos_page(root)

    print(f"✅ `{old}` → `{new}`　source key 已搬 {len(plan)} 筆"
          f"{'（去掉前綴 ' + strip + '）' if strip else ''}"
          f"{f'；doc_index 另搬 {di_hits} 處' if di_hits else ''}")
    cards = sorted({c for _, _, c in plan if c})
    if cards:
        # 🔴 卡的 frontmatter 是 Claude 寫的散文，腳本不該亂改 —— 只回報，人／Claude 自己判斷
        print(f"\n🔴 下列 {len(cards)} 張卡的 frontmatter 還指著舊 alias，**腳本不會自動改**：")
        for c in cards:
            print(f"   · {c}")
        print(f"   要改的欄位：`repo:`、`source_file:`（若用了 --strip-prefix 要去掉前綴）、"
              f"內文出現的 `{old}::` 字樣")
    return 0


def main():
    ap = argparse.ArgumentParser(description="多 repo 來源管理")
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add"); a.add_argument("path"); a.add_argument("--alias"); a.add_argument("--desc", default="")
    a.add_argument("--force", action="store_true",
                   help="目標是既有 wiki vault 時仍整包掛（預設擋下，改建議分兩個 alias）")
    sub.add_parser("list")
    s = sub.add_parser("scan"); s.add_argument("alias", nargs="?")
    r = sub.add_parser("remove"); r.add_argument("alias"); r.add_argument("--force", action="store_true")
    fp = sub.add_parser("fixpaths", help="卡片 frontmatter 的絕對路徑改成 alias::rel 或 raw/…；移除 source_abs")
    fp.add_argument("--dry-run", action="store_true")
    sc = sub.add_parser("scope", help="回填缺 scope 的卡（依 source key 推導：alias 或 raw/ 第一層）")
    sc.add_argument("--scope", help="全部指定為此值（不推導）")
    sc.add_argument("--force", action="store_true", help="已有 scope 也覆寫")
    sc.add_argument("--dry-run", action="store_true")
    lk = sub.add_parser("link", help="把 catalog 卡登記進 manifest.sources（#32，防孤兒卡）")
    lk.add_argument("--scope", help="覆寫自動推導的 scope（alias 或 raw/ 第一層名）")
    lk.add_argument("key", help="source key：raw/x.pdf 或 {alias}::{repo 內路徑}")
    lk.add_argument("card", help="卡片路徑，相對 vault 根，例：wiki/catalog/X.md")
    lk.add_argument("--tier", default="1", help="1 或 full（預設 1）")
    lk.add_argument("--topics", default="", help="逗號分隔")
    rn = sub.add_parser("rename", help="改 alias 並搬動所有 source key（#31）")
    rn.add_argument("old"); rn.add_argument("new")
    rn.add_argument("--strip-prefix", dest="strip_prefix", default="",
                    help="新 alias 的根往下移時，從 source key 去掉這段前綴（例：raw/）")
    rn.add_argument("--dry-run", action="store_true", dest="dry_run")
    d = sub.add_parser("discover", help="掃描上層資料夾，列出候選專案供批次註冊")
    d.add_argument("path")
    d.add_argument("--depth", type=int, default=2, help="往下找幾層（預設 2）")
    d.add_argument("--min-files", type=int, default=3, dest="min_files",
                   help="至少幾份文件才算候選（預設 3）")
    d.add_argument("--min-office", type=int, default=1, dest="min_office",
                   help="至少幾份 Office 檔（docx/pdf/xlsx/pptx）才算候選（預設 1，設 0 不過濾）")
    d.add_argument("--include-code", action="store_true", dest="include_code",
                   help="連程式碼專案也列（預設排除 package.json/CMakeLists 那類）")

    args = ap.parse_args()
    root = find_vault_root(Path.cwd())
    if root is None:
        print("🔴 找不到 vault（往上找不到含 wiki/ 或 raw/.manifest.json 的目錄）")
        return 1
    return {"add": cmd_add, "list": cmd_list, "scan": cmd_scan,
            "remove": cmd_remove, "discover": cmd_discover,
            "rename": cmd_rename, "link": cmd_link, "scope": cmd_scope,
            "fixpaths": cmd_fixpaths}[args.cmd](root, args)


if __name__ == "__main__":
    sys.exit(main())
