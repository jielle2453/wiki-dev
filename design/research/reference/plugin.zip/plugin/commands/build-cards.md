---
description: 建置 4：分批製卡，中斷後可從斷點續做
argument-hint: "[分區代號]"
disable-model-invocation: true
---

# 批次製卡

依核心規則執行（第八節安靜模式）：@${CLAUDE_PLUGIN_ROOT}/rules/core-rules.md

**檔案內容只能由子代理讀**，主對話只處理排程與數字。

程式：`${CLAUDE_PLUGIN_ROOT}/scripts/`

## 步驟

1. 重設上次中斷時殘留的「處理中」：`python "${CLAUDE_PLUGIN_ROOT}/scripts/batch.py" 重設`
2. 看進度：`python "${CLAUDE_PLUGIN_ROOT}/scripts/batch.py" 進度`
3. 重複以下迴圈，直到沒有待處理的檔案：
   1. 取三批，每批 10 份（指定分區時加 `--分區 $ARGUMENTS`）：
      `python "${CLAUDE_PLUGIN_ROOT}/scripts/batch.py" 下一批 --數量 10`
   2. 每批派一個 `card-maker` 代理，三個平行（放在同一則訊息裡一起派，前景執行，不要設成背景）。訊息裡給：
      - plugin 路徑：`${CLAUDE_PLUGIN_ROOT}`
      - 總資料夾路徑：目前資料夾的完整路徑
      - 任務類型：製卡
      - 這批檔案的 JSON
   3. 三個代理都回來後：
      - 重建索引：`python "${CLAUDE_PLUGIN_ROOT}/scripts/reindex.py"`
      - 印進度：`python "${CLAUDE_PLUGIN_ROOT}/scripts/batch.py" 進度`
      - 代理會自己把新的文件類型加進客戶設定檔（來源「推測」）；回報有新類型時，看一下設定檔有沒有重複的列，有就合併（合併時依據合在一起、最多 3 份；其中一列依據是空的，合併後就留空）；代理說設定檔是舊格式時，記進〈等服務人員處理〉請服務人員重跑 init_kb.py
   4. 用一行告訴服務人員進度，例如「已完成 120／860 份，失敗 3 份」。
4. 全部完成後，在 `admin/改動紀錄.md` 加一行：`[時間] 建置｜製卡完成 N 張，失敗 M 份`。
5. 交代下一步：`/llm-wiki:build-finish`

## 中斷與續做

- 額度用完或中斷時，已完成的卡片與清冊狀態都會保留。恢復後重新執行 `/llm-wiki:build-cards` 即可從斷點續做。
- 標為「失敗」的檔案不會再被取出，已記在 `admin/待處理.md`〈讀不到的檔案〉。
