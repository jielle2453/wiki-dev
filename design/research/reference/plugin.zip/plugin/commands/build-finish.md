---
description: 建置 5：填寫總覽、總目錄、交付確認與建置報告
disable-model-invocation: true
---

# 收尾

依核心規則執行（第八節安靜模式）：@${CLAUDE_PLUGIN_ROOT}/rules/core-rules.md

會讀到內容的工作交給子代理，主對話只看數字。

## 步驟

0. **先確認總資料夾已信任，沒信任就停下：** 執行 `python "${CLAUDE_PLUGIN_ROOT}/scripts/envcheck.py" --知識庫 "<目前資料夾的完整路徑>"`。
   - 「總資料夾已信任」是「是」：往下做第 1 步。
   - 「否」或「看不出來」：**停下，第 1 步以後都不要做**。照它印出的說明告訴服務人員（或自己建置的客戶）怎麼信任：在總資料夾開一次 Claude Code，跳出「是否信任這個資料夾」時按信任；以及為什麼：沒信任時放行規則全部不生效，客戶日常使用時讀來源、執行程式都會一直被問。請對方信任後重開，再執行一次 `/llm-wiki:build-finish`。「看不出來」時，對方確認按過信任就可以再執行一次。
1. 重建索引並檢查結構：
   - `python "${CLAUDE_PLUGIN_ROOT}/scripts/reindex.py"`
   - `python "${CLAUDE_PLUGIN_ROOT}/scripts/check.py"`
   - 有「索引與卡片數不一致」以外的問題，用檔名與數字告訴服務人員。
2. 派一個 general-purpose 代理撰寫以下頁面。訊息裡給 plugin 路徑 `${CLAUDE_PLUGIN_ROOT}`、總資料夾路徑、成品區路徑（`admin/來源清單.json` 的「成品區」），要求它先讀 `${CLAUDE_PLUGIN_ROOT}/rules/core-rules.md`，**最後只回報寫了哪些頁面，不回報內容**：
   - 每個分區的 `wiki/<分區>/總覽.md`：照 `${CLAUDE_PLUGIN_ROOT}/templates/總覽.md` 寫，依索引與卡片撰寫，每句附出處。讀不到的數量用 `batch.py 進度` 的「失敗」數；子資料夾對應從卡片「原檔」路徑的第一層歸納。
   - `wiki/總目錄.md`：已有格式，填入每個分區一行（連到總覽與索引）、跨區綜合頁清單、5–8 個依實際資料設計的「可以這樣問」。
   - 成品區的 `交付確認.md`：已有格式，把客戶設定檔中來源為「推測」的文件類型、詞彙、人物、專案，改寫成客戶看得懂的說法填入。
3. 填寫 `admin/建置報告.md`（已有格式，只有數字，服務人員可以看）：
   - 各分區檔案數、製卡數、失敗數、重複、略過、雲端占位（`batch.py 進度` 與 `inventory.py` 的統計）
   - 讀不到的檔案：依原因分類計數（從 `admin/待處理.md`〈讀不到的檔案〉統計，不列內容）
   - 建置日期、plugin 版本（`${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`）、範本版本（`${CLAUDE_PLUGIN_ROOT}/templates/` 三份範本頁首的「範本版本」）
4. 在 `admin/改動紀錄.md` 加一行：`[時間] 建置｜收尾完成`。
5. 記下第一次健檢的時間（這時還沒有綜合頁，結構已在步驟 1 檢查過）：`python "${CLAUDE_PLUGIN_ROOT}/scripts/health.py" 完成`。之後客戶開對話時，滿 7 天會自動提醒健檢。
6. 告訴服務人員：
   - 建置報告的重點數字
   - 總資料夾的信任狀態（第 0 步的結果）
   - 交付時帶客戶看成品區的 `交付確認.md` 逐條勾選或寫下正確說法，然後在 Claude 說「交付確認看完了」，query 技能會把結果寫回客戶設定檔
   - 客戶之後用桌面捷徑開啟 Claude，直接用一般的話問問題；AI 起草的文件在成品區
