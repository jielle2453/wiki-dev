---
description: 建置 3：抽樣試讀，推測文件類型、詞彙與人物
argument-hint: "[每區份數，預設 12]"
disable-model-invocation: true
---

# 試讀

依核心規則執行（第八節安靜模式）：@${CLAUDE_PLUGIN_ROOT}/rules/core-rules.md

**檔案內容只能由子代理讀**，你和服務人員都不看內容。

## 步驟

1. 抽樣：`python "${CLAUDE_PLUGIN_ROOT}/scripts/batch.py" 抽樣 --每區 <$ARGUMENTS 或 12>`
2. 把抽樣結果依分區分組，每組派一個 `card-maker` 代理（可平行，最多 3 個，放在同一則訊息裡一起派，前景執行，不要設成背景），任務類型為**試讀**。訊息裡給：
   - plugin 路徑：`${CLAUDE_PLUGIN_ROOT}`
   - 總資料夾路徑：目前資料夾的完整路徑
   - 任務類型：試讀
   - 這組檔案的 JSON
   - 提醒：平行的代理會同時改客戶設定檔，寫入前先重新讀一次，用 Edit 加入條目，不要整份覆寫；每條推測都要填「依據」（`{代號}/相對路徑`，最多 3 份）
3. 彙整代理的回報給服務人員：每區新增了幾條文件類型、詞彙、人物、專案；讀取失敗的檔名與原因。**不要讀出設定檔的內容。**
4. 交代下一步：`/llm-wiki:build-cards`
