---
description: 建置 1：檢查環境、建立總資料夾與成品區、寫入訪談內容
argument-hint: "[總資料夾路徑]"
disable-model-invocation: true
---

# 建置準備

協助服務人員於客戶電腦上建置 LLM-wiki。依核心規則執行（特別注意第八節安靜模式）：@${CLAUDE_PLUGIN_ROOT}/rules/core-rules.md

plugin 路徑：`${CLAUDE_PLUGIN_ROOT}`
程式路徑：`${CLAUDE_PLUGIN_ROOT}/scripts/`

## 步驟

### 1. 環境檢查

要裝的只有 plugin 的基礎元件，都有不用管理員的裝法（winget 裝 Node.js、Git 可能跳出管理員確認，沒有管理員就用 Node.js 的 zip 版、PortableGit）；客戶的辦公軟體（Office、LibreOffice、WPS）照客戶原本的習慣，**不幫客戶裝**（決策 #45）。

1. 確認 `python --version` 是 3.10 以上。沒有 Python 時，請服務人員安裝（`winget install Python.Python.3.12`，或到 python.org 下載，安裝時勾選加入 PATH），裝好後重開 Claude Code。
2. 安裝套件：`python -m pip install "markitdown[docx,pptx,xlsx,xls,pdf]" pdfplumber`（openpyxl、pandas、lxml、defusedxml、pypdfium2 會一起裝；掃描 PDF 轉圖片用 pypdfium2，不用裝 poppler）
3. 確認 `node --version`。沒有 Node.js 時請服務人員安裝（`winget install OpenJS.NodeJS.LTS`，或官方 zip 版解壓縮後把資料夾加進使用者 PATH），裝好後重開 Claude Code。docx 技能產生新 Word 要用它。
4. 執行 `python "${CLAUDE_PLUGIN_ROOT}/scripts/envcheck.py"`，把「問題」逐條用白話告訴服務人員：
   - onnxruntime 無法載入、VC++ 版本太舊：不影響使用（自動改用替身），只是建議，更新要管理員，客戶同意再裝。
   - 看不到 docx／xlsx 技能：請客戶在 claude.ai 帳號開啟文件技能（會同步到 `~/.claude/skills/synced/`）；同步不到時改裝 GitHub 上的 anthropics/skills。
   - 沒有技能、沒有 Node.js 時，建置照常完成，只是做不了 Word：寫進建置報告與〈等服務人員處理〉。
   - 「重算與轉 PDF」只是告訴你客戶電腦有什麼辦公軟體，沒有也不用裝。
5. Git for Windows（Bash）：envcheck 印「Bash：沒有」時，請服務人員裝 `winget install Git.Git`（或 PortableGit）。桌面版沒有它時有沒有 Bash 工具**還待端到端確認**，先照這樣裝。

### 2. 收集建置資訊

一次問一項，給建議值：

| 項目 | 建議值 |
|---|---|
| 總資料夾位置 | `$ARGUMENTS`；沒給就建議 `%USERPROFILE%\.llm-wiki`（客戶不直接打開，放在不常去的位置）。不能放在任何來源資料夾裡 |
| 成品區位置 | 建議 `%USERPROFILE%\Documents\AI 產出`。客戶會在這裡拿 AI 起草的文件，要放在一般看得到的位置；不能放在來源資料夾或總資料夾裡 |
| 來源資料夾 | 客戶指定的資料夾，可多個 |
| 分區 | 預設一個來源資料夾一個分區。名稱用客戶習慣的說法（例如「薪資」），代號用簡短中文或英文，之後不改 |
| 共用 | 每個分區問一次：「這個資料夾有和別人共用嗎？（例如同事也會打開的雲端資料夾）」（訪談第 2.5 題）。共用的分區，客戶要 AI 存檔、搬檔、改名時會先問一句「其他人也會看到」。預設「否」 |
| AI 產出放哪 | 每個分區：AI 起草的 Word、Excel 放那一區來源最上層的「AI 產出」資料夾（`資料夾內`），還是集中放成品區（`中央`）。不問也可以：共用的、雲端同步資料夾（OneDrive、Dropbox、Google 雲端硬碟）程式預設中央，其他預設資料夾內 |
| 排除規則 | 客戶不想納入的資料夾或檔名，例如 `私人`、`*.bak` |
| 辦公軟體 | 「平常用 Microsoft 365 桌面版、只有網頁版、Google 文件，還是其他（LibreOffice、WPS）？」寫進客戶設定檔〈辦公軟體〉。只用來決定 AI 怎麼跟客戶說，能不能重算、轉 PDF 由程式自己偵測。Microsoft 365 有些方案只有網頁版（例如商務基本版），沒有桌面版要問清楚。Google 用戶第一版照「都沒有」處理，並記進〈等服務人員處理〉（輸出到 Google 雲端硬碟還沒做） |

### 3. 建立總資料夾與成品區

```
python "${CLAUDE_PLUGIN_ROOT}/scripts/init_kb.py" "<總資料夾>" --成品區 "<成品區>" --分區 "名稱|代號|來源路徑|說明|共用|AI 產出放哪" [--分區 ...] [--排除 規則 ...]
```

「共用」寫 `是` 或 `否`；「AI 產出放哪」寫 `資料夾內` 或 `中央`，不寫照預設。

裝 docx 技能要用的 npm 套件到總資料夾（init_kb 已建好 `.system/node/`）：`npm install docx --prefix "<總資料夾>/.system/node"`。沒有 Node.js 就跳過，記進建置報告。

再執行一次 envcheck，把結果存進總資料夾：`python "${CLAUDE_PLUGIN_ROOT}/scripts/envcheck.py" --知識庫 "<總資料夾>"`。這時「總資料夾已信任」會是「否」（還沒在總資料夾開過），先不用處理，第 5 步會交代。

客戶電腦有桌面版 Word／Excel 或 LibreOffice 時，這一次 envcheck 會做 **Office 自檢**：用 plugin 附的小檔實際在背景重算一次 Excel、把 Word 轉一次 PDF（約 10–30 秒），印「Office 自檢：重算 ✓／轉 PDF ✓」或失敗原因。
- 都是 ✓：之後改 Excel 會重算、可以給客戶 PDF。
- 有 ✗：照實告訴服務人員原因（常見是 Office 第一次啟動要登入或按同意、跳出受保護的檢視）。可以請客戶先手動開一次 Word、Excel 把第一次啟動的視窗處理完，再跑一次 envcheck。還是不行就照輕量做法：跟客戶說「這台電腦的 Office 沒辦法在背景幫你重算或轉 PDF：Excel 改完要你打開檔案才會更新公式結果，也不能直接給你 PDF」，並寫進建置報告與〈等服務人員處理〉（附原因）。
- 「—」表示沒有那個軟體，本來就用輕量做法，不算失敗。

### 4. 寫入訪談內容

請服務人員提供訪談筆記，寫進 `<總資料夾>/admin/客戶設定檔.md` 對應的欄位，每條來源標「訪談」，「依據」欄留空（那一欄是給 AI 推測時記從哪些原檔看出來的）。〈辦公軟體〉照第 2 步問到的寫。只寫客戶親口說的，不要推測。

### 5. 交代下一步

告訴服務人員：

1. 關掉這個 Claude Code，**改在總資料夾開啟**，跳出「是否信任這個資料夾」時**按信任**。沒信任時，總資料夾 `.claude/settings.json` 的放行規則（讀來源資料夾、寫成品區、執行 plugin 程式、讀 plugin 的規則）全部不生效，每一步都會被問、自動模式也會被擋。客戶自己建置時也一樣要按。開好後執行 build-inventory，它第一步會確認信任。沒跳出詢問，通常是上層資料夾已經信任過，build-inventory 也會確認。
2. 在客戶桌面建立一個開啟 Claude 的捷徑，並把成品區釘選到檔案總管的「快速存取」。
3. 接著執行 `/llm-wiki:build-inventory`。
