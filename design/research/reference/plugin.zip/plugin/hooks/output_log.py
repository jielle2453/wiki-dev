"""PostToolUse 掛鉤：AI 用檔案工具寫進成品區之後，自動登記成 AI 產出（spec 4.8、決策 #43）。

登記的是寫完之後的文字內容指紋（ai_output.py），之後這份文件被複製進來源、製卡時，看指紋就知道是 AI 起草的，
不會被當成客戶自己的資料拿來當證據。起草時參考了哪些原檔由 AI 另外用 ai_output.py 登記 --參考 補上。
掛鉤出錯時不擋任何事，只留下紀錄。
"""
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from kbcommon import HOOK_LOG, find_kb, load_sources  # noqa: E402

FILE_TOOLS = ("Write", "Edit", "MultiEdit")


def inside(child, parent):
    c = os.path.normcase(os.path.abspath(child))
    p = os.path.normcase(os.path.abspath(parent)).rstrip("\\/")
    return c.startswith(p + os.sep)


def main():
    data = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}")
    if data.get("tool_name") not in FILE_TOOLS:
        return
    cwd = data.get("cwd") or os.getcwd()
    target = (data.get("tool_input") or {}).get("file_path") or ""
    if not target:
        return
    target = target if os.path.isabs(target) else os.path.join(cwd, target)
    kb = find_kb(cwd) or find_kb(os.path.dirname(target))
    if not kb:
        return
    out = load_sources(kb).get("成品區")
    if not out or not inside(target, out) or not os.path.isfile(target):
        return
    from ai_output import register
    register(kb, target, quiet=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # 掛鉤出錯不能擋住客戶，留下紀錄
        try:
            kb = find_kb()
            if kb:
                with open(kb / HOOK_LOG, "a", encoding="utf-8") as f:
                    f.write(f"{datetime.now():%Y-%m-%d %H:%M} output_log {type(e).__name__}: {e}\n")
        except Exception:
            pass
