"""PreToolUse 掛鉤：原檔保護、自動備份、大改動攔截。

1. 原檔保護：擋下寫入來源資料夾的工具呼叫。
   檔案工具依目標路徑判斷；指令列只能用字串比對「提到來源路徑且含寫入動作」，
   刻意把路徑拆開的程式碼攔不住（實測結果），所以這是規則層之外的第二道防線。
   唯一放行的是「整個指令只有 python 執行 plugin 的 scripts/source_edit.py」（客戶要求改原資料夾，spec 4.6）；
   用 ; && | 換行串了其他指令、導向輸出、反引號或 $( ) 時照一般規則判斷：串接的那段寫到來源照擋，無害的不擋。
   導向（>）只看引號外的部分（0.10.1）。
   admin/來源清單.json、.claude/settings.json 只由 plugin 程式改，檔案工具與指令直接改都擋（0.10.1）。
   總資料夾 .system/node/ 裡 AI 寫的 Python 工作腳本（Word、Excel 處理，放行執行）：執行前讀腳本內容，
   提到來源路徑、{代號}/、wiki/、admin/ 就擋（0.13.0；同樣是第二道防線，刻意拆開的路徑擋不住）。
   同樣的判斷也用在總資料夾：指令改 wiki/、admin/、CLAUDE.md 會被擋下（備份只在檔案工具寫入前做），
   plugin 附帶的程式與刪除 .system/暫存/ 的檔案不受影響。
2. 自動備份：總資料夾裡的頁面被檔案工具改動前，複製到 .system/版本/<回合代號>/，
   並在 清單.jsonl 記下「修改」或「新增」，供 versions.py 退回。
3. 大改動攔截：同一回合修改既有綜合頁超過 10 頁時擋下，請 AI 改寫進 admin/待處理.md〈等你同意的改動〉。

.system/、.claude/、admin/改動紀錄.md、admin/待處理.md、admin/工作日誌/ 不備份（紀錄本身要記下退回這件事）。
成品區不在總資料夾裡，不備份；寫入成品區不攔截。
"""
import json
import os
import re
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from kbcommon import (BIG_CHANGE_PAGES, HOOK_LOG, backup_page, current_turn, find_kb, is_synthesis,  # noqa: E402
                      load_sources, long_path, turn_entries)

FILE_TOOLS = ("Write", "Edit", "MultiEdit", "NotebookEdit")
REDIRECT = re.compile(r">")
WRITE_WORDS = re.compile(
    r"(\btee\b|\bcp\b|\bmv\b|\brm\b|\brmdir\b|\bdel\b|\berase\b|\bren(ame)?\b|\bmove\b|\bcopy\b|"
    r"\bmkdir\b|\btouch\b|\bsed\s+-i|\btruncate\b|"
    r"set-content|add-content|out-file|new-item|remove-item|move-item|copy-item|rename-item|clear-content|"
    r"writealltext|writeallbytes|open\([^)]*['\"][wax+]|\.write_text|\.write_bytes|shutil\.|os\.remove|"
    r"os\.rename|unlink)",
    re.IGNORECASE,
)


def norm(p, cwd):
    p = p.strip().strip('"').strip("'")
    m = re.match(r"^/([a-zA-Z])/(.*)", p)  # Git Bash 風格 /c/Users/...
    if m:
        p = f"{m.group(1)}:/{m.group(2)}"
    if not os.path.isabs(p):
        p = os.path.join(cwd, p)
    return os.path.normcase(os.path.normpath(p))


def inside(t, d):
    return t == d or t.startswith(d.rstrip(os.sep) + os.sep)


def path_forms(src, cwd):
    """來源路徑在指令字串中可能出現的寫法（小寫、分隔符號一律為 /，指令也先照樣正規化）。"""
    a = os.path.normpath(src)
    forms = {a}
    m = re.match(r"^([a-zA-Z]):[\\/](.*)", a)
    if m:
        forms.add(f"/{m.group(1).lower()}/{m.group(2)}")
    try:
        rel = os.path.relpath(a, cwd)
        if not rel.startswith(".."):
            forms.add(rel)
    except ValueError:
        pass
    return {f.replace("\\", "/").lower() for f in forms}


def norm_cmd(cmd):
    """指令字串正規化：小寫、\\\\ 與 \\ 一律改成 /（混用斜線與反斜線的路徑也比對得到）。"""
    return cmd.lower().replace("\\\\", "/").replace("\\", "/")


# 只是把輸出丟掉，不算寫入：2>/dev/null、>/dev/null、2>&1、> nul、| Out-Null
DISCARD_OUTPUT = re.compile(r"\d?>\s*&\s*\d|\d?>\s*/dev/null|\d?>\s*\$null|\d?>\s*nul\b|\|\s*out-null", re.IGNORECASE)
PLUGIN_ROOT = os.path.normpath(os.path.join(HERE, ".."))
PLUGIN_SCRIPTS_ESCAPE = re.compile(re.escape(PLUGIN_ROOT.replace("\\", "/").lower() + "/scripts/") + r"[^\"'\s]*\.\.")
ABS_PATH = re.compile(r"(?:[A-Za-z]:[\\/]|/[a-z]/)[^\"'\s|;&<>]+")
# 總資料夾裡的頁面所在位置（.system 由程式管理，暫存檔可以刪）
VAULT_DIRS = ("wiki", "admin")


def touches_vault_pages(low, kb, cwd):
    """指令是否提到總資料夾的 wiki/、admin/ 或 CLAUDE.md。plugin 自己的程式與 .system/ 除外。"""
    if any(f in low for f in path_forms(PLUGIN_ROOT, cwd) if len(f) > 3):
        return False  # 執行 plugin 附帶的程式
    targets = set()
    for f in path_forms(str(kb), cwd):
        base = f.rstrip("/")
        for d in VAULT_DIRS + ("claude.md",):
            targets.add(f"{base}/{d}")
    in_kb = find_kb(cwd) is not None and os.path.normcase(str(kb)) == os.path.normcase(str(find_kb(cwd)))
    if in_kb:
        # 在總資料夾裡執行時，相對路徑也算
        rel_hits = re.search(r"(^|[\s\"'=(])(\./)?(wiki|admin)[/\\]|(^|[\s\"'])claude\.md\b|\bcd\s+[\"']?(wiki|admin)\b", low)
        if rel_hits:
            return True
    return any(t in low for t in targets)


SOURCE_EDIT = "/scripts/source_edit.py"
# 引號外不能出現的字元：串接指令（; & |）、導向（< >）、換行；反引號與 $( 在引號裡也會執行，一律不行
SHELL_META = set(";&|<>\n\r")


def outside_quotes(cmd):
    """去掉引號裡的內容（引號裡的 > ; | 都只是文字，例如正規表示式 <[^>]+>）。引號沒有成對時回傳 None。"""
    out, quote = [], None
    for ch in cmd:
        if quote:
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
        else:
            out.append(ch)
    return None if quote else "".join(out)


def single_plugin_call(cmd, cwd, script=None):
    """整個指令是不是只有「python 執行 plugin scripts/ 裡的一支程式」這一個呼叫（script 指定是哪一支）。
    串了其他指令、導向輸出、反引號或 $( ) 都不算。"""
    if "`" in cmd or "$(" in cmd:
        return False
    bare = outside_quotes(cmd)
    if bare is None or any(ch in SHELL_META for ch in bare):
        return False
    low = norm_cmd(cmd).strip()
    m = re.match(r"^(?:python3?|py)(?:\.exe)?(?:\s+-x\s+\S+)?\s+[\"']?([^\"']+?)[\"']?(?:\s|$)", low)
    if not m or "/scripts/" not in m.group(1) or not m.group(1).endswith(".py"):
        return False
    root, _, name = m.group(1).rpartition("/scripts/")
    if script and name != script:
        return False
    return root.rstrip("/") in {f.rstrip("/") for f in path_forms(PLUGIN_ROOT, cwd)}


def only_source_edit(cmd, cwd):
    """整個指令是不是只有「python 執行 plugin 的 scripts/source_edit.py」這一個呼叫（spec 4.6、5.5）。
    改原資料夾只能經由這支程式，所以放行它；串了其他指令就照一般規則判斷（串接的那段寫到來源照擋）。"""
    return single_plugin_call(cmd, cwd, SOURCE_EDIT.rsplit("/", 1)[-1])


# 只由 plugin 程式改的設定檔（init_kb.py、folders.py）：AI 直接改會繞過檢查、擴大讀取權限（0.10.1）
PROTECTED = ("admin/來源清單.json", ".claude/settings.json", ".claude/settings.local.json")
PROTECTED_MSG = ("已擋下：admin/來源清單.json 與 .claude/settings.json 只由 plugin 程式改（它們會檢查、備份）。"
                 "加資料夾、拿掉、改路徑、排除、改分區名稱，請照 query 技能〈管理資料夾〉用 folders.py。")


WORK_SCRIPT_MSG = ("已擋下：工作腳本不能碰來源或知識庫頁面，只能讀寫 .system/暫存/（{why}）。"
                   "要改的 Word、Excel 先用 office_check.py --複製到暫存 複製，在副本上改；存回來源用 source_edit.py（rules/office.md）。")
PY_FILE = re.compile(r"[\"']?((?:[A-Za-z]:)?[^\"'\s|;&<>]*\.py)[\"']?", re.IGNORECASE)


def work_scripts(cmd, cwd, kb):
    """指令裡要執行的 .py 中，放在總資料夾 .system/node/ 的（AI 寫的 Word、Excel 工作腳本，spec 4.9）。"""
    node = os.path.normcase(os.path.normpath(os.path.join(str(kb), ".system", "node")))
    return [p for p in (norm(m, cwd) for m in PY_FILE.findall(cmd)) if inside(p, node) and p != node]


def work_script_problem(path, kb, cwd):
    """工作腳本的內容提到來源資料夾、總資料夾的 wiki/ 或 admin/、{代號}/ 寫法時回傳原因；沒問題回傳 None。
    和指令的字串比對一樣是第二道防線：刻意把路徑拆開的程式碼擋不住（spec 5.5）。"""
    try:
        with open(long_path(path), encoding="utf-8", errors="replace") as f:
            raw = f.read()
    except OSError:
        return None  # 檔案不存在：python 自己會失敗
    low = norm_cmd(raw)
    srcs = load_sources(kb)["分區"]
    for s in srcs:
        if any(f in low for f in path_forms(s["路徑"], cwd) if len(f) > 3 and not f.startswith(".")):
            return f"腳本裡有來源資料夾「{s['名稱']}」的路徑"
        if "{" + s["代號"] + "}/" in raw:
            return f"腳本裡有 {{{s['代號']}}}/ 寫法"
    for f in path_forms(str(kb), cwd):
        base = f.rstrip("/")
        if len(base) > 3 and any(f"{base}/{d}/" in low for d in VAULT_DIRS):
            return "腳本裡有總資料夾 wiki/ 或 admin/ 的路徑"
    if re.search(r"[\"'](?:\.\./)*(?:wiki|admin)/", low):
        return "腳本裡有 wiki/ 或 admin/ 的路徑"
    return None


def deny(msg):
    sys.stderr.buffer.write(msg.encode("utf-8"))
    sys.exit(2)


NO_BACKUP = (".system/", ".claude/", "admin/改動紀錄.md", "admin/待處理.md", "admin/工作日誌/")


def backup(kb, rel):
    turn = current_turn(kb)
    entries = turn_entries(kb, turn)
    if any(e["路徑"] == rel for e in entries):
        return  # 這一回合已經備份過最初的版本
    if os.path.exists(long_path(kb / rel)) and is_synthesis(rel):
        n = sum(1 for e in entries if e["動作"] == "修改" and is_synthesis(e["路徑"]))
        if n >= BIG_CHANGE_PAGES:
            deny(f"已擋下：這個問題已經修改了 {n} 頁綜合頁（上限 {BIG_CHANGE_PAGES} 頁）。"
                 "問答時（query）：再改就是大改動，把其餘要改的頁面與原因寫進 admin/待處理.md 的「等你同意的改動」，告訴客戶，等客戶同意後再做。"
                 "維護時（ingest 更新、lint 每週檢查）：不算大改動，其餘的頁留到下次，不要寫進「等你同意的改動」，也不用問客戶。")
    backup_page(kb, rel, turn=turn, entries=entries)


def main():
    data = json.loads(sys.stdin.buffer.read().decode("utf-8"))
    cwd = data.get("cwd") or os.getcwd()
    tool = data.get("tool_name", "")
    ti = data.get("tool_input", {}) or {}
    target = ti.get("file_path") or ti.get("notebook_path") or ""

    kb = find_kb(cwd) or (find_kb(os.path.dirname(norm(target, cwd))) if target else None)
    if not kb and tool in ("Bash", "PowerShell"):
        # 不在總資料夾裡執行時，從指令中的絕對路徑找總資料夾
        for p in ABS_PATH.findall(ti.get("command", "")):
            kb = find_kb(os.path.dirname(norm(p, cwd)))
            if kb:
                break
    if not kb:
        return
    sources = [norm(s["路徑"], cwd) for s in load_sources(kb)["分區"]]

    if tool in FILE_TOOLS and target:
        t = norm(target, cwd)
        for s in sources:
            if inside(t, s):
                deny(f"已擋下：來源資料夾只能讀取。知識內容寫進 wiki/，給客戶的文件寫進成品區（{tool} 目標：{target}）。"
                     "客戶親口要求存進原本的資料夾、搬動、改名、改純文字檔時，照 query 技能〈改原資料夾〉用 source_edit.py。")
        kbn = os.path.normcase(str(kb))
        if inside(t, kbn):
            # normcase 會把路徑轉小寫，備份要用原始大小寫的相對路徑
            full = os.path.normpath(target if os.path.isabs(target) else os.path.join(cwd, target))
            rel = os.path.relpath(full, str(kb)).replace("\\", "/")
            if rel.lower() in (p.lower() for p in PROTECTED):
                deny(PROTECTED_MSG)
            if not any(rel == x or rel.startswith(x) for x in NO_BACKUP):
                backup(kb, rel)

    elif tool in ("Bash", "PowerShell"):
        cmd = ti.get("command", "")
        # 總資料夾的設定放行了「python 執行 plugin scripts/ 裡的程式」，不讓 .. 借這條規則跳到別的程式
        if PLUGIN_SCRIPTS_ESCAPE.search(norm_cmd(cmd)):
            deny("已擋下：執行 plugin 程式時路徑不能含「..」。請直接寫程式的完整路徑。")
        if only_source_edit(cmd, cwd):
            return  # 改原資料夾的程式：它自己檢查目標、備份、記錄
        # .system/node/ 的工作腳本是放行執行的（init_kb.py），執行前看一次內容（0.13.0）
        for p in work_scripts(cmd, cwd, kb):
            why = work_script_problem(p, kb, cwd)
            if why:
                deny(WORK_SCRIPT_MSG.format(why=why))
        cleaned = DISCARD_OUTPUT.sub(" ", cmd)
        bare = outside_quotes(cleaned)
        # 導向（>）只看引號外：引號裡的 > 是文字（例如 python -c 裡的正規表示式）；其他寫入動作整個指令都看（0.10.1）
        writes = WRITE_WORDS.search(cleaned) or REDIRECT.search(cleaned if bare is None else bare)
        if not writes:
            return
        low = norm_cmd(cmd)
        if any(p.lower() in low for p in PROTECTED) and not single_plugin_call(cmd, cwd):
            deny(PROTECTED_MSG)
        for s in sources:
            if any(f in low for f in path_forms(s, cwd)):
                deny("已擋下：這個指令提到來源資料夾且含寫入動作。來源資料夾只能讀取。知識內容寫進 wiki/，給客戶的文件寫進成品區。"
                     "客戶親口要求改原資料夾時，照 query 技能〈改原資料夾〉用 source_edit.py（一次一個指令，不要串接）。")
        if touches_vault_pages(low, kb, cwd):
            deny("已擋下：不要用指令或程式改總資料夾的頁面，因為掛鉤只在檔案工具寫入前備份，用指令改的頁面退不回來。"
                 "請改用 Edit 或 Write 工具（連「被引用於」這種小欄位也一樣）。plugin 附帶的程式不受影響。")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:  # 掛鉤本身出錯時放行，但留下紀錄
        try:
            kb = find_kb()
            if kb:
                with open(kb / HOOK_LOG, "a", encoding="utf-8") as f:
                    f.write(f"{datetime.now():%Y-%m-%d %H:%M} {type(e).__name__}: {e}\n")
        except Exception:
            pass
