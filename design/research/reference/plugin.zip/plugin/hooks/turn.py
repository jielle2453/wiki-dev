"""UserPromptSubmit 掛鉤：每個新問題開一個新的「回合」，並記進工作日誌。

同一回合裡對知識庫的所有改動，由 guard.py 備份到同一個版本資料夾，
因此「退回上一版」等於退回上一個問題造成的所有改動。
工作日誌（admin/工作日誌/）讓下一個對話知道之前問過什麼（spec 4.5）。
"""
import json
import os
import sys
from datetime import datetime

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from kbcommon import VERSIONS_DIR, append_journal, find_kb, write_json_atomic  # noqa: E402


def main():
    try:
        data = json.loads(sys.stdin.buffer.read().decode("utf-8"))
        kb = find_kb(data.get("cwd"))
        if not kb:
            return
        # 系統自動送入的訊息（背景工作完成通知、排程等）不是新問題，不開新回合
        if data.get("source") not in (None, "user", "sdk"):
            return
        prompt = " ".join((data.get("prompt") or "").split())
        # 背景代理（例如製卡）做完時送進來的通知也會觸發這個掛鉤，不是客戶的問題：不開回合、不記日誌（0.10.1）
        if prompt.startswith("<task-notification"):
            return
        write_json_atomic(kb / VERSIONS_DIR / ".目前回合.json", {
            "代號": datetime.now().strftime("%Y%m%d-%H%M%S"),
            "問題": prompt[:80],
        })
        if prompt:
            append_journal(kb, "問", prompt[:80])
    except Exception:
        pass  # 掛鉤出錯不能擋住客戶提問


if __name__ == "__main__":
    main()
