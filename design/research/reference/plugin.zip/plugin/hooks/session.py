"""SessionStart 掛鉤：開新對話時帶入接續資訊、快速比對來源資料夾、看距離上次健檢幾天；摺疊後補回規則。

開新對話、接續、清空（startup、resume、clear）：
  只比修改時間與大小（必要時才算指紋），不改任何檔案；再帶入〈做到一半的事〉與最近幾筆工作日誌。
  有資料夾變動才用標頭【LLM-wiki 自動檢查】（會叫起 ingest）；只有健檢提醒或接續資訊時用【LLM-wiki 接續資訊】。
  什麼都沒有時完全安靜。變動由 ingest 處理（先回答客戶的第一個問題再做）；健檢到期只請 AI 在回答末尾問客戶，客戶說好才由 lint 做。
摺疊後（compact）：核心規則不會自動回來，提醒 AI 重讀；帶入〈做到一半的事〉；不重跑比對（spec 4.5）。
"""
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from changes import detect, has_notice, report  # noqa: E402
from health import DUE_DAYS, days_since  # noqa: E402
from kbcommon import HOOK_LOG, find_kb, now_str, open_items, recent_journal  # noqa: E402

PLUGIN = os.path.normpath(os.path.join(HERE, "..")).replace("\\", "/")
JOURNAL_LINES = 5
LONG_DAYS = 30  # 超過這麼久沒健檢，提醒時多加一句（推估值）


def ongoing_lines(kb):
    rows = open_items(kb)
    if not rows:
        return []
    return ["做到一半的事（admin/待處理.md〈做到一半的事〉，表格欄位：時間｜事情｜下一步｜狀態）：", *rows]


# 對照規則（核心規則〈改動與紀錄〉的「接續」），開對話與摺疊後共用
MATCH = ("客戶只回編號（「1 對、2 不是」）而對話裡看不到題目 → 對照狀態「等客戶回覆」、事情以「問客戶：」開頭的最新一列；"
         "說「繼續」「接著做」→ 對照狀態「進行中」的最新一列。用一句話複述後在同一個回答裡接著做；"
         "刪除筆記只有明確的確認才做，回答含糊就只複述、這一輪不執行程式（ingest 技能〈客戶回答之後〉）。"
         "最新一列標〔改原資料夾〕〔管理資料夾〕時，只回「好」「可以」也算在答它（照 query 技能第七、八節；排除要客戶明確選一種）。")


def after_compact(kb):
    lines = [f"【LLM-wiki：對話剛摺疊 {now_str()}】",
             f"摺疊後核心規則已不在對話裡。回答前先重新讀 {PLUGIN}/rules/core-rules.md；"
             f"回答客戶的問題前重新讀 {PLUGIN}/skills/query/SKILL.md，要做更新時重新讀 {PLUGIN}/skills/ingest/SKILL.md、每週檢查時重新讀 {PLUGIN}/skills/lint/SKILL.md，兩者都要再讀 {PLUGIN}/rules/maintenance.md。"]
    lines += ongoing_lines(kb)
    lines.append(MATCH)
    lines.append("這個對話已經做過的那一種維護不要再開始（更新、每週檢查分開算，看 admin/改動紀錄.md 今天的行；客戶自己要求或答應檢查的除外）；"
                 "客戶已經對整理份數說「之後再說」也不要再整理。")
    lines.append("摺疊後不主動提健檢。摺疊前已在回答末尾問過要不要檢查、客戶這一句只回「好」「檢查」：當成答應檢查；"
                 "看不出在答什麼時先問客戶，不要拿〈做到一半的事〉的編號列來對照。")
    lines.append("在這次回答末尾加一句：「這段對話已經很長，建議開一個新的對話，我會記得要接著做的事。」只說這一次。")
    return lines


def at_start(kb):
    c = detect(kb, quick=True)
    days = days_since(kb)  # 沒有紀錄（建置還沒收尾）時是 None，不提醒
    changed = has_notice(c)
    due = days is not None and days >= DUE_DAYS
    ongoing = ongoing_lines(kb)
    journal = recent_journal(kb, JOURNAL_LINES)
    if not (changed or due or ongoing or journal):
        return []
    # 有資料夾變動才用【自動檢查】（會叫起 ingest）；健檢只是提醒，和接續資訊一樣不叫起維護技能（spec 4.4、4.5）
    lines = [f"【LLM-wiki 自動檢查 {now_str()}】" if changed else f"【LLM-wiki 接續資訊 {now_str()}】"]
    if changed:
        lines += ["客戶的來源資料夾和上次整理時不同：", *report(c),
                  "處理方式：客戶開口後，先照常回答他的第一個問題；回答完，依 llm-wiki 的 ingest 技能處理這些變動（會重新比對）。"
                  "整個資料夾找不到、原檔不見、要製卡超過 30 份時，依技能列入要問客戶的事；客戶說過要自己刪的不用問。"]
    if due:
        pending_check = any("每週檢查" in r for r in ongoing)
        lines.append(f"距離上次健檢已經 {days} 天。健檢不自動做：回答完在最後一行（有編號問題時放在編號問題之後、不編號）用一句話問客戶，例如"
                     f"「距離上次檢查筆記已經 {days} 天，要我現在檢查一下嗎？大約幾分鐘，會用掉一些用量。要的話回我『檢查』就好。」"
                     + ("已經滿 30 天，再加一句「已經很久沒檢查了，有些整理可能過時。」" if days >= LONG_DAYS else "")
                     + ("〈做到一半的事〉已有每週檢查的列，問一次就好，不要另外再問要不要接著做。" if pending_check else "")
                     + "這個對話已經提過、或客戶已經不要就不再提。客戶答應後（「檢查」；單獨的「好」照 rules/maintenance.md 判斷），"
                     "回覆他的那個回答依 lint 技能做。")
    if ongoing:
        lines += ongoing
        lines.append(MATCH)
        lines.append("客戶問別的事時：照常回答；狀態「進行中」的事，回答完用一句話問要不要接著做；「等客戶回覆」的不用主動再提。")
    if journal:
        lines += ["最近的工作日誌（只供參考；客戶提到之前的事才用，不要主動提起）：", *journal]
    return lines


def main():
    data = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}")
    kb = find_kb(data.get("cwd"))
    if not kb:
        return
    lines = after_compact(kb) if data.get("source") == "compact" else at_start(kb)
    if not lines:
        return
    out = {"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": "\n".join(lines)}}
    sys.stdout.write(json.dumps(out, ensure_ascii=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # 掛鉤出錯不能擋住客戶開對話，留下紀錄
        try:
            kb = find_kb()
            if kb:
                with open(kb / HOOK_LOG, "a", encoding="utf-8") as f:
                    f.write(f"{datetime.now():%Y-%m-%d %H:%M} session {type(e).__name__}: {e}\n")
        except Exception:
            pass
