"""轉換：把一份原檔轉成純文字，寫到 .system/暫存/，供 AI 製卡或核對。

- Word、PowerPoint、Excel 用 MarkItDown。
- PDF 逐頁轉換，每頁加 <!-- 第 N 頁 -->，並列出沒有文字層、需看圖辨識的頁；那幾頁用 pypdfium2（pdfplumber 附帶）
  轉成 PNG 放 .system/暫存/ 並印出路徑（最多前 20 頁），製卡代理用 Read 看圖（0.13.0，不再用 poppler）。
- 純文字自動判斷 UTF-8 或 Big5。
- onnxruntime 無法載入時（見 envcheck.py），改用 magika 替身，MarkItDown 退回用副檔名判斷格式。

畫面上只印出暫存檔位置與統計，不印內容。製卡完成後請刪除暫存檔。
最後印出「卡片頁首要加」的出處類別幾行（比對 AI 產出登記清單，ai_output.py，0.12.0）。

用法：python convert.py <{代號}/相對路徑 或 絕對路徑> [--知識庫 路徑]
結束碼：0 成功；3 無法轉換（原因印在最後一行）
"""
import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from kbcommon import ENV_FILE, TEMP_DIR, file_hash, long_path, read_json, require_kb, resolve_code_path, utf8_io, write_text_atomic  # noqa: E402

MIN_PAGE_CHARS = 10  # 少於這個字數的 PDF 頁視為掃描頁
BIG_CHARS = 60000    # 超過這個字數建議切子卡
MAX_IMAGE_PAGES = 20  # 掃描頁最多轉前 20 頁成圖片（spec 4.9；超過的讀取狀態標「部分」）
IMAGE_SCALE = 2.0     # 72 dpi × 2 = 144 dpi，看得清楚中文又不會太大


def onnx_ok(kb):
    env = read_json(kb / ENV_FILE, {}) or {}
    if "onnxruntime" in env:
        return env["onnxruntime"]
    r = subprocess.run([sys.executable, "-c", "import onnxruntime"], capture_output=True)
    return r.returncode == 0


def use_stub_if_needed(kb):
    """onnxruntime 無法載入時，在載入 MarkItDown 之前先換上 magika 替身。"""
    if not onnx_ok(kb) and os.path.join(HERE, "_magika_stub") not in sys.path:
        sys.path.insert(0, os.path.join(HERE, "_magika_stub"))


def convert_pdf(path, kb):
    import pdfplumber
    use_stub_if_needed(kb)
    try:
        from markitdown.converters._pdf_converter import _extract_form_content_from_words
    except ImportError:
        _extract_form_content_from_words = None
    parts, image_pages = [], []
    with pdfplumber.open(long_path(path)) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            text = None
            if _extract_form_content_from_words:
                try:
                    text = _extract_form_content_from_words(page)
                except Exception:
                    text = None
            if text is None:
                text = page.extract_text() or ""
            text = text.strip()
            if len(re.sub(r"\s", "", text)) < MIN_PAGE_CHARS:
                image_pages.append(i)
            parts.append(f"<!-- 第 {i} 頁 -->\n{text}")
            page.close()
    return "\n\n".join(parts), image_pages


def render_pages(pdf_path, pages, out_dir, stem, limit=MAX_IMAGE_PAGES):
    """用 pypdfium2 把 PDF 的指定頁（從 1 起算）轉成 PNG，回傳 [(頁碼, 圖片路徑)]。最多 limit 頁。
    不用 poppler（沒有數位簽章會被 Windows 智慧型應用程式控制擋下）、不用 PyMuPDF（AGPL）。"""
    import pypdfium2 as pdfium
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    done = []
    pdf = pdfium.PdfDocument(long_path(pdf_path))
    try:
        for n in pages[:limit]:
            if not 1 <= n <= len(pdf):
                continue
            page = pdf[n - 1]
            img = page.render(scale=IMAGE_SCALE).to_pil()
            dest = out_dir / f"{stem}_第{n}頁.png"
            img.save(long_path(dest))
            page.close()
            done.append((n, dest))
    finally:
        pdf.close()
    return done


def convert_text(path):
    raw = open(long_path(path), "rb").read()
    for enc in ("utf-8-sig", "cp950", "big5hkscs", "utf-16"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8（有無法辨識的字元）"


def convert_office(path, kb):
    use_stub_if_needed(kb)
    from markitdown import MarkItDown
    # 用長路徑開檔再交給 MarkItDown，避開路徑長度限制
    with open(long_path(path), "rb") as f:
        text = MarkItDown().convert_stream(f, file_extension=Path(path).suffix.lower()).text_content or ""
    if Path(path).suffix.lower() in (".xlsx", ".xls"):
        text = re.sub(r"\bNaN\b", "", text)            # 空格與沒有快取值的公式格
        text = re.sub(r"(?<=\d)\.0(?=\s*\|)", "", text)  # 360000.0 → 360000
    return text


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()

    kb = require_kb(a.kb)
    path = resolve_code_path(kb, a.file)
    ext = path.suffix.lower()
    if not os.path.exists(long_path(path)):
        print("無法轉換：找不到原檔")
        sys.exit(3)

    notes = []
    try:
        if ext == ".pdf":
            text, image_pages = convert_pdf(path, kb)
            if image_pages:
                notes.append(f"需看圖辨識的頁：{image_pages}")
        elif ext in (".txt", ".md", ".csv"):
            text, enc = convert_text(path)
            notes.append(f"編碼：{enc}")
        elif ext in (".docx", ".pptx", ".xlsx", ".xls"):
            text = convert_office(path, kb)
        elif ext == ".doc":
            print("無法轉換：舊版 Word（.doc）不支援，請客戶另存為 .docx")
            sys.exit(3)
        else:
            print(f"無法轉換：不支援的格式 {ext}")
            sys.exit(3)
    except Exception as e:
        msg = f"{type(e).__name__}: {e}"[:200]
        if "password" in msg.lower() or "encrypt" in msg.lower():
            print("無法轉換：檔案有密碼保護")
        else:
            print(f"無法轉換：{msg}")
        sys.exit(3)

    chars = len(re.sub(r"\s", "", text))
    digest = file_hash(path)
    if ext == ".pdf" and image_pages:
        try:
            imgs = render_pages(path, image_pages, kb / TEMP_DIR, digest[:12])
            notes.append("需看圖的頁已轉成圖片（用 Read 看，用完和暫存檔一起刪除）：")
            notes += [f"  第 {n} 頁：{p}" for n, p in imgs]
            if len(image_pages) > MAX_IMAGE_PAGES:
                notes.append(f"掃描頁超過 {MAX_IMAGE_PAGES} 頁：只轉了前 {MAX_IMAGE_PAGES} 頁，卡片讀取狀態標「部分」並註明沒看的頁")
        except Exception as e:  # 沒有 pypdfium2 或轉圖失敗：照實印出，製卡代理照「特殊情況」處理
            notes.append(f"需看圖的頁轉成圖片失敗（{type(e).__name__}: {str(e)[:120]}）")
    out = kb / TEMP_DIR / f"{digest[:12]}.md"
    write_text_atomic(out, text)
    headings = len(re.findall(r"^#{1,3} ", text, re.M))
    print(f"暫存檔：{out}")
    print(f"原檔目前的指紋：{digest}")
    print(f"字數：{chars}；標題 {headings} 個")
    if chars == 0 and ext != ".pdf":
        notes.append("轉換結果是空的")
    if chars > BIG_CHARS:
        notes.append("大檔：依 page-formats.md〈索引卡〉的切分規則，做一張主卡加依章節或工作表切開的子卡")
    for n in notes:
        print(n)
    # 出處類別（spec 4.8）：用剛轉好的文字比對 AI 產出登記清單，不看檔案放在哪裡
    from ai_output import header_lines, lookup
    print("卡片頁首要加（照抄，每行頂格寫、前面不要空白）：")
    for ln in header_lines(lookup(kb, path, text)):
        print(ln)


if __name__ == "__main__":
    main()
