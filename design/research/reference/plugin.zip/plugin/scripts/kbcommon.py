"""共用函式：找知識庫、讀來源清單、長路徑、指紋、安全寫檔、檔案鎖、改動前備份。

只用 Python 標準函式庫，掛鉤與各程式共用。
"""
import fnmatch
import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

# 總資料夾的結構（spec 3.2）：admin/ 管理文件、wiki/ 知識內容、.system/ 程式內部
ADMIN = Path("admin")
WIKI = Path("wiki")
SYSTEM = Path(".system")
SOURCES_FILE = ADMIN / "來源清單.json"
PENDING_FILE = ADMIN / "待處理.md"
CHANGELOG_FILE = ADMIN / "改動紀錄.md"
PROFILE_FILE = ADMIN / "客戶設定檔.md"
INVENTORY_FILE = SYSTEM / "檔案清冊.json"
ENV_FILE = SYSTEM / "環境.json"
TEMP_DIR = SYSTEM / "暫存"
VERSIONS_DIR = SYSTEM / "版本"
HOOK_LOG = SYSTEM / "掛鉤錯誤.log"
JOURNAL_DIR = ADMIN / "工作日誌"
DRAFT_DIR = SYSTEM / "草稿"   # 新文件的 Markdown 草稿（spec 4.9，0.13.0）；定稿後歸檔到 版本/<回合>/草稿/
NODE_DIR = SYSTEM / "node"    # npm 的 docx 套件與 docx 技能寫的 build.js（spec 4.9）

# AI 產出放在那一區來源最上層的這個資料夾（spec 4.9 議題 C）；照常盤點與製卡，不是保留名稱
AI_OUT_DIR = "AI 產出"
AI_OUT_IN = "資料夾內"
AI_OUT_CENTRAL = "中央"
# 雲端同步資料夾的路徑字樣（AI 產出預設放中央成品區）
CLOUD_WORDS = ("onedrive", "dropbox", "google drive", "googledrive", "雲端硬碟", "我的雲端硬碟", "icloud")
# 清冊狀態：AI 改過或產生的 Excel 還沒重算（沒有 Office、LibreOffice），batch.py 不取，客戶用 Excel 打開存檔後才製卡
RECALC_STATE = "公式待重算"

# 待處理.md 的五節（標題要和 skeleton/admin/待處理.md 一致）
PENDING_APPROVE = "等你同意的改動"
PENDING_UNREADABLE = "讀不到的檔案"
PENDING_UPDATE = "等更新的資料"
PENDING_STAFF = "等服務人員處理"
PENDING_ONGOING = "做到一半的事"
ONGOING_HEADER = ["| 時間 | 事情 | 下一步 | 狀態 |", "|---|---|---|---|"]
ONGOING_DONE = ("已完成", "已改問新的")

# 盤點時直接跳過的檔名（暫存檔、系統檔、捷徑）
SKIP_NAMES = ["~$*", ".~lock*", "*.tmp", "~*.tmp", "Thumbs.db", "desktop.ini", ".DS_Store", "*.lnk", "*.url"]
# 可以製卡的格式
SUPPORTED = {".docx", ".xlsx", ".xls", ".pptx", ".pdf", ".txt", ".md", ".csv"}

# Windows 檔案屬性：雲端占位檔（OneDrive 等「僅在線上」的檔案）
_RECALL_ON_OPEN = 0x40000
_RECALL_ON_DATA_ACCESS = 0x400000
_OFFLINE = 0x1000


def utf8_io():
    """讓輸出一律是 UTF-8，避免 Windows 主控台的字碼頁造成中文亂碼。"""
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def long_path(p):
    """Windows 加上 \\\\?\\ 前綴，避開 260 字元的路徑長度限制。"""
    s = os.path.abspath(str(p))
    if os.name != "nt" or s.startswith("\\\\?\\"):
        return s
    if s.startswith("\\\\"):
        return "\\\\?\\UNC\\" + s[2:]
    return "\\\\?\\" + s


def find_kb(start=None):
    """從 start（預設為目前資料夾）往上找含 admin/來源清單.json 的總資料夾。"""
    env = os.environ.get("LLMWIKI_KB")
    if env and (Path(env) / SOURCES_FILE).exists():
        return Path(env).resolve()
    p = Path(start or os.getcwd()).resolve()
    for d in [p, *p.parents]:
        if (d / SOURCES_FILE).exists():
            return d
    return None


def require_kb(arg=None):
    kb = Path(arg).resolve() if arg else find_kb()
    if not kb or not (kb / SOURCES_FILE).exists():
        sys.exit("找不到知識庫：請在知識庫資料夾內執行，或用 --知識庫 指定路徑。")
    return kb


def read_json(path, default=None):
    try:
        with open(long_path(path), encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def write_text_atomic(path, text):
    """先寫暫存檔，完成後才取代正式檔，避免寫一半壞掉。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=long_path(path.parent), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    for i in range(20):
        try:
            os.replace(tmp, long_path(path))
            return
        except PermissionError:
            # Windows 上防毒、索引或另一支程式剛好在讀這個檔時會暫時被拒，稍等再試（約 2 秒）
            if i == 19:
                os.remove(tmp)
                raise
            time.sleep(0.1)


def write_json_atomic(path, data):
    write_text_atomic(path, json.dumps(data, ensure_ascii=False, indent=1))


class FileLock:
    """以「建立鎖檔」實作的簡單檔案鎖，讓平行的製卡代理不會同時改清冊。"""

    def __init__(self, path, timeout=60):
        self.path = long_path(str(path) + ".lock")
        self.timeout = timeout

    def __enter__(self):
        start = time.time()
        while True:
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                return self
            except FileExistsError:
                # 超過十分鐘的鎖視為殘留（程式中途被中斷）
                try:
                    if time.time() - os.path.getmtime(self.path) > 600:
                        os.remove(self.path)
                        continue
                except FileNotFoundError:
                    continue
                if time.time() - start > self.timeout:
                    sys.exit(f"等待檔案鎖逾時：{self.path}")
                time.sleep(0.1)

    def __exit__(self, *exc):
        os.close(self.fd)
        try:
            os.remove(self.path)
        except FileNotFoundError:
            pass


def load_sources(kb):
    """回傳 {"分區": [{"名稱","代號","路徑","說明","共用"}], "排除": [規則], "成品區": 路徑}。"""
    data = read_json(kb / SOURCES_FILE, {}) or {}
    data.setdefault("分區", [])
    data.setdefault("排除", [])
    data.setdefault("成品區", "")
    return data


def append_pending(kb, section, row):
    """在 待處理.md 指定那一節的表格最後加一列。找不到該節時加在檔尾。"""
    path = kb / PENDING_FILE
    with FileLock(path):
        lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else ["# 待處理", ""]
        try:
            i = next(n for n, ln in enumerate(lines) if ln.strip() == f"## {section}")
        except StopIteration:
            lines += ["", f"## {section}", ""]
            i = len(lines) - 2
        # 找到這一節表格的最後一列（遇到下一節為止）
        insert_at = i + 1
        j = i + 1
        while j < len(lines) and not lines[j].startswith("## "):
            if lines[j].startswith("|"):
                insert_at = j + 1
            j += 1
        lines.insert(insert_at, row)
        write_text_atomic(path, "\n".join(lines) + "\n")


def ensure_ongoing_section(kb):
    """0.6.0 以前建的總資料夾沒有〈做到一半的事〉，補在檔尾（已有就不動）。"""
    path = kb / PENDING_FILE
    if not path.exists():
        return
    with FileLock(path):
        text = path.read_text(encoding="utf-8")
        if f"## {PENDING_ONGOING}" in text:
            return
        add = ["", f"## {PENDING_ONGOING}", "",
               "還沒結束的事，換對話或對話摺疊後接著做。做完改為「已完成」；問了新的一組問題時，舊的一組改為「已改問新的」。", "", *ONGOING_HEADER]
        write_text_atomic(path, text.rstrip("\n") + "\n" + "\n".join(add) + "\n")


def open_items(kb):
    """〈做到一半的事〉還沒結束的列（原文）。"""
    path = kb / PENDING_FILE
    if not path.exists():
        return []
    rows, inside = [], False
    for ln in path.read_text(encoding="utf-8").splitlines():
        if ln.startswith("## "):
            inside = ln.strip() == f"## {PENDING_ONGOING}"
            continue
        if not inside or not ln.startswith("|") or ln in ONGOING_HEADER or set(ln) <= set("|-: "):
            continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if cells and cells[0] == "時間":
            continue
        if cells and not any(cells[-1].startswith(d) for d in ONGOING_DONE):
            rows.append(ln.strip())
    return rows


def journal_file(kb, when=None):
    return kb / JOURNAL_DIR / f"{(when or datetime.now()):%Y-%m}.md"


def append_journal(kb, kind, text):
    """工作日誌加一行：[時間] 類別｜內容。一個月一份。"""
    path = journal_file(kb)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = " ".join(str(text).split())
    with FileLock(path, timeout=5):  # 掛鉤裡呼叫，不能等太久
        head = "" if path.exists() else (
            f"# 工作日誌 {datetime.now():%Y-%m}\n\n"
            "每個問題一行（掛鉤自動寫）；有後續的事 AI 補一行「結果」。只往下加，不要改舊的行。\n\n")
        with open(long_path(path), "a", encoding="utf-8") as f:
            f.write(f"{head}[{now_str()}] {kind}｜{text}\n")


def recent_journal(kb, n=5):
    """最近 n 筆工作日誌（這個月不夠時往前一個月找）。"""
    d = kb / JOURNAL_DIR
    if not d.is_dir():
        return []
    lines = []
    for f in sorted(d.glob("*.md"), reverse=True)[:2]:
        got = [ln for ln in f.read_text(encoding="utf-8").splitlines() if ln.startswith("[")]
        lines = got + lines
        if len(lines) >= n:
            break
    return lines[-n:]


def current_turn(kb):
    """目前的回合（UserPromptSubmit 掛鉤在客戶每次提問時寫入）；沒有就開一個。"""
    turn_file = kb / VERSIONS_DIR / ".目前回合.json"
    try:
        with open(long_path(turn_file), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        turn = {"代號": datetime.now().strftime("%Y%m%d-%H%M%S"), "問題": ""}
        write_json_atomic(turn_file, turn)
        return turn


def turn_entries(kb, turn):
    m = kb / VERSIONS_DIR / turn["代號"] / "清單.jsonl"
    if not m.exists():
        return []
    with open(long_path(m), encoding="utf-8") as f:
        return [json.loads(ln) for ln in f if ln.strip()]


BIG_CHANGE_PAGES = 10  # 一個問題最多改幾頁既有的綜合頁（掛鉤 guard.py 攔截）


def is_synthesis(rel):
    """wiki/跨區綜合/… 或 wiki/<分區>/綜合/…"""
    parts = rel.split("/")
    return parts[0] == "wiki" and len(parts) > 2 and (parts[1] == "跨區綜合" or parts[2] == "綜合")


def synthesis_used(kb):
    """這一次（目前回合）已經修改的既有綜合頁數。同一頁改幾次都只算一次；新增的頁、卡片、admin 不算。"""
    turn = read_json(kb / VERSIONS_DIR / ".目前回合.json")
    if not turn or "代號" not in turn:
        return 0
    return sum(1 for e in turn_entries(kb, turn) if e["動作"] == "修改" and is_synthesis(e["路徑"]))


def stat_entry(code, rel, path):
    """清冊一筆的基本欄位，算法和 inventory.scan 相同（修改時間取到 0.1 秒）。"""
    st = os.stat(long_path(path))
    return {"分區": code, "副檔名": Path(rel).suffix.lower(), "大小": st.st_size, "修改時間": round(st.st_mtime, 1)}, st


def budget_line(kb):
    n = synthesis_used(kb)
    return (f"改綜合頁的額度：這個回答已改 {n}/{BIG_CHANGE_PAGES} 頁"
            f"（只算既有的綜合頁；這一次已改過的頁再改不另算）")


def backup_page(kb, rel, action=None, turn=None, entries=None):
    """改動總資料夾的頁面前，把舊版複製到 .system/版本/<回合代號>/檔案/，並在 清單.jsonl 記一行。

    同一回合同一頁只備份第一次（保留最初的版本）。action 預設依頁面是否存在為「修改」或「新增」；
    刪除頁面前傳「刪除」（退回時和「修改」一樣複製回去）。掛鉤 guard.py 與會改頁面的程式共用。
    """
    turn = turn or current_turn(kb)
    entries = turn_entries(kb, turn) if entries is None else entries
    if any(e["路徑"] == rel for e in entries):
        return
    target = kb / rel
    exists = os.path.exists(long_path(target))
    action = action or ("修改" if exists else "新增")
    vdir = turn_dir(kb, turn)
    if exists:
        dst = vdir / "檔案" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(long_path(target), long_path(dst))
    append_turn_entry(kb, turn, {"路徑": rel, "動作": action})


def turn_dir(kb, turn):
    """這一回合的版本資料夾（第一次用到時建立，並寫下時間與問題）。"""
    vdir = kb / VERSIONS_DIR / turn["代號"]
    vdir.mkdir(parents=True, exist_ok=True)
    if not (vdir / "說明.json").exists():
        write_json_atomic(vdir / "說明.json", {"時間": now_str(), "問題": turn.get("問題", "")})
    return vdir


def append_turn_entry(kb, turn, entry):
    """在這一回合的 清單.jsonl 加一行。每一行都要有「路徑」「動作」。"""
    with open(long_path(turn_dir(kb, turn) / "清單.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


SOURCE_ACTIONS = ("來源新增", "來源搬動", "來源覆蓋")  # source_edit.py 記進回合的動作（4.6）


DRAFT_ACTIONS = ("草稿歸檔",)  # ai_output.py 定稿（4.9）：退回時草稿搬回 .system/草稿/


FOLDER_ACTIONS = ("資料夾加入", "資料夾拿掉", "資料夾改路徑", "資料夾排除", "資料夾取消排除", "分區改名")  # folders.py（4.7）
RESERVED_NAMES = ("跨區綜合", "跨區")  # wiki/ 與成品區裡已經用掉的資料夾名稱


def _within(child, parent):
    c = os.path.normcase(os.path.abspath(str(child)))
    p = os.path.normcase(os.path.abspath(str(parent))).rstrip("\\/")
    return c == p or c.startswith(p + os.sep)


def system_dirs():
    env = os.environ
    cands = [env.get("SystemRoot") or r"C:\Windows", env.get("ProgramFiles"), env.get("ProgramFiles(x86)"),
             env.get("ProgramData"), os.path.join(str(Path.home()), "AppData")]
    return [c for c in cands if c]


def path_problems(kb, sources, path, ignore_code=None):
    """來源資料夾不能放的地方（spec 4.7〈安全措施〉由程式擋下的四種）。回傳原因清單，空的表示可以。
    folders.py 與 init_kb.py 共用。ignore_code：改路徑時不跟自己那一區比。"""
    p = os.path.abspath(str(path))
    reasons = []
    if os.path.splitdrive(p)[1].strip("\\/") == "":
        reasons.append("整顆磁碟不能當來源資料夾，請指定裡面的資料夾")
    for s in system_dirs():
        if _within(p, s) or _within(s, p):
            reasons.append(f"系統資料夾（{s}）不能當來源，也不能包住它")
            break
    if kb and (_within(p, kb) or _within(kb, p)):
        reasons.append("總資料夾和來源資料夾不能互相包含")
    out = sources.get("成品區")
    if out and (_within(p, out) or _within(out, p)):
        reasons.append("成品區和來源資料夾不能互相包含")
    for s in sources.get("分區", []):
        if s["代號"] == ignore_code:
            continue
        if _within(p, s["路徑"]) or _within(s["路徑"], p):
            reasons.append(f"和既有分區「{s['名稱']}」（{s['路徑']}）重疊，同一份檔案會有兩張卡。"
                           "資料夾搬家請用「改路徑」；要細分請在那一區裡建子資料夾")
    return reasons


def free_code(sources, code, ignore=None):
    """代號和既有分區重複時自動換一個（加 2、3……），不取代舊分區。"""
    used = {s["代號"] for s in sources.get("分區", []) if s["代號"] != ignore}
    if code not in used:
        return code
    i = 2
    while f"{code}{i}" in used:
        i += 1
    return f"{code}{i}"


# ---- 客戶設定檔的推測表格（0.11.0 加「依據」欄，決策 #41）----
GUESS_TABLES = ("詞彙表", "文件類型", "重要的人與組織", "專案或案件")
BASIS = "依據"


def split_basis(cell):
    """依據欄：最多 3 份原檔的 {代號}/相對路徑，用「、」分開。檔名裡也可能有「、」，所以用「{」切。"""
    return [("{" + x).strip().rstrip("、").strip() for x in str(cell).split("{")[1:] if x.strip()]


def card_texts(kb):
    """所有卡片的全文（頁首加內文），轉小寫，給「卡片有沒有提到」用。"""
    return [c.read_text(encoding="utf-8").lower() for c in (kb / WIKI).glob("*/卡片/*.md")]


def mentioned(name, texts):
    """推測條目的名稱（表格第一欄：說法、類型、名稱）有沒有出現在任何一張卡片的頁首或內文（不分大小寫的英文）。
    健檢第 10 項與隱私排除共用這個判斷（0.11.0）。"""
    n = str(name).strip().lower()
    return bool(n) and any(n in t for t in texts)


def _cells(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def edit_profile_tables(text, fn, tables=GUESS_TABLES):
    """逐列處理設定檔指定表格的資料列。fn(表名, 欄位 dict, 原本的 cells) 回傳 None（不動）、False（刪掉這列）
    或新的 cells。欄位 dict 用表頭當鍵（例如「依據」「來源」）。回傳新的文字。"""
    out, table, header = [], None, None
    for ln in text.split("\n"):
        if ln.startswith("## "):
            table, header = ln[3:].strip(), None
            out.append(ln)
            continue
        if table in tables and ln.startswith("|"):
            cells = _cells(ln)
            if header is None:
                header = cells
            elif not set(ln.strip()) <= set("|-: "):
                res = fn(table, dict(zip(header, cells)), cells)
                if res is False:
                    continue
                if res is not None:
                    ln = "| " + " | ".join(res) + " |"
        out.append(ln)
    return "\n".join(out)


def add_basis_column(text):
    """舊的設定檔（0.11.0 以前）推測表格沒有「依據」欄：插在「來源」前面，舊的列留空。已經有就不動。"""
    out, table, row = [], None, 0
    for ln in text.split("\n"):
        if ln.startswith("## "):
            table, row = ln[3:].strip(), 0
        elif table in GUESS_TABLES and ln.startswith("|"):
            cells = _cells(ln)
            row += 1
            if row == 1:
                if BASIS in cells:
                    table = None  # 這一表已經是新格式
                else:
                    cells.insert(len(cells) - 1, BASIS)
                    ln = "| " + " | ".join(cells) + " |"
            elif row == 2 and set(ln.strip()) <= set("|-: "):
                ln = "|" + "---|" * (len(cells) + 1)
            else:
                cells.insert(len(cells) - 1, "")
                ln = "| " + " | ".join(cells) + " |"
        out.append(ln)
    return "\n".join(out)


def is_shared(section):
    """來源清單的分區是否和別人共用；0.9.0 以前沒有這欄，當作「否」。"""
    return str(section.get("共用", "否")).strip().lower() in ("是", "yes", "true")


def is_cloud_path(path):
    """來源路徑在雲端同步資料夾裡（OneDrive、Dropbox、Google 雲端硬碟等）。"""
    p = str(path).lower().replace("\\", "/")
    return any(w in p for w in CLOUD_WORDS)


def ai_out_mode(section, files=None):
    """這一區的 AI 產出放哪：「資料夾內」（來源最上層的 AI 產出/）或「中央」（成品區）。
    來源清單有寫「AI 產出放哪」就照寫；沒寫（0.13.0 以前）照預設：共用、雲端同步資料夾（路徑字樣，
    或清冊裡這一區有只在雲端的占位檔）→ 中央；其他 → 資料夾內（spec 4.9）。"""
    v = str(section.get("AI 產出放哪", "")).strip()
    if v in (AI_OUT_IN, AI_OUT_CENTRAL):
        return v
    return default_ai_out(section, files)


def default_ai_out(section, files=None):
    if is_shared(section) or is_cloud_path(section.get("路徑", "")):
        return AI_OUT_CENTRAL
    if files and any(e.get("分區") == section.get("代號") and e.get("狀態") == "雲端占位" for e in files.values()):
        return AI_OUT_CENTRAL
    return AI_OUT_IN


def needs_recalc(path):
    """Excel 檔要不要重算才能讀到正確的公式結果：設了「打開時全部重算」（office_tools.py 沒有工具時設的），
    或有公式格沒有快取值（openpyxl 寫的檔）。不是 Excel、打不開時回傳 False。只讀壓縮檔裡的 XML。"""
    import re
    import zipfile
    if Path(path).suffix.lower() not in (".xlsx", ".xlsm"):
        return False
    try:
        with zipfile.ZipFile(long_path(path)) as z:
            names = z.namelist()
            wb = z.read("xl/workbook.xml").decode("utf-8", "ignore") if "xl/workbook.xml" in names else ""
            if re.search(r"<(?:\w+:)?calcPr\b[^>]*\bfullCalcOnLoad=\"(?:1|true)\"", wb):
                return True
            for n in names:
                if re.match(r"xl/worksheets/sheet\d+\.xml$", n):
                    x = z.read(n).decode("utf-8", "ignore")
                    for cell in re.findall(r"<c\b[^>]*?(?<!/)>(.*?)</c>", x, re.S):
                        if re.search(r"<f\b", cell) and not re.search(r"<v>[^<]*</v>", cell):
                            return True
    except (OSError, zipfile.BadZipFile, KeyError):
        return False
    return False


def file_hash(path):
    h = hashlib.sha256()
    with open(long_path(path), "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def is_cloud_placeholder(st):
    attrs = getattr(st, "st_file_attributes", 0)
    return bool(attrs & (_RECALL_ON_OPEN | _RECALL_ON_DATA_ACCESS | _OFFLINE))


def is_skipped_name(name):
    return any(fnmatch.fnmatch(name.lower(), pat.lower()) for pat in SKIP_NAMES)


def is_excluded(rel, rules, code=None):
    """rel 是分區內的相對路徑（以 / 分隔）。規則可比對整段路徑或任一層名稱，套用到所有分區；
    寫成 {代號}/相對路徑 的規則只套用到那一區（0.10.0，folders.py 排除寫的就是這種）。"""
    parts = rel.split("/")
    for r in rules:
        r = r.strip().replace("\\", "/").rstrip("/")
        if r.startswith("{"):
            rc, sep, rr = r[1:].partition("}/")
            if not sep or rc != code:
                continue
            if rel == rr or rel.startswith(rr + "/") or fnmatch.fnmatch(rel, rr):
                return True
            continue
        if not r:
            continue
        if fnmatch.fnmatch(rel, r) or rel == r or rel.startswith(r + "/"):
            return True
        if any(fnmatch.fnmatch(p, r) for p in parts):
            return True
    return False


def code_path(code, rel):
    """卡片中記錄原檔的寫法：{分區代號}/相對路徑。"""
    return "{" + code + "}/" + rel


def resolve_code_path(kb, cp, sources=None):
    """把 {代號}/相對路徑 換成實際路徑；已經是絕對路徑就原樣回傳。"""
    if not cp.startswith("{"):
        return Path(cp)
    code, _, rel = cp[1:].partition("}/")
    for s in (sources or load_sources(kb))["分區"]:
        if s["代號"] == code:
            return Path(s["路徑"]) / rel
    raise KeyError(f"來源清單沒有分區代號 {code}")


def section_dir(kb, code, sources=None):
    for s in (sources or load_sources(kb))["分區"]:
        if s["代號"] == code:
            return kb / WIKI / s["名稱"]
    raise KeyError(f"來源清單沒有分區代號 {code}")


def safe_name(name):
    bad = '<>:"/\\|?*'
    return "".join("_" if c in bad or ord(c) < 32 else c for c in name).strip(" .")


def card_name(rel, digest):
    """卡片檔名：原檔名＿指紋前四碼.md。原檔搬動時檔名不變。"""
    stem = Path(rel).stem
    return f"{safe_name(stem)[:80]}＿{digest[:4]}.md"


# ---- 卡片頁首（只支援本 plugin 自己寫出的簡單格式）----

def parse_front_matter(text):
    """解析 --- 包住的頁首。值可以是字串、"引號字串" 或 [a, b] 清單。"""
    if not text.startswith("---"):
        return {}
    end = text.find("\n---", 3)
    if end < 0:
        return {}
    meta = {}
    for line in text[3:end].splitlines():
        if ":" not in line or line.startswith((" ", "\t", "#")):
            continue
        k, _, v = line.partition(":")
        meta[k.strip()] = _parse_value(v.strip())
    return meta


def _parse_value(v):
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        return [_unquote(x.strip()) for x in _split_list(inner)] if inner else []
    return _unquote(v)


def _split_list(s):
    out, cur, q = [], "", None
    for c in s:
        if q:
            cur += c
            if c == q:
                q = None
        elif c in "\"'":
            q = c
            cur += c
        elif c in ",、":
            out.append(cur)
            cur = ""
        else:
            cur += c
    out.append(cur)
    return [x for x in out if x.strip()]


def _unquote(v):
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    return v


def fm_value(v):
    """把值寫成頁首格式：清單寫成 [a, b]；含冒號、大括號、逗號的值加雙引號。"""
    def one(x):
        x = str(x)
        return f'"{x}"' if any(c in x for c in ':{}[],、') else x
    if isinstance(v, list):
        return "[" + ", ".join(one(x) for x in v) + "]"
    return one(v)


def set_front_matter(text, key, value):
    """只改頁首某一欄那一行；欄位不存在時加在頁首最後。"""
    if not text.startswith("---"):
        return text
    end = text.find("\n---", 3)
    if end < 0:
        return text
    head = text[:end].split("\n")
    for i, ln in enumerate(head[1:], 1):
        if not ln.startswith((" ", "\t")) and ln.split(":", 1)[0].strip() == key:
            cr = "\r" if ln.endswith("\r") else ""
            head[i] = f"{key}: {fm_value(value)}{cr}"
            break
    else:
        head.append(f"{key}: {fm_value(value)}")
    return "\n".join(head) + text[end:]
