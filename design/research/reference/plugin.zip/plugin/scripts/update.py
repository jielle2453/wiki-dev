"""更新：把來源資料夾的變動套用到知識庫。製卡本身由 card-maker 代理做（batch.py 下一批）。

會改頁面的步驟都先用 backup_page 備份，客戶說「退回上一版」時一起退回。

用法：
  python update.py 套用                          更新清冊；搬動的卡片改寫原檔位置；原檔變了的綜合頁標為待更新；
                                                 客戶說要自己刪（預期刪除）、已經不見的直接刪卡片
  python update.py 刪除 <{代號}/相對路徑> ...      客戶確認是自己刪的：刪卡片、綜合頁的出處標「原檔已刪除」
  python update.py 保留 <{代號}/相對路徑> ...      客戶說不是他刪的：卡片不動，之後不再問
"""
import argparse
import os
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from health import note_unfinished_toc, stale_pages  # noqa: E402
from inventory import scan  # noqa: E402
from kbcommon import (INVENTORY_FILE, WIKI, FileLock, backup_page, budget_line, load_sources, long_path,  # noqa: E402
                      now_str, parse_front_matter, read_json, require_kb, set_front_matter, utf8_io,
                      write_json_atomic, write_text_atomic)

LINK = re.compile(r"\[([^\]]*)\]\(<?([^)>]+)>?\)")
SHOW = 15


def read(p):
    return Path(long_path(p)).read_text(encoding="utf-8")


def card_family(kb, card):
    """主卡加上它的子卡（檔名為主卡檔名去掉 .md 再加「－部分名稱.md」），回傳以總資料夾為準的路徑。"""
    main = kb / card
    out = [card] if main.exists() else []
    if main.parent.is_dir():  # 不用 glob：檔名裡的 [ ] 會被當成萬用字元
        prefix = main.stem + "－"
        out += sorted(p.relative_to(kb).as_posix() for p in main.parent.iterdir()
                      if p.name.startswith(prefix) and p.suffix == ".md")
    return out


def synthesis_pages(kb):
    w = kb / WIKI
    pages = list((w / "跨區綜合").glob("*.md"))
    for d in w.iterdir() if w.exists() else []:
        if d.is_dir() and (d / "綜合").is_dir():
            pages += list((d / "綜合").glob("*.md"))
    return pages


def link_hits(target, names):
    t = unquote(target.split("#")[0].strip()).replace("\\", "/")
    parts = t.rsplit("/", 2)
    return len(parts) >= 2 and parts[-2] == "卡片" and parts[-1] in names


def cites(text, names):
    """綜合頁是否引用了這些卡片（內文連結或頁首的「引用的卡片」）。"""
    m = parse_front_matter(text)
    if any(Path(str(c)).name in names for c in (m.get("引用的卡片") or [])):
        return True
    return any(link_hits(t, names) for _, t in LINK.findall(text))


def sync_card_paths(kb, files):
    """卡片頁首的「原檔」「其他位置」跟清冊不一致時改成清冊的值（搬動、改名、重複檔變動）。"""
    changed = []
    for cp, e in files.items():
        if e["狀態"] not in ("完成", "已變動") or not e.get("卡片"):
            continue
        others = e.get("其他位置", [])
        for card in card_family(kb, e["卡片"]):
            text = read(kb / card)
            m = parse_front_matter(text)
            new = text
            if "原檔" in m and m["原檔"] != cp:
                new = set_front_matter(new, "原檔", cp)
            is_main = card == e["卡片"]
            if ("其他位置" in m or (is_main and others)) and (m.get("其他位置") or []) != others:
                new = set_front_matter(new, "其他位置", others)
            if new != text:
                backup_page(kb, card)
                write_text_atomic(kb / card, new)
                changed.append(card)
    return changed


def mark_stale(kb, cards):
    """引用了這些卡片的綜合頁標為「待更新」。客戶確認過的不改（大改動），另外列出。"""
    names = {Path(c).name for c in cards}
    marked, confirmed = [], []
    if not names:
        return marked, confirmed
    for p in synthesis_pages(kb):
        text = read(p)
        if not cites(text, names):
            continue
        rel = p.relative_to(kb).as_posix()
        status = str(parse_front_matter(text).get("狀態", ""))
        if status.startswith("客戶確認"):
            confirmed.append(rel)
        elif status not in ("待更新", "已停用"):
            backup_page(kb, rel)
            write_text_atomic(p, set_front_matter(text, "狀態", "待更新"))
            marked.append(rel)
    return marked, confirmed


def annotate_deleted(kb, cards, note="原檔已刪除"):
    """綜合頁裡連到這些卡片的出處改成「名稱（原檔已刪除）」，並從「引用的卡片」拿掉。"""
    names = {Path(c).name for c in cards}
    pages = []
    for p in synthesis_pages(kb):
        text = read(p)
        if not cites(text, names):
            continue
        new = LINK.sub(lambda m: f"{m.group(1)}（{note}）" if link_hits(m.group(2), names) else m.group(0), text)
        refs = parse_front_matter(new).get("引用的卡片")
        if isinstance(refs, list):
            new = set_front_matter(new, "引用的卡片", [c for c in refs if Path(str(c)).name not in names])
        if new != text:
            rel = p.relative_to(kb).as_posix()
            backup_page(kb, rel)
            write_text_atomic(p, new)
            pages.append(rel)
    return pages


def remove_notes(kb, e, note="原檔已刪除"):
    """拿掉一份原檔的筆記：綜合頁的出處加註、卡片（含子卡）先備份再刪除，清冊那一筆改為「已刪除」。
    回傳 (刪除的卡片, 改過的綜合頁)。呼叫的人要拿著清冊的鎖，並自己寫回清冊、重建索引。"""
    cards = card_family(kb, e["卡片"]) if e.get("卡片") else []
    pages = annotate_deleted(kb, cards, note)
    for c in cards:
        backup_page(kb, c, "刪除")
        os.remove(long_path(kb / c))
    e["狀態"] = "已刪除"
    e.pop("預期刪除", None)
    return cards, pages


def reindex(kb):
    subprocess.run([sys.executable, os.path.join(HERE, "reindex.py"), "--知識庫", str(kb)], stdout=subprocess.DEVNULL)


def remove_expected(kb):
    """客戶說要自己刪（source_edit.py 預期刪除）、現在真的不見的檔案：直接拿掉筆記，不再問（spec 4.6）。"""
    inv_path = kb / INVENTORY_FILE
    done, removed = [], []
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        for cp, e in sorted(inv["檔案"].items()):
            if e["狀態"] == "預期刪除":
                cards, _ = remove_notes(kb, e)
                removed += cards
                done.append(cp)
        if done:
            write_json_atomic(inv_path, inv)
    if removed:
        reindex(kb)
    return done


def show(label, items):
    if items:
        more = f"……等 {len(items)} 個" if len(items) > SHOW else ""
        print(f"- {label} {len(items)}：" + "、".join(items[:SHOW]) + more)


def apply(kb):
    sources = load_sources(kb)
    inv_path = kb / INVENTORY_FILE
    if not inv_path.exists():
        print("還沒有清冊（建置還沒盤點），不處理。")
        return
    with FileLock(inv_path):
        old = (read_json(inv_path, {}) or {}).get("檔案", {})
        r = scan(sources, old)
        write_json_atomic(inv_path, {"更新時間": now_str(), "檔案": r["檔案"]})
    files = r["檔案"]
    expected = remove_expected(kb)
    moved_cards = sync_card_paths(kb, files)
    stale_cards = [c for e in files.values() if e["狀態"] == "已變動" and e.get("卡片")
                   for c in card_family(kb, e["卡片"])]
    marked, confirmed = mark_stale(kb, stale_cards)

    st = Counter(e["狀態"] for e in files.values())
    print("已套用變動（清冊已更新）：")
    print(f"- 要製卡 {st['待處理'] + st['已變動'] + st['處理中']} 份"
          f"（新檔 {st['待處理']}、原檔改過 {st['已變動']}、處理中 {st['處理中']}）")
    show("搬動或改名，卡片已改寫原檔位置", [f"{a} → {b}" for a, b in r["搬動"]])
    if moved_cards and not r["搬動"]:
        show("卡片的原檔位置已校正", moved_cards)
    show("原檔不見、要問客戶", sorted(cp for cp, e in files.items() if e["狀態"] == "原檔已不存在"))
    show("客戶說要自己刪、已經刪掉的檔案，筆記已拿掉（不用再問；出處標「原檔已刪除」）", expected)
    show("整個來源資料夾找不到（這一區的紀錄沒有動）", [f"{s['名稱']}（{s['路徑']}）" for s in r["不見的分區"]])
    show("只在雲端、還沒下載", sorted(cp for cp, e in files.items() if e["狀態"] == "雲端占位"
                                and old.get(cp, {}).get("狀態") != "雲端占位"))
    show("排除規則涵蓋、已做過卡片（服務人員處理）", sorted(cp for cp, e in files.items() if e["狀態"] == "已排除"))
    show("待更新的綜合頁（含之前標的；製卡完成後再看一次註記）", [r + n for r, n in stale_pages(kb)])
    show("綜合頁是客戶確認過的、原檔有變（大改動，寫進〈等你同意的改動〉）", confirmed)
    print(budget_line(kb))
    toc = note_unfinished_toc(kb)
    if toc:
        print(toc)


def decide(kb, action, cps):
    inv_path = kb / INVENTORY_FILE
    removed, pages, done = [], [], []
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        files = inv["檔案"]
        for cp in cps:
            e = files.get(cp)
            if not e:
                print(f"清冊裡沒有：{cp}")
                continue
            if e["狀態"] not in ("原檔已不存在", "保留", "預期刪除"):
                print(f"略過（狀態是「{e['狀態']}」，不是原檔不見）：{cp}")
                continue
            if action == "保留":
                e["狀態"] = "保留"
                e.pop("預期刪除", None)
            else:
                cards, ps = remove_notes(kb, e)
                removed += cards
                pages += ps
            done.append(cp)
        write_json_atomic(inv_path, inv)
    if removed:
        reindex(kb)
    verb = "已刪除筆記" if action == "刪除" else "已標為保留（之後不再詢問）"
    print(f"{verb}：{len(done)} 份")
    show("刪除的卡片", removed)
    show("出處改標「原檔已刪除」的綜合頁", sorted(set(pages)))


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["套用", "刪除", "保留"])
    ap.add_argument("files", nargs="*")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    if a.action == "套用":
        apply(kb)
    elif not a.files:
        sys.exit("請指定原檔，例如 \"{行政}/2025/報價單.xlsx\"")
    else:
        decide(kb, a.action, a.files)


if __name__ == "__main__":
    main()
