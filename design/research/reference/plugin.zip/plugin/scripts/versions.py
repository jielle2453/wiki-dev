"""版本：列出最近的改動，或退回某一次（預設上一次）問答造成的所有改動。

備份由掛鉤 hooks/guard.py 在每次寫入前自動完成（會改頁面的程式也呼叫同一個備份函式），
存在 .system/版本/<回合代號>/：
  說明.json   時間與當時的問題
  清單.jsonl  每個頁面一行：{"路徑", "動作": 修改 | 新增 | 刪除}；
              改原資料夾（source_edit.py）另有 來源新增 | 來源搬動 | 來源覆蓋；定稿（ai_output.py）另有 草稿歸檔
  檔案/       被修改或刪除頁面的舊版
  來源/       被覆蓋的來源純文字檔的舊版
  草稿/       定稿後歸檔的 Markdown 草稿（退回時搬回 .system/草稿/，0.13.0）

用法：
  python versions.py 列出 [--數量 5]
  python versions.py 退回 [回合代號]
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from kbcommon import (CHANGELOG_FILE, DRAFT_ACTIONS, FOLDER_ACTIONS, INVENTORY_FILE, SOURCE_ACTIONS, VERSIONS_DIR, FileLock, long_path,  # noqa: E402
                      now_str, parse_front_matter, read_json, require_kb, utf8_io, write_json_atomic)

REVERTED = "-已退回"


def turns(kb):
    root = kb / VERSIONS_DIR
    if not root.exists():
        return []
    out = []
    for d in sorted(root.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        info = read_json(d / "說明.json", {}) or {}
        m = d / "清單.jsonl"
        entries = [json.loads(x) for x in open(m, encoding="utf-8") if x.strip()] if m.exists() else []
        out.append({"代號": d.name, "資料夾": d, "時間": info.get("時間", ""), "問題": info.get("問題", ""),
                    "已退回": d.name.endswith(REVERTED), "清單": entries})
    return out


def describe(t):
    n = {k: sum(1 for e in t["清單"] if e["動作"] == k) for k in ("修改", "新增", "刪除")}
    flag = "（已退回）" if t["已退回"] else ""
    deleted = f"、刪除 {n['刪除']} 頁" if n["刪除"] else ""
    src = sum(1 for e in t["清單"] if e["動作"] in SOURCE_ACTIONS)
    src = f"、改原資料夾 {src} 項" if src else ""
    fol = sum(1 for e in t["清單"] if e["動作"] in FOLDER_ACTIONS)
    src += f"、管理資料夾 {fol} 項" if fol else ""
    dr = sum(1 for e in t["清單"] if e["動作"] in DRAFT_ACTIONS)
    src += f"、定稿 {dr} 份" if dr else ""
    return f"{t['代號']}{flag}｜{t['時間']}｜問題：「{t['問題']}」｜修改 {n['修改']} 頁、新增 {n['新增']} 頁{deleted}{src}"


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["列出", "退回"])
    ap.add_argument("code", nargs="?")
    ap.add_argument("--數量", dest="n", type=int, default=5)
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    all_turns = turns(kb)

    if a.action == "列出":
        if not all_turns:
            print("還沒有任何改動紀錄")
        current = (read_json(kb / VERSIONS_DIR / ".目前回合.json", {}) or {}).get("代號")
        if current and not any(t["代號"] == current for t in all_turns):
            print(f"{current}（這一次）｜還沒有改動")
        for t in all_turns[:a.n]:
            print(describe(t) + ("｜（這一次）" if t["代號"] == current else ""))
            for e in t["清單"][:15]:
                where = e.get("名稱") or e.get("規則") or e.get("新名稱") if e["動作"] in FOLDER_ACTIONS else e["路徑"]
                print(f"    {e['動作']}：{where}")
            if len(t["清單"]) > 15:
                print(f"    ……共 {len(t['清單'])} 頁")
        return

    cands = [t for t in all_turns if not t["已退回"] and t["清單"]]
    if a.code:
        cands = [t for t in cands if t["代號"] == a.code]
    if not cands:
        sys.exit("找不到可以退回的改動")
    t = cands[0]
    later = [x for x in all_turns if not x["已退回"] and x["清單"] and x["代號"] > t["代號"]]
    if later and any(e["動作"] in FOLDER_ACTIONS for e in t["清單"]):
        # 資料夾管理是整份還原來源清單與清冊，先退回之後的改動才不會把之後的進度蓋掉
        sys.exit(f"這一次有管理資料夾的改動，要先退回之後的 {len(later)} 次改動（從最近的一次開始），才能退回這一次")

    restored, removed, undeleted, lost = [], [], [], []
    for e in reversed(t["清單"]):
        if e["動作"] in SOURCE_ACTIONS or e["動作"] in FOLDER_ACTIONS or e["動作"] in DRAFT_ACTIONS:
            continue  # 來源與資料夾管理的改動在頁面還原之後才退回（下面 folders.revert、source_edit.revert）
        dst = kb / e["路徑"]
        if e["動作"] in ("修改", "刪除"):
            src = t["資料夾"] / "檔案" / e["路徑"]
            if not os.path.exists(long_path(src)):
                lost.append(e["路徑"])  # 排除時選了隱私，備份已經刪掉
                continue
            if e["動作"] == "刪除":
                undeleted.append(e["路徑"])
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(long_path(src), long_path(dst))
            restored.append(e["路徑"])
        elif os.path.exists(long_path(dst)):
            os.remove(long_path(dst))
            removed.append(e["路徑"])

    # 清冊跟著退回的卡片調整：
    #   移除的卡片 → 待處理；更新時刪掉、現在救回來的 → 保留（不再詢問）；
    #   還原成舊版、但原檔已經是新版（指紋不同）→ 已變動，下次更新會重做
    # 資料夾管理（spec 4.7）：改名的資料夾改回，還原來源清單、settings.json、清冊的快照（隱私排除除外）
    folder_msgs = []
    if any(e["動作"] in FOLDER_ACTIONS for e in t["清單"]):
        from folders import revert as revert_folders
        folder_msgs = revert_folders(kb, t["清單"], t["資料夾"])

    restored_cards = [p for p in restored if "/卡片/" in p]
    if removed or undeleted or restored_cards:
        inv_path = kb / INVENTORY_FILE
        with FileLock(inv_path):
            inv = read_json(inv_path, {}) or {"檔案": {}}
            for entry in inv["檔案"].values():
                card = entry.get("卡片")
                if card in removed:
                    entry["狀態"] = "待處理"
                    entry.pop("卡片", None)
                elif card in undeleted and entry.get("狀態") == "已刪除":
                    entry["狀態"] = "保留"
                elif card in restored_cards and entry.get("狀態") == "完成":
                    old = parse_front_matter((kb / card).read_text(encoding="utf-8")).get("指紋")
                    if old and entry.get("指紋") and old != entry["指紋"]:
                        entry["狀態"] = "已變動"
            write_json_atomic(inv_path, inv)

    # 改原資料夾的改動（spec 4.6）：新增的移除、搬動的搬回、覆蓋的還原；客戶之後又改過的不動並說明
    source_msgs = []
    if any(e["動作"] in SOURCE_ACTIONS for e in t["清單"]):
        from source_edit import revert
        source_msgs = revert(kb, t["清單"], t["資料夾"])
    # 定稿（spec 4.9）：草稿搬回 .system/草稿/，〈做到一半的事〉補一列「等客戶回覆」
    if any(e["動作"] in DRAFT_ACTIONS for e in t["清單"]):
        from ai_output import revert_drafts
        source_msgs += revert_drafts(kb, t["清單"], t["資料夾"])

    t["資料夾"].rename(t["資料夾"].with_name(t["代號"] + REVERTED))
    src = f"、來源 {len(source_msgs)} 項" if source_msgs else ""
    src += f"、資料夾管理 {len(folder_msgs)} 項" if folder_msgs else ""
    with open(kb / CHANGELOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n[{now_str()}] 退回｜退回 {t['代號']}（問題：「{t['問題']}」）："
                f"還原 {len(restored)} 頁、移除 {len(removed)} 頁{src}\n")
    if any("/卡片/" in p for p in removed + restored) or folder_msgs:
        subprocess.run([sys.executable, os.path.join(HERE, "reindex.py"), "--知識庫", str(kb)])

    print(f"已退回 {t['代號']}（問題：「{t['問題']}」）")
    for p in restored:
        print(f"  還原：{p}")
    for p in removed:
        print(f"  移除：{p}")
    for m in folder_msgs + source_msgs:
        print(m)
    if lost:
        print(f"  無法還原 {len(lost)} 頁（排除資料夾時選了不想讓 AI 看到，備份已經刪掉）")


if __name__ == "__main__":
    main()
