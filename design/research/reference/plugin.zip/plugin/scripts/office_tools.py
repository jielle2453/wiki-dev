"""重算 Excel、轉 PDF、舊格式轉新格式：用客戶電腦上原本就有的辦公軟體（spec 4.9，決策 #45，0.13.0）。

每次執行時自己偵測，AI 不用判斷：
  1. Microsoft 365 桌面版 Word、Excel（登錄檔有 Word.Application、Excel.Application）：Python 以子程序呼叫
     PowerShell 的 COM，不顯示視窗、不跳警告、停用巨集、不更新外部連結，做完結束**自己開的那個** Word／Excel
  2. LibreOffice（PATH、預設安裝位置，或環境變數 LLMWIKI_SOFFICE）：暫時的設定檔把 OOXML 載入時重算設成「永遠」，
     再 soffice --headless --convert-to 轉存（e8 驗證過的做法）
  3. 都沒有：重算 → 在 workbook.xml 設「打開時全部重算」；轉 PDF、轉新格式 → 做不到（結束碼 3）
不呼叫 docx／xlsx 技能附的 soffice.py、recalc.py（用了 Linux 才有的 AF_UNIX，Windows 一定失敗）。
**COM 的部分還沒在有 Office 的電腦測過**（這台沒有 Office；受保護的檢視、首次啟動、啟用編輯這些視窗要端到端補測）。

用法：
  python office_tools.py 重算 <.system/暫存/ 裡的 Excel>        只重算暫存的副本（不碰來源）
  python office_tools.py 轉PDF <Word 或 Excel> [--轉圖]         PDF 寫到 .system/暫存/；--轉圖：再用 pypdfium2 轉成 PNG（最多 20 頁）
  python office_tools.py 轉新格式 <.doc 或 .xls>                 .docx／.xlsx 寫到 .system/暫存/（只給轉文字、新文件流程用，不寫回來源）
  python office_tools.py 偵測                                     印出這台電腦有哪些辦公軟體
  共同參數：--知識庫 <路徑>
最後印「結果：…」一行：已重算／打開時重算／已轉成 PDF／已轉成新格式／做不到／沒做成。
結束碼：0 完成（重算退到「打開時重算」也是 0）；3 做不到（沒有任何工具，印出改用的輕量做法；或檔案不在暫存）；
        5 檔案使用中；1 有工具但沒做成（Office 沒有回應、出錯）
測試用環境變數：LLMWIKI_OFFICE（覆寫偵測，例如「Word,Excel」或「無」）、LLMWIKI_SOFFICE（soffice.exe，「無」表示沒有）、
        LLMWIKI_POWERSHELL（換掉 powershell，.py 用目前的 Python 執行）、LLMWIKI_OFFICE_TIMEOUT（秒，預設 120）
"""
import argparse
import base64
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from kbcommon import TEMP_DIR, long_path, require_kb, resolve_code_path, utf8_io  # noqa: E402

TIMEOUT = 120
WORD_EXTS = (".docx", ".docm", ".doc", ".rtf")
EXCEL_EXTS = (".xlsx", ".xlsm", ".xls")
OK_MARK = "LLMWIKI-OK"
ERR_MARK = "LLMWIKI-ERR:"
HUNG = "Office 沒有回應，可能跳出了視窗（受保護的檢視、啟用編輯、首次啟動）"


class Refuse(Exception):
    """做不到或不能做：結束碼 3。"""


class Failed(Exception):
    """有工具但沒做成：結束碼 1。"""


# ---- 偵測 ----

def office_apps():
    """有桌面版的哪幾個：{"Word", "Excel"} 的子集合。看登錄檔的 ProgID；LLMWIKI_OFFICE 可覆寫（測試用）。"""
    env = os.environ.get("LLMWIKI_OFFICE")
    if env is not None:
        return {x.strip() for x in env.replace("，", ",").split(",") if x.strip() in ("Word", "Excel")}
    if os.name != "nt":
        return set()
    import winreg
    found = set()
    for app in ("Word", "Excel"):
        try:
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, f"{app}.Application\\CLSID"):
                found.add(app)
        except OSError:
            pass
    return found


def find_soffice():
    """LibreOffice 的 soffice.exe；沒有回傳 None。"""
    env = os.environ.get("LLMWIKI_SOFFICE")
    if env is not None:
        return env if env not in ("", "無") and os.path.isfile(env) else None
    exe = shutil.which("soffice") or shutil.which("soffice.exe")
    if exe:
        return exe
    cands = [os.path.join(os.environ.get(v, ""), "LibreOffice", "program", "soffice.exe")
             for v in ("ProgramFiles", "ProgramFiles(x86)")]
    cands.append(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "LibreOffice", "program", "soffice.exe"))
    return next((c for c in cands if os.path.isfile(c)), None)


def timeout():
    try:
        return int(os.environ.get("LLMWIKI_OFFICE_TIMEOUT", TIMEOUT))
    except ValueError:
        return TIMEOUT


def kill_tree(pid):
    """只結束指定的程序（和它開的子程序）：自己開的 Word／Excel／soffice，客戶自己開著的不動。"""
    if not pid:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True)
    else:
        try:
            os.kill(int(pid), 9)
        except OSError:
            pass


# ---- COM（PowerShell）----

def ps_quote(s):
    return "'" + str(s).replace("'", "''") + "'"


PS_HEAD = r"""$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$op = {op}
$in = {src}
$out = {dst}
$pidfile = {pidfile}
$app = $null; $mypid = 0; $code = 0
try {{
  $before = @(Get-Process {proc} -ErrorAction SilentlyContinue | ForEach-Object {{ $_.Id }})
  $app = New-Object -ComObject {app}.Application
  $new = @(Get-Process {proc} -ErrorAction SilentlyContinue | ForEach-Object {{ $_.Id }} | Where-Object {{ $before -notcontains $_ }})
  if ($new.Count -eq 1) {{ $mypid = $new[0]; Set-Content -LiteralPath $pidfile -Value $mypid }}
  $app.Visible = $false
{body}
  Write-Output '{ok}'
}} catch {{
  Write-Output ('{err} ' + $_.Exception.Message)
  $code = 1
}} finally {{
  if ($app) {{ try {{ $app.Quit() }} catch {{}}; [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) }}
  [GC]::Collect(); [GC]::WaitForPendingFinalizers()
  if ($mypid) {{ Start-Sleep -Milliseconds 500; Stop-Process -Id $mypid -Force -ErrorAction SilentlyContinue }}
}}
exit $code
"""

# Excel：DisplayAlerts 關、AutomationSecurity 3（停用巨集）、不問也不更新外部連結（Workbooks.Open 第 2 個參數 0）
EXCEL_SETUP = """  $app.DisplayAlerts = $false
  $app.ScreenUpdating = $false
  $app.AskToUpdateLinks = $false
  $app.AutomationSecurity = 3"""
WORD_SETUP = """  $app.DisplayAlerts = 0
  $app.AutomationSecurity = 3"""

PS_BODY = {
    ("Excel", "重算"): EXCEL_SETUP + """
  $wb = $app.Workbooks.Open($in, 0, $false)
  $app.CalculateFullRebuild()
  $wb.Save()
  $wb.Close($false)""",
    ("Excel", "轉PDF"): EXCEL_SETUP + """
  $wb = $app.Workbooks.Open($in, 0, $true)
  $wb.ExportAsFixedFormat(0, $out)
  $wb.Close($false)""",
    ("Excel", "轉新格式"): EXCEL_SETUP + """
  $wb = $app.Workbooks.Open($in, 0, $true)
  $wb.SaveAs($out, 51)
  $wb.Close($false)""",
    ("Word", "轉PDF"): WORD_SETUP + """
  $doc = $app.Documents.Open($in, $false, $true, $false)
  $doc.ExportAsFixedFormat($out, 17)
  $doc.Close(0)""",
    ("Word", "轉新格式"): WORD_SETUP + """
  $doc = $app.Documents.Open($in, $false, $true, $false)
  $doc.SaveAs2($out, 16)
  $doc.Close(0)""",
}


def decode(b):
    """PowerShell 的輸出：腳本設了 UTF-8，但 Office 的錯誤訊息或舊版主控台可能是系統字碼頁（繁中是 cp950）。"""
    b = b or b""
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("mbcs" if os.name == "nt" else "latin-1", "replace")


def ps_command():
    env = os.environ.get("LLMWIKI_POWERSHELL")
    if env:
        return [sys.executable, env] if env.lower().endswith(".py") else [env]
    return ["powershell.exe"]


def run_com(app, op, src, dst):
    """用 PowerShell 的 COM 操作 Word／Excel。逾時就結束自己開的那個 Office 與 PowerShell。成功回傳 None，失敗丟 Failed。"""
    tmp = tempfile.mkdtemp(prefix="llmwiki_com_")
    pidfile = os.path.join(tmp, "pid.txt")
    script = PS_HEAD.format(op=ps_quote(op), src=ps_quote(src), dst=ps_quote(dst), pidfile=ps_quote(pidfile),
                            proc="EXCEL" if app == "Excel" else "WINWORD", app=app,
                            body=PS_BODY[(app, op)], ok=OK_MARK, err=ERR_MARK)
    enc = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    cmd = ps_command() + ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
        try:
            out, err = p.communicate(timeout=timeout())
        except subprocess.TimeoutExpired:
            try:
                kill_tree(open(pidfile, encoding="utf-8-sig").read().strip())
            except OSError:
                pass
            kill_tree(p.pid)
            p.kill()
            p.communicate()
            raise Failed(HUNG)
        text = decode(out) + decode(err)
        if p.returncode != 0 or OK_MARK not in text:
            m = re.search(re.escape(ERR_MARK) + r"\s*(.*)", text)
            raise Failed(f"{app} 出錯：{(m.group(1) if m else text.strip())[:200] or '沒有訊息'}")
    except OSError as e:
        raise Failed(f"執行 PowerShell 失敗：{e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---- LibreOffice ----

LO_PROFILE = """<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="ODFRecalcMode" oor:op="fuse"><value>0</value></prop></item>
</oor:items>
"""


def lo_filter(src, op):
    ext = Path(src).suffix.lower()
    if op == "轉PDF":
        return "pdf", ".pdf"
    if op == "轉新格式":
        return ("docx", ".docx") if ext in WORD_EXTS else ("xlsx", ".xlsx")
    # 重算：轉存成同一種格式；.xlsm 用保留 VBA 的篩選器
    return ('xlsm:"Calc MS Excel 2007 VBA XML"', ".xlsm") if ext == ".xlsm" else ("xlsx", ".xlsx")


def run_lo(soffice, op, src):
    """用 LibreOffice 轉存，回傳產出的檔案（在暫時資料夾裡，呼叫端負責搬走）。失敗丟 Failed。"""
    tmp = tempfile.mkdtemp(prefix="llmwiki_lo_")
    prof = Path(tmp) / "profile"
    (prof / "user").mkdir(parents=True)
    (prof / "user" / "registrymodifications.xcu").write_text(LO_PROFILE, encoding="utf-8")
    outdir = Path(tmp) / "out"
    outdir.mkdir()
    filt, ext = lo_filter(src, op)
    filt = filt.replace('"', "")  # 參數清單直接傳給程式，不經過 shell，不用引號
    cmd = [soffice, f"-env:UserInstallation={prof.as_uri()}", "--headless", "--norestore", "--nologo",
           "--convert-to", filt, "--outdir", str(outdir), str(src)]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
        try:
            out, err = p.communicate(timeout=timeout())
        except subprocess.TimeoutExpired:
            kill_tree(p.pid)
            p.kill()
            p.communicate()
            raise Failed("LibreOffice 沒有回應")
        result = outdir / (Path(src).stem + ext)
        if not result.exists():
            msg = ((err or b"") + (out or b"")).decode("utf-8", "replace").strip()
            raise Failed(f"LibreOffice 沒有產出檔案：{msg[:200] or '沒有訊息'}")
        return tmp, result
    except OSError as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise Failed(f"執行 LibreOffice 失敗：{e}")
    except Failed:
        shutil.rmtree(tmp, ignore_errors=True)
        raise


# ---- 都沒有：Excel 設打開時重算 ----

CALC_AFTER = ("oleSize", "customWorkbookViews", "pivotCaches", "smartTagPr", "smartTagTypes", "webPublishing",
              "fileRecoveryPr", "webPublishObjects", "extLst")


def set_full_calc_on_load(path):
    """在 xl/workbook.xml 的 calcPr 設 fullCalcOnLoad="1"（Excel 打開時全部重算）。只改這一個屬性，其他檔案照原樣。"""
    with zipfile.ZipFile(long_path(path)) as z:
        infos = z.infolist()
        data = {i.filename: z.read(i.filename) for i in infos}
    wb = data["xl/workbook.xml"].decode("utf-8")
    m = re.search(r"<((?:\w+:)?)workbook\b", wb)
    pre = m.group(1) if m else ""
    calc = re.search(rf"<{re.escape(pre)}calcPr\b[^>]*?/?>", wb)
    if calc:
        tag = calc.group(0)
        if re.search(r"\bfullCalcOnLoad=\"[^\"]*\"", tag):
            new = re.sub(r"\bfullCalcOnLoad=\"[^\"]*\"", 'fullCalcOnLoad="1"', tag)
        else:
            new = re.sub(r"\s*(/?>)$", r' fullCalcOnLoad="1"\1', tag)
        wb = wb[:calc.start()] + new + wb[calc.end():]
    else:
        new = f'<{pre}calcPr fullCalcOnLoad="1"/>'
        nxt = re.search(rf"<{re.escape(pre)}(?:{'|'.join(CALC_AFTER)})\b", wb)
        at = nxt.start() if nxt else wb.rindex(f"</{pre}workbook>")
        wb = wb[:at] + new + wb[at:]
    data["xl/workbook.xml"] = wb.encode("utf-8")
    fd, tmp = tempfile.mkstemp(dir=long_path(Path(path).parent), suffix=".tmp")
    os.close(fd)
    with zipfile.ZipFile(tmp, "w") as out:
        for i in infos:
            out.writestr(i, data[i.filename], compress_type=i.compress_type)
    os.replace(tmp, long_path(path))


# ---- 各個動作 ----

def kind_of(path):
    ext = Path(path).suffix.lower()
    if ext in WORD_EXTS:
        return "Word"
    if ext in EXCEL_EXTS:
        return "Excel"
    return None


def unique(p):
    base, p, i = Path(p), Path(p), 2
    while os.path.exists(long_path(p)):
        p = base.parent / f"{base.stem} ({i}){base.suffix}"
        i += 1
    return p


def inside(child, parent):
    c = os.path.normcase(os.path.abspath(str(child)))
    p = os.path.normcase(os.path.abspath(str(parent))).rstrip(os.sep)
    return c.startswith(p + os.sep)


def recalc(kb, src):
    if not inside(src, kb / TEMP_DIR):
        raise Refuse("只重算 .system/暫存/ 裡的副本（來源的原檔不直接改）：先複製到暫存，改完再重算")
    if Path(src).suffix.lower() not in (".xlsx", ".xlsm"):
        raise Refuse("重算只接受 .xlsx、.xlsm（舊版 .xls 先轉新格式）")
    with open(long_path(src), "r+b"):
        pass  # 檔案被鎖住時在這裡就停（PermissionError → 結束碼 5）
    notes = []
    if "Excel" in office_apps():
        try:
            run_com("Excel", "重算", os.path.abspath(src), "")
            return "結果：已重算（用 Excel）", notes
        except Failed as e:
            notes.append(f"Excel 沒做成：{e}")
    soffice = find_soffice()
    if soffice:
        try:
            tmp, result = run_lo(soffice, "重算", src)
            try:
                os.replace(result, long_path(src))
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            return "結果：已重算（用 LibreOffice）", notes
        except Failed as e:
            notes.append(f"LibreOffice 沒做成：{e}")
    set_full_calc_on_load(src)
    why = "；".join(notes) if notes else "這台電腦沒有桌面版 Excel，也沒有 LibreOffice"
    return f"結果：打開時重算（{why}）", notes + [
        "已設定成 Excel 打開時全部重算：回答時說「公式的結果要用 Excel 打開才會更新」，不要報公式的數字（自己手算的也不行）",
        "存進來源後清冊會記「公式待重算」，先不製卡；客戶用 Excel 打開、存檔後下次更新照常製卡"]


def convert(kb, src, op):
    kind = kind_of(src)
    if not kind:
        raise Refuse(f"{Path(src).suffix or '這種'} 檔不是 Word、Excel")
    if op == "轉新格式" and Path(src).suffix.lower() not in (".doc", ".xls", ".rtf"):
        raise Refuse("轉新格式只接受舊版的 .doc、.xls、.rtf")
    ext = ".pdf" if op == "轉PDF" else (".docx" if kind == "Word" else ".xlsx")
    dest = unique(kb / TEMP_DIR / (Path(src).stem + ext))
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(long_path(src), "rb"):
        pass
    notes = []
    tried = False
    if kind in office_apps():
        tried = True
        try:
            run_com(kind, op, os.path.abspath(src), os.path.abspath(dest))
            if os.path.exists(long_path(dest)):
                return dest, f"用 {kind}", notes
            notes.append(f"{kind} 沒有產出檔案")
        except Failed as e:
            notes.append(f"{kind} 沒做成：{e}")
    soffice = find_soffice()
    if soffice:
        tried = True
        try:
            tmp, result = run_lo(soffice, op, src)
            try:
                shutil.move(str(result), long_path(dest))
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            return dest, "用 LibreOffice", notes
        except Failed as e:
            notes.append(f"LibreOffice 沒做成：{e}")
    if not tried:
        light = ("不給 PDF：照實告訴客戶這台電腦沒有桌面版 Office 或 LibreOffice，做不出 PDF；需要的話請客戶用 Word 開啟後另存 PDF"
                 if op == "轉PDF" else
                 f"請客戶用 {kind} 打開這份檔案，另存成新格式（{'.docx' if kind == 'Word' else '.xlsx'}）後再說一次")
        raise Refuse(f"這台電腦沒有桌面版 {kind}，也沒有 LibreOffice。改用輕量做法：{light}")
    raise Failed("；".join(notes))


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["重算", "轉PDF", "轉新格式", "偵測"])
    ap.add_argument("file", nargs="?")
    ap.add_argument("--轉圖", dest="images", action="store_true", help="轉PDF 之後再轉成 PNG（給 AI 看排版）")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    if a.action == "偵測":
        apps = office_apps()
        print("桌面版 Word：" + ("有" if "Word" in apps else "沒有"))
        print("桌面版 Excel：" + ("有" if "Excel" in apps else "沒有"))
        print("LibreOffice：" + (find_soffice() or "沒有"))
        return
    if not a.file:
        print("請指定檔案")
        sys.exit(3)
    src = resolve_code_path(kb, a.file) if a.file.startswith("{") else Path(os.path.abspath(a.file))
    if not os.path.isfile(long_path(src)):
        print(f"結果：做不到（找不到檔案 {a.file}）")
        sys.exit(3)
    try:
        if a.action == "重算":
            line, notes = recalc(kb, src)
            for n in notes:
                print(n)
            print(line)
            return
        dest, how, notes = convert(kb, src, a.action)
        for n in notes:
            print(n)
        print(f"{'PDF' if a.action == '轉PDF' else '新格式的檔案'}：{dest}")
        if a.action == "轉PDF" and a.images:
            from convert import render_pages
            import pypdfium2 as pdfium
            pdf = pdfium.PdfDocument(long_path(dest))
            n = len(pdf)
            pdf.close()
            imgs = render_pages(dest, list(range(1, n + 1)), kb / TEMP_DIR, dest.stem)
            print("排版圖片（用 Read 看，看完和 PDF 一起刪除）：")
            for i, p in imgs:
                print(f"  第 {i} 頁：{p}")
            if n > len(imgs):
                print(f"  共 {n} 頁，只轉了前 {len(imgs)} 頁")
        print(f"結果：{'已轉成 PDF' if a.action == '轉PDF' else '已轉成新格式'}（{how}）")
    except Refuse as e:
        print(f"結果：做不到——{e}")
        sys.exit(3)
    except Failed as e:
        print(f"結果：沒做成——{e}")
        sys.exit(1)
    except PermissionError:
        print(f"結果：沒做成——{Path(src).name} 正在使用中。請客戶把檔案關掉後再說一次；不要自己重試。")
        sys.exit(5)


if __name__ == "__main__":
    main()
