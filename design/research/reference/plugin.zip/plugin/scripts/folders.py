"""管理資料夾：加資料夾、拿掉、改路徑、排除、取消排除、改分區名稱（spec 4.7、決策 #40）。

客戶要求時由 AI 呼叫（query 技能；ingest 發現整區不見、客戶回答之後），服務人員建置後調整也用這支。
程式只擋四種危險情況（整顆磁碟與系統資料夾、總資料夾與成品區、和既有分區重疊；代號重複自動換），
其他（範圍大、份數多、像私人資料、外接硬碟、共用）只印提醒。
改之前把來源清單、.claude/settings.json、檔案清冊備份進同一回合（.system/版本/<回合>/設定/），卡片與綜合頁照常備份，
所以「退回上一版」救得回來；只有排除時選「隱私」會連備份一起刪，無法退回。

用法：
  python folders.py 預覽 <路徑> [--名稱 名稱] [--代號 代號]                 只盤點、不改任何東西
  python folders.py 加入 <路徑> --名稱 名稱 --共用 是|否 [--AI產出 資料夾內|中央] [--代號 代號] [--說明 文字] --客戶已同意
                     --AI產出：AI 起草的文件放這一區來源最上層的「AI 產出」或中央成品區（不寫照預設：共用、雲端 → 中央，0.13.0）
  python folders.py 拿掉 <代號> --客戶已同意                                  卡片刪除（有備份），客戶的資料夾不動
  python folders.py 改路徑 <代號> <新路徑> [--客戶已同意]                     抽樣比對指紋；對不上要先問
  python folders.py 排除 <{代號}/資料夾 或 檔名規則> --種類 隱私|用不到 --客戶已同意
  python folders.py 取消排除 <規則>
  python folders.py 改名 <代號> <新名稱>
  python folders.py 試讀完成 <代號>                                          新的一區試讀做完，之後一般製卡也會取這一區
  python folders.py 刪除推測 "表名|名稱" [...]                              隱私排除後客戶勾的推測：設定檔與備份一起刪
共同參數：--知識庫 <路徑>

結束碼：0 完成（預覽也是 0）；3 拒絕（原因印在最後）；4 要先問客戶（什麼都還沒做，印出盤點結果）；
        5 有檔案正在使用中（請客戶關掉後再說一次）
加入、改路徑對不上之後：這個對話讀不到新資料夾，請客戶開新對話，〈做到一半的事〉記「進行中」接著試讀與製卡。
"""
import argparse
import os
import re
import shutil
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import quote, unquote

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from inventory import regroup, scan, walk  # noqa: E402
from kbcommon import (AI_OUT_CENTRAL, AI_OUT_IN, BASIS, CHANGELOG_FILE, FOLDER_ACTIONS, GUESS_TABLES, INVENTORY_FILE, PENDING_FILE, PROFILE_FILE, RESERVED_NAMES, SOURCES_FILE, SUPPORTED,  # noqa: E402
                      VERSIONS_DIR, WIKI, FileLock, append_turn_entry, backup_page, current_turn, file_hash,
                      free_code, is_cloud_placeholder, is_excluded, is_skipped_name, load_sources, long_path,
                      now_str, parse_front_matter, path_problems, read_json, require_kb, safe_name,
                      card_texts, default_ai_out, edit_profile_tables, mentioned, set_front_matter, split_basis, turn_dir, utf8_io, write_json_atomic,
                      write_text_atomic)
from update import LINK, card_family, cites, reindex, remove_notes, sync_card_paths, synthesis_pages  # noqa: E402

SETTINGS = Path(".claude") / "settings.json"
SNAP = "設定"                 # 版本資料夾裡放來源清單、settings.json、清冊快照的子資料夾
MOVED_OUT = "原檔已移出"
BIG = 500                     # 超過這麼多份多提醒時間與用量（推估）
ASK_CARDS = 30                # 製卡超過這麼多份照 4.3 先問
MATCH_RATIO = 0.8             # 改路徑：抽樣的檔案有這個比例對得上才算同一個資料夾（推估）
SAMPLE = 30                   # 改路徑最多抽幾份比對
PRIVATE_WORDS = ("家庭", "保單", "病歷", "相簿", "私人")
USER_TOP = ("Desktop", "Documents", "Downloads", "桌面", "文件", "下載")


class Refuse(Exception):
    pass


class Ask(Exception):
    """要先問客戶：印出盤點結果後結束碼 4。訊息是最後一行的提示（沒有就用預設的）。"""


def norm(p):
    return os.path.normcase(os.path.abspath(str(p)))


def find_section(sources, code):
    s = next((x for x in sources["分區"] if x["代號"] == code), None)
    if not s:
        raise Refuse(f"來源清單沒有分區代號 {code}（現有：{'、'.join(x['代號'] for x in sources['分區']) or '無'}）")
    return s


def log_change(kb, text):
    with open(long_path(kb / CHANGELOG_FILE), "a", encoding="utf-8") as f:
        f.write(f"\n[{now_str()}] 管理資料夾｜{text}\n")


# ---- 讀取權限、快照 ----

def settings_dirs(kb, add=(), remove=()):
    """改總資料夾 .claude/settings.json 的 additionalDirectories（AI 不直接編輯）。"""
    path = kb / SETTINGS
    data = read_json(path, {}) or {}
    dirs = data.setdefault("permissions", {}).setdefault("additionalDirectories", [])
    gone = {norm(p) for p in remove}
    dirs[:] = [d for d in dirs if norm(d) not in gone]
    for p in add:
        if norm(p) not in {norm(d) for d in dirs}:
            dirs.append(Path(p).as_posix())
    write_json_atomic(path, data)


def snapshot(kb, turn):
    """這一回合第一次改資料夾設定前，備份來源清單、settings.json、清冊（.claude/ 與 .system/ 平常不備份）。"""
    d = turn_dir(kb, turn) / SNAP
    if d.exists():
        return
    had = []
    for rel in (SOURCES_FILE, SETTINGS, INVENTORY_FILE):
        if (kb / rel).exists():
            (d / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(long_path(kb / rel), long_path(d / rel))
            had.append(rel.as_posix())
    write_json_atomic(d / "有哪些.json", had)


def record(kb, turn, action, code, **detail):
    append_turn_entry(kb, turn, {"路徑": f"分區:{code}:{action}:{now_str()}", "動作": action, "代號": code, **detail})


# ---- 盤點與提醒 ----

def survey(path, rules):
    """只看檔名、大小、格式（不讀內容）：份數、格式、雲端占位、像私人資料的子資料夾。"""
    c = {"份數": 0, "可製卡": 0, "不支援": 0, "雲端占位": 0, "大小": 0, "格式": Counter(), "私人": []}
    for rel, st, err in walk(path):
        if not st:
            continue
        name = rel.rsplit("/", 1)[-1]
        if is_skipped_name(name) or is_excluded(rel, rules):
            continue
        c["份數"] += 1
        c["大小"] += st.st_size
        ext = Path(name).suffix.lower()
        c["格式"][ext or "（無副檔名）"] += 1
        if ext not in SUPPORTED:
            c["不支援"] += 1
        elif is_cloud_placeholder(st):
            c["雲端占位"] += 1
        else:
            c["可製卡"] += 1
        for i, part in enumerate(rel.split("/")[:-1]):
            if any(w in part for w in PRIVATE_WORDS):
                folder = "/".join(rel.split("/")[:i + 1])
                if folder not in c["私人"]:
                    c["私人"].append(folder)
    return c


def warnings(path, count):
    p = Path(os.path.abspath(path))
    w = []
    home = Path.home()
    if p.name in USER_TOP and (p.parent == home or p.parent.parent == home):
        w.append(f"這是整個「{p.name}」資料夾，範圍很大，可能混進和工作無關的檔案；可以只加裡面的某個資料夾")
    if any(word in p.name for word in PRIVATE_WORDS):
        w.append("名稱看起來像私人資料：建議另外建一個私人的知識庫，不要和工作資料混在一起；客戶堅持就照加")
    if count["私人"]:
        w.append("裡面有看起來像私人資料的子資料夾：" + "、".join(count["私人"][:10]) + "；可以加入後排除這幾個")
    if count["份數"] > BIG:
        w.append(f"有 {count['份數']} 份（超過 {BIG} 份），整理要花比較久、也會用掉較多用量，建議分批加；客戶堅持就照做")
    drive = os.path.splitdrive(str(p))[0]
    sysdrive = os.environ.get("SystemDrive", "C:")
    if drive.startswith("\\\\"):
        w.append("這是網路磁碟：連不上時這一區會暫時找不到；網路磁碟還沒測過，可能比較慢")
    elif drive and drive.upper() != sysdrive.upper():
        w.append(f"這在 {drive} 槽（可能是外接硬碟）：沒接上時這一區會暫時找不到，接上就恢復")
    if count["雲端占位"]:
        w.append(f"有 {count['雲端占位']} 份只在雲端、還沒下載，要先下載到電腦才能整理")
    return w


def print_survey(path, count, warns, name=None, code=None):
    mb = count["大小"] / 1048576
    print(f"資料夾：{path}" + (f"（名稱「{name}」、代號 {code}）" if name else ""))
    print(f"- 共 {count['份數']} 份，{mb:.1f} MB；可以整理 {count['可製卡']} 份、格式不支援 {count['不支援']} 份、只在雲端 {count['雲端占位']} 份")
    if count["格式"]:
        print("- 格式：" + "、".join(f"{k} {v}" for k, v in count["格式"].most_common(8)))
    if count["可製卡"] > ASK_CARDS:
        print(f"- 超過 {ASK_CARDS} 份：之後製卡前照更新的規則先問客戶要不要現在整理")
    for x in warns:
        print(f"- 提醒：{x}")


def check_path(kb, sources, path, ignore_code=None):
    if not Path(long_path(path)).is_dir():
        raise Refuse(f"找不到這個資料夾：{path}。客戶沒說完整路徑時，列出候選讓客戶選，不要猜。")
    problems = path_problems(kb, sources, path, ignore_code)
    if problems:
        raise Refuse("；".join(problems))


def check_name(sources, name, ignore_code=None):
    if not name or safe_name(name) != name:
        raise Refuse(f"分區名稱不能有 <>:\"/\\|?* 這些字元，也不能以空白或句點結尾：{name}")
    if name in RESERVED_NAMES:
        raise Refuse(f"「{name}」是系統用的名稱，請換一個")
    if any(s["名稱"] == name and s["代號"] != ignore_code for s in sources["分區"]):
        raise Refuse(f"分區名稱「{name}」已經有人用了，請客戶換一個名稱")


# ---- 清冊 ----

def add_inventory(kb, sources, sec):
    """新的一區先記進清冊（狀態「待處理」）：新對話開頭不會被當成新增叫起 ingest，照〈做到一半的事〉先試讀再製卡。"""
    inv_path = kb / INVENTORY_FILE
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        r = scan({"分區": [sec], "排除": sources["排除"]}, {})
        files = inv["檔案"]
        files.update(r["檔案"])
        # 原本在別處、原檔不見（或客戶說先留著）的筆記，內容和新的一區某份相同時接過來，不重做（同 inventory 的搬動判斷）
        heirs = {}
        for cp, e in sorted(r["檔案"].items(), key=lambda x: (len(x[0]), x[0])):
            if e["狀態"] == "待處理" and e.get("指紋"):
                heirs.setdefault(e["指紋"], cp)
        moved = []
        for cp, e in list(files.items()):
            if e["狀態"] in ("原檔已不存在", "保留") and e.get("卡片") and e.get("指紋") in heirs:
                new = heirs.pop(e["指紋"])
                files[new]["卡片"] = e["卡片"]
                files[new]["狀態"] = "完成"
                files.pop(cp)
                moved.append(new)
        for d in {e.get("指紋") for e in r["檔案"].values() if e.get("指紋")}:
            regroup(files, d)
        write_json_atomic(inv_path, inv)
    if moved:
        sync_card_paths(kb, {c: files[c] for c in moved if c in files})
    return sum(1 for e in r["檔案"].values() if e["狀態"] == "待處理")


def drop_section_notes(kb, sec):
    """拿掉一區的筆記：卡片刪除、綜合頁出處標「原檔已移出」、索引與總覽刪除（都先備份），清冊拿掉這一區。"""
    inv_path = kb / INVENTORY_FILE
    removed = []
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        files = inv["檔案"]
        for cp, e in sorted(files.items()):
            if e.get("分區") == sec["代號"] and e.get("卡片") and e["狀態"] != "已刪除":
                cards, _ = remove_notes(kb, e, MOVED_OUT)
                removed += cards
        inv["檔案"] = {cp: e for cp, e in files.items() if e.get("分區") != sec["代號"]}
        write_json_atomic(inv_path, inv)
    d = kb / WIKI / sec["名稱"]
    for p in [d / "索引.md", d / "總覽.md", *sorted((d / "索引").glob("*.md"))]:
        if p.exists():
            rel = p.relative_to(kb).as_posix()
            backup_page(kb, rel, "刪除")
            os.remove(long_path(p))
    return removed


def section_cards(kb, code):
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    return [c for e in inv.values() if e.get("分區") == code and e.get("卡片") and e["狀態"] != "已刪除"
            for c in card_family(kb, e["卡片"])]


def citing_pages(kb, cards):
    names = {Path(c).name for c in cards}
    return [p.relative_to(kb).as_posix() for p in synthesis_pages(kb) if names and cites(p.read_text(encoding="utf-8"), names)]


# ---- 各個操作 ----

def op_preview(kb, sources, a):
    path = os.path.abspath(a.target[0])
    check_path(kb, sources, path)
    count = survey(path, sources["排除"])
    code = free_code(sources, a.code or a.name) if (a.code or a.name) else None
    print("盤點結果（只看檔名與數字，什麼都還沒改）：")
    print_survey(path, count, warnings(path, count), a.name, code)
    if a.name and a.code and code != a.code:
        print(f"- 代號 {a.code} 已經有人用，會改用 {code}")
    if a.name:
        try:
            check_name(sources, a.name)
        except Refuse as e:  # 加入時會被拒絕，預覽就先提醒，好一次問完（0.11.1）
            print(f"- 提醒：名稱不能用——{e}")
    print("- 要問客戶：這個資料夾有沒有和別人共用（加入時寫 --共用 是 或 否）")
    print("客戶答應後：folders.py 加入 \"<路徑>\" --名稱 <名稱> --共用 是|否 --客戶已同意")


def op_add(kb, sources, a, turn):
    path = os.path.abspath(a.target[0])
    check_path(kb, sources, path)
    if not a.name:
        raise Refuse("加入要寫 --名稱（客戶習慣的說法，例如「報價」）")
    check_name(sources, a.name)
    if a.shared not in ("是", "否"):
        raise Refuse("加入要寫 --共用 是 或 否：先問客戶這個資料夾有沒有和別人共用")
    if a.ai_out and a.ai_out not in (AI_OUT_IN, AI_OUT_CENTRAL):
        raise Refuse(f"--AI產出 只能寫 {AI_OUT_IN} 或 {AI_OUT_CENTRAL}")
    code = free_code(sources, a.code or a.name)
    if any(c in code for c in "{}/\\") or not code.strip():
        raise Refuse(f"代號不能有 {{ }} / \\：{code}")
    count = survey(path, sources["排除"])
    if not a.confirmed:
        print("要先問客戶（什麼都還沒做）：")
        print_survey(path, count, warnings(path, count), a.name, code)
        raise Ask()
    snapshot(kb, turn)
    sec = {"名稱": a.name, "代號": code, "路徑": str(Path(path).resolve()), "說明": a.desc or "", "共用": a.shared,
           "待試讀": True}  # batch.py 下一批不帶 --分區 時跳過這一區，試讀完由 folders.py 試讀完成 清掉
    sec["AI 產出放哪"] = a.ai_out or default_ai_out(sec)  # spec 4.9
    sources["分區"].append(sec)
    write_json_atomic(kb / SOURCES_FILE, sources)
    for d in (kb / WIKI / a.name / "卡片", kb / WIKI / a.name / "綜合"):
        d.mkdir(parents=True, exist_ok=True)
    if sources.get("成品區"):
        (Path(sources["成品區"]) / a.name).mkdir(parents=True, exist_ok=True)
    settings_dirs(kb, add=[sec["路徑"]])
    todo = add_inventory(kb, sources, sec)
    record(kb, turn, "資料夾加入", code, 名稱=a.name, 新路徑=sec["路徑"])
    log_change(kb, f"加入「{a.name}」（{{{code}}} {sec['路徑']}，{count['份數']} 份）")
    print(f"已加入「{a.name}」（代號 {code}{'，和別人共用' if a.shared == '是' else ''}，"
          f"AI 起草的文件放{'這一區的「AI 產出」資料夾' if sec['AI 產出放哪'] == AI_OUT_IN else '中央成品區'}），待製卡 {todo} 份。")
    if code != (a.code or a.name):
        print(f"代號 {a.code or a.name} 已經有人用，改用 {code}。")
    after_add_hint(a.name, code, todo)


def after_add_hint(name, code, todo):
    print("這個對話還讀不到新資料夾：請客戶開一個新的對話（說「繼續」就好），我會接著整理。")
    print(f"在〈做到一半的事〉記一列（狀態「進行中」）：事情「新分區〈{name}〉試讀與製卡（客戶已同意加入）」，"
          f"下一步「開新對話後照 query 技能第八節〈加完之後〉：batch.py 抽樣 --分區 {code} → card-maker 試讀 → folders.py 試讀完成 {code} → 製卡 batch.py 下一批 --分區 {code}"
          f"（{todo} 份" + ("，超過 30 份先問客戶" if todo > ASK_CARDS else "") + f"）→ 寫 wiki/{name}/總覽.md → 總目錄加一行」")


def op_remove(kb, sources, a, turn):
    sec = find_section(sources, a.target[0])
    cards = section_cards(kb, sec["代號"])
    pages = citing_pages(kb, cards)
    if not a.confirmed:
        print("要先問客戶（什麼都還沒做）：")
        print(f"- 拿掉「{sec['名稱']}」（{sec['路徑']}）：筆記 {len(cards)} 張會刪除（有備份，說「退回上一版」救得回來）")
        print(f"- 引用到的整理頁 {len(pages)} 頁，出處會標「{MOVED_OUT}」" + ("：" + "、".join(pages[:10]) if pages else ""))
        print("- 客戶的資料夾本身不會動")
        raise Ask()
    snapshot(kb, turn)
    removed = drop_section_notes(kb, sec)
    sources["分區"] = [s for s in sources["分區"] if s["代號"] != sec["代號"]]
    write_json_atomic(kb / SOURCES_FILE, sources)
    if not any(norm(s["路徑"]) == norm(sec["路徑"]) for s in sources["分區"]):
        settings_dirs(kb, remove=[sec["路徑"]])
    record(kb, turn, "資料夾拿掉", sec["代號"], 名稱=sec["名稱"], 舊路徑=sec["路徑"])
    log_change(kb, f"拿掉「{sec['名稱']}」（{{{sec['代號']}}}）：刪除筆記 {len(removed)} 張；客戶的資料夾沒動")
    reindex(kb)
    left = sorted(p.relative_to(kb).as_posix() for p in (kb / WIKI / sec["名稱"] / "綜合").glob("*.md"))
    print(f"已拿掉「{sec['名稱']}」：刪除筆記 {len(removed)} 張，整理頁出處標「{MOVED_OUT}」 {len(pages)} 頁；客戶的資料夾沒動。")
    if left:
        print(f"這一區的整理頁 {len(left)} 頁還留著（出處已標「{MOVED_OUT}」）：" + "、".join(left[:10]))
    print(f"請用 Edit 把 wiki/總目錄.md 裡「{sec['名稱']}」那一行拿掉。")


def sample_match(sec, new_path, inv):
    cands = sorted(cp for cp, e in inv.items() if e.get("分區") == sec["代號"] and e.get("指紋")
                   and e["狀態"] not in ("已刪除", "原檔已不存在", "保留", "已排除", "預期刪除"))
    if not cands:
        return 0, 0
    step = max(1, len(cands) // SAMPLE)
    picked = cands[::step][:SAMPLE]
    ok = 0
    for cp in picked:
        p = Path(new_path) / cp.split("}/", 1)[1]
        try:
            st = os.stat(long_path(p))
        except OSError:
            continue
        if is_cloud_placeholder(st):
            ok += st.st_size == inv[cp].get("大小")  # 不下載占位檔，只比大小
        else:
            try:
                ok += file_hash(p) == inv[cp]["指紋"]
            except PermissionError:
                continue  # 開著的檔案讀不到，這一份不算
    return ok, len(picked)


def op_move(kb, sources, a, turn):
    if len(a.target) != 2:
        raise Refuse("改路徑要寫代號與新路徑")
    sec = find_section(sources, a.target[0])
    new_path = os.path.abspath(a.target[1])
    check_path(kb, sources, new_path, ignore_code=sec["代號"])
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    ok, n = sample_match(sec, new_path, inv)
    matched = n == 0 or ok / n >= MATCH_RATIO
    if not matched and not a.confirmed:
        cards = section_cards(kb, sec["代號"])
        count = survey(new_path, sources["排除"])
        print("要先問客戶（什麼都還沒做）：")
        print(f"- 新位置的檔案和「{sec['名稱']}」原本的對不上（抽樣 {n} 份只有 {ok} 份相同），不像是同一個資料夾搬家")
        print(f"- 要做的話會當成拿掉舊的、加新的：舊的筆記 {len(cards)} 張刪除（有備份），新位置的檔案重新整理")
        print_survey(new_path, count, warnings(new_path, count))
        raise Ask()
    snapshot(kb, turn)
    old_path = sec["路徑"]
    if not matched:
        removed = drop_section_notes(kb, sec)
    sec["路徑"] = str(Path(new_path).resolve())
    if not matched:
        sec["待試讀"] = True
    write_json_atomic(kb / SOURCES_FILE, sources)
    settings_dirs(kb, add=[sec["路徑"]], remove=[old_path] if not any(
        norm(s["路徑"]) == norm(old_path) for s in sources["分區"]) else [])
    record(kb, turn, "資料夾改路徑", sec["代號"], 名稱=sec["名稱"], 舊路徑=old_path, 新路徑=sec["路徑"], 對得上=matched)
    if matched:
        log_change(kb, f"「{sec['名稱']}」改路徑：{old_path} → {sec['路徑']}（抽樣 {n} 份、{ok} 份相同）")
        print(f"已改路徑：「{sec['名稱']}」{old_path} → {sec['路徑']}（抽樣 {n} 份、{ok} 份相同；筆記不用重做）。")
        print("這個對話可能還讀不到新位置：要回原檔核對時請客戶開新對話。")
    else:
        todo = add_inventory(kb, sources, sec)
        reindex(kb)
        log_change(kb, f"「{sec['名稱']}」改路徑（對不上，當成拿掉舊的、加新的）：刪除筆記 {len(removed)} 張")
        print(f"已改路徑並拿掉舊的筆記 {len(removed)} 張；新位置待製卡 {todo} 份。")
        after_add_hint(sec["名稱"], sec["代號"], todo)


def exclusion_rule(sources, target):
    """{代號}/資料夾 → 只套用那一區的規則；其他寫法（「私人」「*.bak」）照舊套用到所有分區。"""
    t = target.replace("\\", "/").strip().rstrip("/")
    if ".." in t.split("/"):
        raise Refuse("規則不能含「..」")
    if t.startswith("{"):
        code, sep, rel = t[1:].partition("}/")
        if not sep or not rel:
            raise Refuse(f"要寫成 {{代號}}/資料夾：{target}")
        find_section(sources, code)
        return "{" + code + "}/" + rel
    if os.path.isabs(target):
        raise Refuse("請寫 {代號}/資料夾，或檔名規則（例如 *.bak）")
    return t


def rule_hint(sources, rule):
    """排除規則對不到檔案時的提示：第一段是某個分區的名稱或代號，多半是少了大括號。"""
    first, _, rest = rule.partition("/")
    for s in sources["分區"]:
        if not rule.startswith("{") and rest and first in (s["名稱"], s["代號"]):
            return f"是不是要寫「{{{s['代號']}}}/{rest}」？只排除某一區的資料夾要用 {{代號}}/相對路徑 的寫法。"
    return "請確認路徑（只排除某一區的資料夾寫 {代號}/相對路徑，例如 {行政}/私人），或先用 預覽 看那個資料夾在哪。"


def affected(inv, rule):
    return sorted(cp for cp, e in inv.items() if e["狀態"] != "已刪除"
                  and is_excluded(cp.split("}/", 1)[1], [rule], e.get("分區")))


def is_card_link(target, names=None):
    t = unquote(target.split("#")[0].strip()).replace("\\", "/")
    parts = t.rsplit("/", 2)
    return len(parts) >= 2 and parts[-2] == "卡片" and (names is None or parts[-1] in names)


def strip_citations(text, names):
    """隱私排除：只引用這些卡片的句子整行刪掉；同一句還引用別的卡片的，只拿掉這些出處。頁首「引用的卡片」也拿掉。"""
    refs = parse_front_matter(text).get("引用的卡片")
    if isinstance(refs, list):
        text = set_front_matter(text, "引用的卡片", [c for c in refs if Path(str(c)).name not in names])
    head_end = text.find("\n---", 3) + 4 if text.startswith("---") else 0
    head, body = text[:head_end], text[head_end:]
    out = []
    for ln in body.split("\n"):
        targets = [t for _, t in LINK.findall(ln)]
        if not any(is_card_link(t, names) for t in targets):
            out.append(ln)
            continue
        if not any(is_card_link(t) and not is_card_link(t, names) for t in targets):
            continue  # 整句只出自排除的卡片
        new = LINK.sub(lambda m: "" if is_card_link(m.group(2), names) else m.group(0), ln)
        new = re.sub(r"〔[、，,\s]*〕", "", new)
        new = re.sub(r"〔[、，,\s]+", "〔", new)
        new = re.sub(r"[、，,\s]+〕", "〕", new)
        out.append(re.sub(r"、{2,}", "、", new))
    return head + "\n".join(out)


def purge_private(kb, cards, src_rules, turn, private_cps=()):
    """隱私排除：卡片直接刪（不留備份）、綜合頁拿掉那些句子；所有回合的備份裡，這些卡片刪掉、綜合頁舊版照同樣規則清掉，
    被覆蓋過的來源檔備份（source_edit.py）也刪掉。回傳改過的綜合頁數。"""
    names = {Path(c).name for c in cards}
    pages = 0
    for p in synthesis_pages(kb):
        text = p.read_text(encoding="utf-8")
        if not cites(text, names):
            continue
        backup_page(kb, p.relative_to(kb).as_posix())
        write_text_atomic(p, strip_citations(text, names))
        pages += 1
    for c in cards:
        if (kb / c).exists():
            os.remove(long_path(kb / c))
    root = kb / VERSIONS_DIR
    for vdir in (d for d in root.iterdir() if d.is_dir()) if root.exists() else []:
        for c in cards:
            b = vdir / "檔案" / c
            if b.exists():
                os.remove(long_path(b))
        files_dir = vdir / "檔案" / WIKI
        for b in files_dir.rglob("*.md") if files_dir.exists() else []:
            rel = b.relative_to(vdir / "檔案").as_posix()
            if rel.split("/")[1:2] == ["跨區綜合"] or "/綜合/" in rel:
                text = b.read_text(encoding="utf-8")
                if cites(text, names):
                    write_text_atomic(b, strip_citations(text, names))
        src_dir = vdir / "來源"
        for b in list(src_dir.rglob("*")) if src_dir.exists() else []:
            if b.is_file():
                code, _, rel = b.relative_to(src_dir).as_posix().partition("/")
                if is_excluded(rel, src_rules, code):
                    os.remove(long_path(b))
    # 待處理.md 裡寫到這些檔名的列（讀不到的檔案、等更新的資料）也拿掉：檔名本身可能透露內容
    pend = kb / PENDING_FILE
    if pend.exists() and private_cps:
        with FileLock(pend):
            lines = pend.read_text(encoding="utf-8").splitlines()
            keep = [ln for ln in lines if not (ln.startswith("|") and any(cp in ln for cp in private_cps))]
            if len(keep) != len(lines):
                write_text_atomic(pend, "\n".join(keep) + "\n")
    return pages


def _profile_versions(kb):
    """總資料夾的客戶設定檔，加上所有回合備份裡的舊版（隱私排除時一起清）。"""
    out = [kb / PROFILE_FILE]
    root = kb / VERSIONS_DIR
    for vdir in (d for d in root.iterdir() if d.is_dir()) if root.exists() else []:
        b = vdir / "檔案" / PROFILE_FILE
        if b.exists():
            out.append(b)
    return out


def purge_profile(kb, rules, cps):
    """隱私排除時處理客戶設定檔的推測（決策 #41）：依據全在排除範圍的條目刪掉，還有其他依據的只拿掉那幾份；
    所有回合備份裡的設定檔照同樣規則清。沒有記依據的舊條目找出「可能相關」的：排除後已經沒有任何卡片提到它
    （卡片已先刪掉，所以比的是剩下的卡片），或名稱出現在被排除的檔名、資料夾名裡；交給 AI 列給客戶勾。
    訪談來的條目不動。回傳 {刪除, 拿掉依據, 可能相關: [(表, 名稱)]}。"""
    count = {"刪除": 0, "拿掉依據": 0, "可能相關": []}
    parts = set()
    for cp in cps:
        rel = cp.split("}/", 1)[-1]
        segs = rel.split("/")
        parts |= {s for s in segs[:-1] if len(s) >= 2} | {Path(segs[-1]).stem}
    remaining = card_texts(kb)

    def gone(b):
        code, _, rel = b[1:].partition("}/")
        return is_excluded(rel, rules, code)

    def fn(table, row, cells, tally=True):
        src = row.get("來源", "")
        if src.startswith("訪談"):
            return None
        basis = split_basis(row.get(BASIS, ""))  # 舊格式沒有依據欄：當成依據空白，一樣找可能相關的
        if not basis:
            name = cells[0]
            if tally and name and (not mentioned(name, remaining)
                                   or len(name) >= 2 and any(name in p or p in name for p in parts if len(p) >= 2)):
                count["可能相關"].append((table, name))
            return None
        keep = [b for b in basis if not gone(b)]
        if len(keep) == len(basis):
            return None
        if tally:
            count["刪除" if not keep else "拿掉依據"] += 1
        if not keep:
            return False
        new = list(cells)
        new[list(row).index(BASIS)] = "、".join(keep)
        return new

    paths = _profile_versions(kb)
    if paths[0].exists():
        backup_page(kb, PROFILE_FILE.as_posix())
        paths = _profile_versions(kb)  # 這一回合的備份也要清
    for i, p in enumerate(paths):
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8")
        new = edit_profile_tables(text, lambda t, r, c, first=(i == 0): fn(t, r, c, first))
        if new != text:
            write_text_atomic(p, new)
    return count


def op_forget_guesses(kb, sources, a, turn):
    """客戶勾了要刪的推測（隱私排除時列出的可能相關條目）：設定檔與所有備份裡一起刪，不能退回。"""
    want = set()
    for x in a.target:
        t, sep, n = x.replace("｜", "|").partition("|")  # 程式印的清單是全形「｜」，照抄也收
        if not sep or t.strip() not in GUESS_TABLES:
            raise Refuse(f"要寫成 \"表名|名稱\"，表名是 {'、'.join(GUESS_TABLES)} 其中一個：{x}")
        want.add((t.strip(), n.strip()))
    found = set()

    def fn(table, row, cells):
        if (table, cells[0]) in want and not row.get("來源", "").startswith("訪談"):
            found.add((table, cells[0]))
            return False
        return None

    paths = _profile_versions(kb)
    if not paths[0].exists():
        raise Refuse("找不到客戶設定檔")
    backup_page(kb, PROFILE_FILE.as_posix())
    for p in _profile_versions(kb):
        text = p.read_text(encoding="utf-8")
        new = edit_profile_tables(text, fn)
        if new != text:
            write_text_atomic(p, new)
    missing = want - found
    log_change(kb, f"刪除推測 {len(found)} 條（客戶要求不讓 AI 看到的資料，連備份刪除）")
    print(f"已刪除推測 {len(found)} 條（連備份裡的一起刪，無法退回）。回答裡只講條數，不要寫出內容。")
    if missing:
        print("找不到（或是訪談來的、不能刪）：" + "、".join(f"{t}|{n}" for t, n in sorted(missing)))


def op_exclude(kb, sources, a, turn):
    rule = exclusion_rule(sources, a.target[0])
    if a.kind not in (None, "隱私", "用不到") or (a.confirmed and not a.kind):
        raise Refuse("排除要寫 --種類 隱私 或 用不到：先讓客戶選是「不想讓 AI 看到」還是「只是用不到」，沒明確選就不做")
    inv_path = kb / INVENTORY_FILE
    inv = (read_json(inv_path, {}) or {}).get("檔案", {})
    cps = affected(inv, rule)
    existing = rule in sources["排除"]
    if existing:
        # 規則已經有了（服務人員手動加、或 init_kb --排除），但之前做過的筆記還在：只清這些殘留（0.10.1）
        cps = [cp for cp in cps if inv[cp].get("卡片")]
        if not cps:
            raise Refuse(f"已經排除了：{rule}（沒有留下的筆記）")
    elif not cps:
        # 對到 0 份不能當成完成：常見是少了大括號（「行政/私人」應該是「{行政}/私人」），
        # 客戶選了「不想讓 AI 看到」卻什麼都沒刪（0.11.1，e8 K1）。不寫入規則、什麼都不做
        raise Refuse(f"「{rule}」對不到任何檔案，什麼都沒做（也沒有寫入排除規則）。" + rule_hint(sources, rule))
    cards = [c for cp in cps if inv[cp].get("卡片") for c in card_family(kb, inv[cp]["卡片"])]
    pages = citing_pages(kb, cards)
    if not a.confirmed:
        print("要先問客戶（什麼都還沒做）：")
        if existing:
            print(f"- 「{rule}」已經排除了，但之前整理過的筆記還留著 {len(cards)} 張，引用到的整理頁 {len(pages)} 頁")
        else:
            print(f"- 排除「{rule}」：{len(cps)} 份檔案，其中有筆記的 {len(cards)} 張，引用到的整理頁 {len(pages)} 頁")
        if a.kind in (None, "隱私"):
            print("- ① 不想讓 AI 看到（--種類 隱私）：筆記、整理頁裡出自這些檔案的句子、備份全部刪掉，救不回來；之後想再讀要重新整理（會花時間和用量）")
        if a.kind in (None, "用不到"):
            print("- ② 只是用不到（--種類 用不到）：筆記拿掉、整理頁出處標「原檔已移出」，備份留著，之後說「退回上一版」還能救回來")
        raise Ask("把上面的事用白話告訴客戶、記進〈做到一半的事〉（等客戶回覆）。客戶明確選了 ① 或 ② 才執行："
                  "同一個指令加 --種類 隱私 或 --種類 用不到，再加 --客戶已同意；只回「好」不算選了，要再問一次。")
    snapshot(kb, turn)
    if not existing:
        sources["排除"].append(rule)
    if a.kind == "隱私" and rule not in sources.setdefault("隱私排除", []):
        sources["隱私排除"].append(rule)
    write_json_atomic(kb / SOURCES_FILE, sources)
    with FileLock(inv_path):
        data = read_json(inv_path, {}) or {"檔案": {}}
        files = data["檔案"]
        if a.kind == "隱私":
            n_pages = purge_private(kb, cards, [rule], turn, cps)
            prof = purge_profile(kb, [rule], cps)
            for cp in cps:
                files.pop(cp, None)  # 連清冊的紀錄也不留（救不回來）
        else:
            for cp in cps:
                e = files.get(cp)
                if e and e.get("卡片"):
                    remove_notes(kb, e, MOVED_OUT)
                elif e:
                    files.pop(cp)
            n_pages = len(pages)
        for d in {inv[cp].get("指紋") for cp in cps if inv[cp].get("指紋")}:
            regroup(files, d)
        write_json_atomic(inv_path, data)
    record(kb, turn, "資料夾排除", rule.split("}/")[0].lstrip("{") if rule.startswith("{") else "*", 規則=rule, 種類=a.kind)
    kind = "不想讓 AI 看到，連備份刪除、無法退回" if a.kind == "隱私" else "只是用不到，可以退回"
    prof_note = (f"、設定檔推測刪除 {prof['刪除']} 條、拿掉部分依據 {prof['拿掉依據']} 條" if a.kind == "隱私" else "")
    log_change(kb, f"排除「{rule}」（{kind}）：{len(cps)} 份、筆記 {len(cards)} 張、整理頁 {n_pages} 頁{prof_note}")
    reindex(kb)
    print(f"已排除「{rule}」（{kind}）：{len(cps)} 份檔案，刪除筆記 {len(cards)} 張，整理頁改了 {n_pages} 頁{prof_note}。")
    if a.kind == "隱私":
        print("這項無法退回。回答裡只講份數和資料夾名稱，不要寫出被刪的內容。")
        if prof["可能相關"]:
            print(f"客戶設定檔裡有 {len(prof['可能相關'])} 條沒有記依據、但可能出自這些檔案的推測（名稱出現在被排除的檔名、"
                  "資料夾名裡，或排除後已經沒有任何筆記提到）。列給客戶勾要刪哪幾條（客戶選了就是同意，確認過的條目也可以刪）：")
            for t, n in prof["可能相關"]:
                print(f"- {t}｜{n}")
            print("客戶勾了之後：folders.py 刪除推測 \"表名|名稱\" …（會連備份裡的一起刪）；客戶說都不用刪就不動。")


def op_unexclude(kb, sources, a, turn):
    t = a.target[0].replace("\\", "/").strip().rstrip("/")
    if t not in sources["排除"]:
        raise Refuse(f"沒有這條排除規則：{t}（現有：{'、'.join(sources['排除']) or '無'}）")
    snapshot(kb, turn)
    sources["排除"].remove(t)
    if t in sources.get("隱私排除", []):
        sources["隱私排除"].remove(t)
    write_json_atomic(kb / SOURCES_FILE, sources)
    record(kb, turn, "資料夾取消排除", t.split("}/")[0].lstrip("{") if t.startswith("{") else "*", 規則=t)
    log_change(kb, f"取消排除「{t}」")
    print(f"已取消排除「{t}」。下次更新時會把那些檔案當成新的整理進來（超過 30 份會先問客戶）。")


def fix_links(kb, old, new):
    """改分區名稱後，wiki 裡指到 wiki/<舊名稱>/ 的連結與頁首路徑改成新名稱（改之前先備份）。"""
    seg = [(re.compile(r"(^|/)" + re.escape(o) + r"(?=/)"), n) for o, n in ((old, new), (quote(old), quote(new)))]
    changed = []
    for p in sorted((kb / WIKI).rglob("*.md")):
        text = p.read_text(encoding="utf-8")

        def fix(m):
            target = m.group(2)
            t2 = target
            for rx, n in seg:
                t2 = rx.sub(lambda mm: mm.group(1) + n, t2)
            return m.group(0).replace(target, t2) if t2 != target else m.group(0)
        new_text = LINK.sub(fix, text).replace(f"wiki/{old}/", f"wiki/{new}/")
        if new_text != text:
            rel = p.relative_to(kb).as_posix()
            backup_page(kb, rel)
            write_text_atomic(p, new_text)
            changed.append(rel)
    return changed


def rename_dir(src, dst):
    """把資料夾改名；目的地已經有同名資料夾時（退回時頁面已先還原到舊位置），把沒有的檔案搬過去再刪掉來源。"""
    if not src.exists():
        return
    if not dst.exists():
        os.rename(long_path(src), long_path(dst))
        return
    for f in sorted(src.rglob("*")):
        if f.is_file():
            t = dst / f.relative_to(src)
            if not t.exists():
                t.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(long_path(f), long_path(t))
    shutil.rmtree(long_path(src))


def op_rename(kb, sources, a, turn):
    if len(a.target) != 2:
        raise Refuse("改名要寫代號與新名稱")
    sec = find_section(sources, a.target[0])
    old, new = sec["名稱"], a.target[1].strip()
    if old == new:
        raise Refuse("名稱一樣，不用改")
    check_name(sources, new, ignore_code=sec["代號"])
    out = Path(sources["成品區"]) if sources.get("成品區") else None
    if (kb / WIKI / new).exists() or (out and (out / new).exists()):
        raise Refuse(f"已經有叫「{new}」的資料夾了（wiki 或成品區），請換一個名稱")
    # 先改成品區（客戶可能開著裡面的檔案），失敗就什麼都沒改；wiki 改名失敗時把成品區改回來（0.10.1）
    out_moved = False
    if out and (out / old).exists():
        os.rename(long_path(out / old), long_path(out / new))  # 被鎖住時 PermissionError，結束碼 5
        out_moved = True
    try:
        if (kb / WIKI / old).exists():
            os.rename(long_path(kb / WIKI / old), long_path(kb / WIKI / new))
    except PermissionError:
        if out_moved:
            os.rename(long_path(out / new), long_path(out / old))
        raise
    snapshot(kb, turn)
    pages = fix_links(kb, old, new)
    inv_path = kb / INVENTORY_FILE
    with FileLock(inv_path):
        data = read_json(inv_path, {}) or {"檔案": {}}
        for e in data["檔案"].values():
            if str(e.get("卡片", "")).startswith(f"wiki/{old}/"):
                e["卡片"] = f"wiki/{new}/" + e["卡片"][len(f"wiki/{old}/"):]
        write_json_atomic(inv_path, data)
    sec["名稱"] = new
    write_json_atomic(kb / SOURCES_FILE, sources)
    record(kb, turn, "分區改名", sec["代號"], 舊名稱=old, 新名稱=new)
    log_change(kb, f"分區改名：「{old}」→「{new}」（代號 {sec['代號']} 不變，修正連結 {len(pages)} 頁）")
    reindex(kb)
    print(f"已把「{old}」改名為「{new}」：代號不變，wiki 與成品區的資料夾已改名，修正連結 {len(pages)} 頁。")
    print(f"總覽、總目錄文字裡寫的分區名稱，請用 Edit 改成「{new}」。")


def op_trial_done(kb, sources, a, turn):
    """新的一區試讀做完：拿掉「待試讀」記號，之後一般的製卡（batch.py 下一批）也會取這一區。"""
    sec = find_section(sources, a.target[0])
    if not sec.pop("待試讀", None):
        print(f"「{sec['名稱']}」沒有待試讀的記號，不用處理。")
        return
    write_json_atomic(kb / SOURCES_FILE, sources)
    print(f"「{sec['名稱']}」試讀完成，接著製卡：batch.py 下一批 --分區 {sec['代號']}")


# ---- 退回（versions.py 呼叫）----

def revert(kb, entries, vdir):
    """退回一個回合裡的資料夾管理：改名的資料夾改回，再還原來源清單、settings.json、清冊的快照。
    隱私排除不退回：規則留著，清冊裡那些檔案的紀錄也不放回來。頁面要先由 versions.py 還原。"""
    fe = [e for e in entries if e["動作"] in FOLDER_ACTIONS]
    if not fe:
        return []
    msgs = []
    keep_private = list(load_sources(kb).get("隱私排除", []))
    out = load_sources(kb).get("成品區")
    for e in reversed(fe):
        if e["動作"] == "分區改名":
            rename_dir(kb / WIKI / e["新名稱"], kb / WIKI / e["舊名稱"])
            if out:
                rename_dir(Path(out) / e["新名稱"], Path(out) / e["舊名稱"])
            msgs.append(f"  分區名稱改回：「{e['新名稱']}」→「{e['舊名稱']}」")
        elif e["動作"] == "資料夾排除" and e.get("種類") == "隱私":
            msgs.append(f"  這項無法退回：排除「{e['規則']}」時選了不想讓 AI 看到，筆記和備份已經刪掉")
        else:
            what = e.get("名稱") or e.get("規則") or e["代號"]
            msgs.append(f"  退回：{e['動作']}「{what}」")
    snap = vdir / SNAP
    if snap.exists():
        had = set(read_json(snap / "有哪些.json", []) or [])
        with FileLock(kb / INVENTORY_FILE):
            for rel in (SOURCES_FILE, SETTINGS, INVENTORY_FILE):
                if rel.as_posix() in had:
                    shutil.copy2(long_path(snap / rel), long_path(kb / rel))
                elif (kb / rel).exists() and rel != INVENTORY_FILE:
                    os.remove(long_path(kb / rel))
    if keep_private:
        s = load_sources(kb)
        for r in keep_private:
            if r not in s["排除"]:
                s["排除"].append(r)
            if r not in s.setdefault("隱私排除", []):
                s["隱私排除"].append(r)
        write_json_atomic(kb / SOURCES_FILE, s)
        inv_path = kb / INVENTORY_FILE
        with FileLock(inv_path):
            data = read_json(inv_path, {}) or {"檔案": {}}
            data["檔案"] = {cp: e for cp, e in data["檔案"].items()
                          if not is_excluded(cp.split("}/", 1)[1], keep_private, e.get("分區"))}
            write_json_atomic(inv_path, data)
    return msgs


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["預覽", "加入", "拿掉", "改路徑", "排除", "取消排除", "改名", "試讀完成", "刪除推測"])
    ap.add_argument("target", nargs="+")
    ap.add_argument("--名稱", dest="name")
    ap.add_argument("--代號", dest="code")
    ap.add_argument("--說明", dest="desc")
    ap.add_argument("--共用", dest="shared")
    ap.add_argument("--AI產出", dest="ai_out", help="資料夾內 或 中央（AI 起草的文件放哪，0.13.0）")
    ap.add_argument("--種類", dest="kind")
    ap.add_argument("--客戶已同意", dest="confirmed", action="store_true")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    sources = load_sources(kb)
    ops = {"預覽": op_preview, "加入": op_add, "拿掉": op_remove, "改路徑": op_move,
           "排除": op_exclude, "取消排除": op_unexclude, "改名": op_rename,
           "試讀完成": op_trial_done, "刪除推測": op_forget_guesses}
    try:
        if a.action == "預覽":
            op_preview(kb, sources, a)
        else:
            ops[a.action](kb, sources, a, current_turn(kb))
    except Refuse as e:
        print(f"拒絕（什麼都沒改）：{e}")
        sys.exit(3)
    except Ask as e:
        print(str(e) or "把上面的事用白話告訴客戶、記進〈做到一半的事〉（等客戶回覆）；客戶明確答應後，同一個指令加 --客戶已同意 再執行一次。")
        sys.exit(4)
    except PermissionError as e:
        name = Path(str(getattr(e, "filename", "") or "")).name or "有檔案"
        print(f"沒做完：{name} 正在使用中（可能是 Word、Excel 或檔案總管開著）。請客戶關掉後再說一次；不要自己重試。")
        sys.exit(5)


if __name__ == "__main__":
    main()
