"""環境檢查：Python、MarkItDown、pdfplumber、onnxruntime、Windows 長路徑；
Word、Excel 要用的（spec 4.9，0.13.0）：Node.js 與總資料夾 .system/node/ 的 docx 套件、Bash（Git for Windows）、
docx／xlsx 技能有沒有同步、桌面版 Word／Excel、LibreOffice（有就用，不裝）、VC++ 執行環境版本（只建議）。
掃描 PDF 轉圖片改用 pypdfium2（pdfplumber 附帶），不再需要 poppler。

onnxruntime 在舊版 Visual C++ 執行階段上會讓 Python 直接崩潰（try 接不住），
所以放在子程序裡試載入；失敗時轉換程式改用 magika 替身。
結果寫入 總資料夾/.system/環境.json，轉換程式會讀它。

偵測到桌面版 Word／Excel 或 LibreOffice、而且有 --知識庫 時，用 templates/自檢/ 的小檔實際重算、轉 PDF 各一次（Office 自檢）。

用法：python envcheck.py [--知識庫 路徑]
測試用環境變數：LLMWIKI_SKILLS_DIR（取代 ~/.claude/skills）
"""
import argparse
import glob
import json
import re
import os
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import ENV_FILE, NODE_DIR, find_kb, now_str, utf8_io, write_json_atomic  # noqa: E402
from office_tools import find_soffice, office_apps  # noqa: E402

VC_MIN = (14, 30)  # 低於這個版本 onnxruntime 可能讓 Python 崩潰（plugin 有替身，只建議更新）


STUB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_magika_stub")


def try_import(module, stub=False):
    """在子程序裡試載入，崩潰也不會拖垮本程式。stub=True 時先載入 magika 替身。"""
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    if stub:
        env["PYTHONPATH"] = STUB + os.pathsep + env.get("PYTHONPATH", "")
    try:
        r = subprocess.run([sys.executable, "-c", f"import {module}"],
                           capture_output=True, timeout=120, env=env)
        return r.returncode == 0
    except Exception:
        return False


def python_command_works():
    """掛鉤以 python 指令執行；實際跑一次，空殼或不存在都會失敗。"""
    exe = shutil.which("python")
    if not exe:
        return False
    try:
        r = subprocess.run([exe, "-c", "print('ok')"], capture_output=True, text=True, timeout=30)
        return r.stdout.strip() == "ok"
    except Exception:
        return False


def long_paths_enabled():
    if os.name != "nt":
        return True
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SYSTEM\CurrentControlSet\Control\FileSystem") as k:
            return winreg.QueryValueEx(k, "LongPathsEnabled")[0] == 1
    except OSError:
        return False


def kb_trusted(kb):
    """總資料夾有沒有在 Claude Code 按過「信任」（沒信任時 .claude/settings.json 的放行規則全部無效）。
    看的是 ~/.claude.json 的 projects.<路徑>.hasTrustDialogAccepted，上層資料夾信任過也算。
    這不是公開文件寫的格式：檔案讀不到或格式不同時回傳 None（看不出來），由服務人員自己確認（0.11.0）。"""
    p = os.environ.get("LLMWIKI_CLAUDE_JSON") or os.path.join(os.path.expanduser("~"), ".claude.json")
    try:
        with open(p, encoding="utf-8") as f:
            projects = json.load(f).get("projects")
    except (OSError, ValueError, AttributeError):
        return None
    if not isinstance(projects, dict):
        return None
    target = os.path.normcase(os.path.abspath(str(kb)))
    for key, v in projects.items():
        k = os.path.normcase(os.path.abspath(key)).rstrip("\\/")
        if isinstance(v, dict) and v.get("hasTrustDialogAccepted") and (target == k or target.startswith(k + os.sep)):
            return True
    return False


def node_version():
    exe = shutil.which("node")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=30)
        return r.stdout.strip() or None
    except Exception:
        return None


def bash_path():
    """Bash 工具要的 bash（Git for Windows）。"""
    exe = shutil.which("bash")
    if exe:
        return exe
    for v in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        for sub in (("Git", "bin", "bash.exe"), ("Programs", "Git", "bin", "bash.exe")):
            c = os.path.join(os.environ.get(v, ""), *sub)
            if os.path.isfile(c):
                return c
    return None


def skill_path(name):
    """docx／xlsx 技能：從客戶 claude.ai 帳號同步的（~/.claude/skills/synced/<帳號>/<名稱>），或自己裝的 anthropics/skills。"""
    root = os.environ.get("LLMWIKI_SKILLS_DIR") or os.path.join(os.path.expanduser("~"), ".claude", "skills")
    for pat in (os.path.join(root, "synced", "*", name, "SKILL.md"), os.path.join(root, name, "SKILL.md")):
        hits = sorted(glob.glob(pat))
        if hits:
            return os.path.dirname(hits[0])
    return None


def vc_runtime():
    """Visual C++ 2015-2022 執行環境版本（例如 "14.51.36231"）；查不到回傳 None。"""
    if os.name != "nt":
        return None
    import winreg
    for key in (r"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64",
                r"SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
                return str(winreg.QueryValueEx(k, "Version")[0]).lstrip("v")
        except OSError:
            continue
    return None


def version_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:2])


SELF_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates", "自檢")


def office_selfcheck(kb, has_excel, has_word, has_lo):
    """用 plugin 附的小測試檔，實際呼叫 office_tools 的重算與轉 PDF 各一次（只在 --知識庫 模式、偵測到辦公軟體時）。
    測試檔複製到 .system/暫存/，用完刪掉。回傳（給人看的一行, 有沒有失敗）。"""
    import office_tools as ot
    from kbcommon import TEMP_DIR
    tmp = os.path.join(str(kb), str(TEMP_DIR))
    os.makedirs(tmp, exist_ok=True)
    parts, failed = [], False
    stamp = now_str().replace(":", "").replace(" ", "_")
    x = os.path.join(tmp, f"自檢_{stamp}.xlsx")
    if has_excel or has_lo:
        shutil.copy2(os.path.join(SELF_DIR, "自檢.xlsx"), x)
        try:
            line, _ = ot.recalc(kb, x)
            import zipfile
            with zipfile.ZipFile(x) as z:
                sheets = "".join(z.read(n).decode("utf-8", "ignore") for n in z.namelist() if n.startswith("xl/worksheets/"))
            right = re.search(r'<c r="A3"[^>]*>.*?<v>300(?:\.0+)?</v>', sheets, re.S) is not None
            if line.startswith("結果：已重算") and right:
                parts.append("重算 ✓" + line[len("結果：已重算"):])
            else:
                failed = True
                parts.append("重算 ✗（" + (line[3:] if not line.startswith("結果：已重算") else "重算後數字不對") + "）")
        except Exception as e:
            failed = True
            parts.append(f"重算 ✗（{type(e).__name__}: {str(e)[:120]}）")
        finally:
            if os.path.exists(x):
                os.remove(x)
    else:
        parts.append("重算 —（沒有桌面版 Excel、LibreOffice：打開時重算）")
    d = os.path.join(tmp, f"自檢_{stamp}.docx")
    if has_word or has_lo:
        shutil.copy2(os.path.join(SELF_DIR, "自檢.docx"), d)
        pdf = None
        try:
            pdf, how, _ = ot.convert(kb, d, "轉PDF")
            parts.append(f"轉 PDF ✓（{how}）")
        except Exception as e:
            failed = True
            parts.append(f"轉 PDF ✗（{str(e)[:160]}）")
        finally:
            for p in (d, pdf):
                if p and os.path.exists(p):
                    os.remove(p)
    else:
        parts.append("轉 PDF —（沒有桌面版 Word、LibreOffice：不給 PDF）")
    return "／".join(parts), failed


TRUST_HOW = ("請在總資料夾開一次 Claude Code（桌面版選這個資料夾、或在這個資料夾執行 claude），"
             "跳出「是否信任這個資料夾」時按信任。沒信任時，總資料夾設定的放行規則（讀來源資料夾、寫成品區、"
             "執行 plugin 程式、讀 plugin 的規則）全部不生效，客戶每一步都會被問、自動模式也會被擋")


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()

    onnx = try_import("onnxruntime")
    result = {
        "檢查時間": now_str(),
        "Python": sys.version.split()[0],
        "Python 路徑": sys.executable,
        "MarkItDown": try_import("markitdown", stub=not onnx),
        "pdfplumber": try_import("pdfplumber"),
        "onnxruntime": onnx,
        "Windows 長路徑": long_paths_enabled(),
        "pypdfium2": try_import("pypdfium2"),
        "使用 magika 替身": not onnx,
        "python 指令": python_command_works(),
        "Node.js": node_version() or "沒有",
        "Bash": bash_path() or "沒有",
        "docx 技能": skill_path("docx") or "沒有",
        "xlsx 技能": skill_path("xlsx") or "沒有",
        "桌面版 Word": "Word" in office_apps(),
        "桌面版 Excel": "Excel" in office_apps(),
        "LibreOffice": find_soffice() or "沒有",
        "VC++ 執行環境": vc_runtime() or "查不到",
    }

    problems = []
    if sys.version_info < (3, 10):
        problems.append("Python 版本低於 3.10，請安裝新版")
    if not result["MarkItDown"]:
        problems.append('MarkItDown 未安裝：pip install "markitdown[docx,pptx,xlsx,xls,pdf]"')
    if not result["pdfplumber"]:
        problems.append("pdfplumber 未安裝（PDF 逐頁轉換需要）：pip install pdfplumber")
    if not result["onnxruntime"]:
        problems.append("onnxruntime 無法載入：轉換時自動改用替身，不影響使用（安裝新版 Visual C++ 可轉散發套件可解決）")
    if not result["python 指令"]:
        problems.append("PATH 上的 python 指令無法執行（不存在，或是 Windows 商店的空殼）：掛鉤（原檔保護與備份）需要它。"
                        "請安裝 Python 時勾選加入 PATH，並在「設定 → 應用程式 → 進階應用程式設定 → 應用程式執行別名」關閉 python.exe")
    if not result["pypdfium2"]:
        problems.append("pypdfium2 無法載入（pdfplumber 會一起裝）：掃描 PDF 的頁轉不成圖片。請重裝：pip install pdfplumber")
    vc = result["VC++ 執行環境"]
    if vc != "查不到" and version_tuple(vc) < VC_MIN:
        problems.append(f"建議（不必裝）：Visual C++ 執行環境是 {vc}，低於 14.30。onnxruntime 已自動改用替身、不影響使用；"
                        "更新要管理員權限，客戶同意再裝")
    if result["Bash"] == "沒有":
        problems.append("沒有 Bash（Git for Windows）：plugin 程式改用 PowerShell 執行，中文路徑可能一直跳出核准詢問。"
                        "可以裝 winget install Git.Git（不用管理員；桌面版是否一定需要，待端到端確認）")
    office = []
    if result["docx 技能"] == "沒有" or result["xlsx 技能"] == "沒有":
        office.append("看不到 docx／xlsx 技能：客戶的 claude.ai 帳號要開啟文件技能（同步到 ~/.claude/skills/synced/）；"
                      "同步不到時改裝 GitHub 上的 anthropics/skills")
    if result["Node.js"] == "沒有":
        office.append("沒有 Node.js（docx 技能產生新 Word 要用）：winget install OpenJS.NodeJS.LTS，或官方 zip 版解壓縮後加進使用者 PATH（不用管理員）")
    if not result["Windows 長路徑"]:
        problems.append("Windows 長路徑未開啟：程式已用長路徑方式讀檔，一般不影響")
    kb = find_kb(a.kb) if a.kb else find_kb()
    if kb:
        has_docx = os.path.isfile(os.path.join(str(kb), str(NODE_DIR), "node_modules", "docx", "package.json"))
        result["docx 套件"] = "有" if has_docx else "沒有"
        if not has_docx and result["Node.js"] != "沒有":
            office.append(f'總資料夾沒有 npm 的 docx 套件：npm install docx --prefix "{os.path.join(str(kb), str(NODE_DIR))}"')
    if office:
        problems += office
    new_word = result["docx 技能"] != "沒有" and result["Node.js"] != "沒有" and (not kb or result.get("docx 套件") == "有")
    result["Word、Excel"] = ("可以產生與修改" if new_word and result["xlsx 技能"] != "沒有"
                            else "做不了 Word（見問題；建置照常完成，記給服務人員）")
    tools = [x for x, ok in (("桌面版 Word", result["桌面版 Word"]), ("桌面版 Excel", result["桌面版 Excel"]),
                              ("LibreOffice", result["LibreOffice"] != "沒有")) if ok]
    result["重算與轉 PDF"] = ("用 " + "、".join(tools)) if tools else \
        "輕量：Excel 改完設打開時重算、不給 PDF、舊版 .doc 請客戶另存（不幫客戶裝辦公軟體）"
    if a.kb and kb and tools:  # 只在 --知識庫 模式（build-setup 建好總資料夾後那一次）
        # 這台開發機沒有 Office，COM 第一次真的執行會在客戶電腦：建置當場實際跑一次，知道能不能用（0.13.0）
        checked, failed = office_selfcheck(kb, result["桌面版 Excel"], result["桌面版 Word"], result["LibreOffice"] != "沒有")
        result["Office 自檢"] = checked
        if failed:
            problems.append(f"Office 自檢沒過（{checked}）：客戶的檔案照輕量做法（Excel 改完打開時才重算、不給 PDF），"
                            "跟客戶說「這台電腦的 Office 沒辦法在背景幫你重算或轉 PDF」；記進〈等服務人員處理〉附這行原因")
    if kb:
        trusted = kb_trusted(kb)
        result["總資料夾已信任"] = {True: "是", False: "否", None: "看不出來"}[trusted]
        if trusted is False:
            problems.append("總資料夾還沒被信任：" + TRUST_HOW)
        elif trusted is None:
            problems.append("看不出總資料夾有沒有被信任（讀不到 Claude Code 的設定）：" + TRUST_HOW + "。按過就不用再按")
    result["問題"] = problems

    if kb:
        write_json_atomic(kb / ENV_FILE, result)
    print(json.dumps(result, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
