"""改既有 Word、Excel 之前先檢查有沒有「改了可能壞掉」的元素（spec 4.9〈風險元素偵測〉，0.13.0）。

只打開壓縮檔看裡面的 XML，不需要 Office，也不改檔案。印三段：「找到的元素」「改之前先告訴客戶」「不改」，
最後一行是結論。--複製到暫存：可以改時，順便把原檔複製到 .system/暫存/（AI 在副本上改；用 cp 會被掛鉤擋）。

用法：python office_check.py <{代號}/相對路徑 或 完整路徑> [--複製到暫存] [--知識庫 路徑]
結束碼：0 可以改（有「改之前先告訴客戶」也是 0）；3 不改（原因印在「不改」）；5 檔案正在使用中，複製不了
"""
import argparse
import os
import re
import shutil
import sys
import zipfile
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from kbcommon import TEMP_DIR, long_path, require_kb, resolve_code_path, utf8_io  # noqa: E402

WORD_EXTS = (".docx", ".docm")
EXCEL_EXTS = (".xlsx", ".xlsm")
OLD_EXTS = {".doc": "Word", ".xls": "Excel", ".rtf": "Word"}
OLE_MAGIC = b"\xd0\xcf\x11\xe0"  # 舊版 Office 或加密的 Office 檔
HYPERLINK = "relationships/hyperlink"

TELL_REVISION = "檔案裡還有沒處理完的修訂：我只加自己的修訂（作者「AI 助理」），不會接受或拒絕原本的"
TELL_COMMENT = "檔案裡有註解：註解會保留，我不會動"
TELL_LAYOUT = "這些部分我不會動，排版可能受影響：{}"
TELL_CHART = "圖表和樞紐分析表會跟著資料更新"
TELL_FORMAT = "格式可能跑掉，改完請檢查：{}"


def _read(z, name):
    return z.read(name).decode("utf-8", "ignore") if name in z.namelist() else ""


def _all(z, pattern):
    return "".join(_read(z, n) for n in z.namelist() if re.match(pattern, n))


def word(z, ext):
    names = z.namelist()
    doc = _read(z, "word/document.xml")
    heads = _all(z, r"word/header\d*\.xml$")
    rels = _read(z, "word/_rels/document.xml.rels")
    ext_links = [m for m in re.findall(r"<Relationship\b[^>]*>", rels)
                 if 'TargetMode="External"' in m and HYPERLINK not in m]
    found = {
        "追蹤修訂": len(re.findall(r"<w:(?:ins|del|moveFrom|moveTo)\b", doc)),
        "註解": len(re.findall(r"<w:comment\b", _read(z, "word/comments.xml"))),
        "目錄": 1 if re.search(r"TOC\s+\\", doc) else 0,
        "頁首圖片": len(re.findall(r"<w:drawing>|<v:imagedata", heads)),
        "表格": doc.count("<w:tbl>"),
        "文字方塊": len(re.findall(r"<w:txbxContent", doc)),
        "內容控制項": len(re.findall(r"<w:sdt>", doc)),
        "嵌入物件": len(re.findall(r"<w:object\b", doc)) + len([n for n in names if n.startswith("word/embeddings/")]),
        "外部連結": len(ext_links),
        "巨集": 1 if "word/vbaProject.bin" in names else 0,
    }
    tell, refuse = [], []
    if found["巨集"] or ext == ".docm":
        refuse.append("有巨集（.docm）：不改。請客戶用 Word 另存成 .docx（不含巨集）後再說一次")
    if found["追蹤修訂"]:
        tell.append(TELL_REVISION)
    if found["註解"]:
        tell.append(TELL_COMMENT)
    layout = [k for k in ("文字方塊", "內容控制項", "嵌入物件", "外部連結") if found[k]]
    if layout:
        tell.append(TELL_LAYOUT.format("、".join(layout)))
    return found, tell, refuse


def excel(z, ext):
    names = z.namelist()
    sheets = _all(z, r"xl/worksheets/sheet\d+\.xml$")
    found = {
        "公式": len(re.findall(r"<f[ >/]", sheets)),
        "圖表": len([n for n in names if re.match(r"xl/charts/chart\d+\.xml$", n)]),
        "樞紐分析表": len([n for n in names if re.match(r"xl/pivotTables/pivotTable\d+\.xml$", n)]),
        "巨集": 1 if "xl/vbaProject.bin" in names else 0,
        "格式化條件": len(re.findall(r"<conditionalFormatting\b", sheets)),
        "資料驗證": len(re.findall(r"<dataValidation\b", sheets)),
        "合併儲存格": len(re.findall(r"<mergeCell\b", sheets)),
        "外部連結": len([n for n in names if re.match(r"xl/externalLinks/externalLink\d+\.xml$", n)]),
        "交叉分析篩選器": len([n for n in names if re.match(r"xl/slicers?/", n) or re.match(r"xl/slicerCaches/", n)]),
        "走勢圖": len(re.findall(r"<(?:\w+:)?sparklineGroup\b", sheets)),
        "表單控制項": len([n for n in names if n.startswith("xl/ctrlProps/")]) + len(re.findall(r"<(?:\w+:)?formControlPr\b", sheets)),
    }
    tell = []
    if found["圖表"] or found["樞紐分析表"]:
        tell.append(TELL_CHART)
    fmt = [k for k in ("外部連結", "交叉分析篩選器", "走勢圖", "表單控制項") if found[k]]
    if fmt:
        tell.append(TELL_FORMAT.format("、".join(fmt)))
    return found, tell, []


def check(path):
    """回傳 (找到的元素 dict, 先告訴客戶 list, 不改 list)。"""
    ext = path.suffix.lower()
    if ext in OLD_EXTS:
        return {}, [], [f"舊版格式（{ext}）：不改。請客戶用 {OLD_EXTS[ext]} 另存成新格式"
                        f"（{'.docx' if OLD_EXTS[ext] == 'Word' else '.xlsx'}）；或可以先轉成新格式"
                        "（office_tools.py 轉新格式），轉出的新檔照「改既有檔」流程另存（AI 修改）（rules/office.md 第四節）"]
    if ext not in WORD_EXTS + EXCEL_EXTS:
        return {}, [], [f"{ext or '這種'} 檔不是 Word、Excel：不改（PDF、PowerPoint、圖片改成產出新檔）"]
    with open(long_path(path), "rb") as f:
        head = f.read(4)
    if head == OLE_MAGIC:
        # 加密的 Office 檔和舊版 .doc、.xls 的檔頭一樣，分不出來（0.13.1）
        return {}, [], ["打不開或不是新格式（可能有密碼，或其實是舊版檔改了副檔名）：不改。"
                        "請客戶確認：有密碼就提供沒有密碼的版本；是舊版檔就用 Word、Excel 另存成新格式"]
    try:
        with zipfile.ZipFile(long_path(path)) as z:
            return word(z, ext) if ext in WORD_EXTS else excel(z, ext)
    except zipfile.BadZipFile:
        return {}, [], ["檔案打不開（不是正常的 Word、Excel 檔，可能已損壞）：不改"]


def to_temp(kb, path):
    d = kb / TEMP_DIR
    d.mkdir(parents=True, exist_ok=True)
    dest = d / path.name
    i = 2
    while os.path.exists(long_path(dest)):
        dest = d / f"{path.stem} ({i}){path.suffix}"
        i += 1
    shutil.copy2(long_path(path), long_path(dest))
    return dest


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--複製到暫存", dest="copy", action="store_true", help="可以改時，把原檔複製到 .system/暫存/")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    path = resolve_code_path(kb, a.file) if a.file.startswith("{") else Path(os.path.abspath(a.file))
    if not os.path.isfile(long_path(path)):
        print(f"不改：找不到檔案 {a.file}")
        sys.exit(3)
    try:
        found, tell, refuse = check(path)
    except PermissionError:
        print(f"沒做：{path.name} 正在使用中，讀不到。請客戶把檔案關掉後再說一次。")
        sys.exit(5)
    print(f"檔案：{path.name}")
    print("找到的元素：" + ("、".join(f"{k} {v}" for k, v in found.items() if v) or "沒有特別的元素"))
    print("改之前先告訴客戶：" + ("" if tell else "沒有"))
    for t in tell:
        print(f"- {t}")
    print("不改：" + ("" if refuse else "沒有"))
    for r in refuse:
        print(f"- {r}")
    if refuse:
        print("結論：不改。用白話把「不改」的原因告訴客戶，原檔不動。")
        sys.exit(3)
    if a.copy:
        try:
            dest = to_temp(kb, path)
        except PermissionError:
            print(f"沒做：{path.name} 正在使用中，複製不了。請客戶把檔案關掉後再說一次。")
            sys.exit(5)
        print(f"暫存副本：{dest}")
    print("結論：可以改" + ("（動手前的複述多說上面幾句）" if tell else "") +
          "。在暫存副本上改，照 rules/office.md 另存「（AI 修改）」，原檔不動。")


if __name__ == "__main__":
    main()
