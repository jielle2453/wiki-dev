"""magika 的替身。

magika 依賴 onnxruntime，而 onnxruntime 在 Visual C++ 執行階段較舊的 Windows 上會載入失敗。
MarkItDown 只用 magika 從內容猜檔案類型；回傳「無法判斷」時會退回用副檔名判斷。
"""


class _Result:
    status = "unavailable"
    prediction = None


class Magika:
    def identify_stream(self, stream):
        return _Result()
