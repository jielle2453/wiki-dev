"""AI 產出登記（spec 4.8、決策 #43）：AI 存到客戶看得到的地方的文件，記下「文字內容指紋」，
之後製卡時看指紋（不看放在哪裡）分出卡片的出處類別：原檔或 AI 產出。

文字內容指紋：把檔案轉成文字（同製卡的轉換 convert.py）、去掉所有空白後算 sha256。只是打開再存檔不算改過；
轉不出文字時退回用檔案指紋，並記下用的是哪一種。

什麼時候登記（不靠 AI 記得）：
  - 寫進成品區：掛鉤 hooks/output_log.py 在 Write、Edit 之後自動登記；AI 再用「登記 --參考」補參考的原檔
  - source_edit.py 新增：放進來源時自動登記（可帶 --參考、--來歷）
  - Word、Excel 定稿（spec 4.9，0.13.0）：「定稿」登記、補參考、把草稿歸檔到 .system/版本/<回合>/草稿/
製卡時：convert.py 轉換後直接比對這份清單，印出卡片頁首的「出處類別」「參考的原檔」「來歷」。

用法：
  python ai_output.py 登記 <檔案> [--參考 {代號}/路徑 ...] [--來歷 文字] [--放到 <成品區的資料夾>]
                                                              登記（或補參考的原檔）；--放到：先把 .system/暫存/ 的檔案搬進成品區
  python ai_output.py 查詢 <{代號}/路徑 或 檔案>             印出這份該寫的出處類別
  python ai_output.py 列出                                    列出登記過的文件
  python ai_output.py 存放位置 [--參考 {代號}/路徑 ...]      新文件該放哪裡（4.9 議題 C），印出目的地與下一步的指令
  python ai_output.py 定稿 <草稿> <檔案> [--參考 ...] [--放到 <成品區的資料夾>]
                                                              草稿轉成 Word／Excel 存好之後：登記、補參考、草稿歸檔、改動紀錄
清單：.system/AI產出清單.json
結束碼：0 完成；3 拒絕（原因印在最後，什麼都沒改）
"""
import argparse
import hashlib
import os
import re
import shutil
import sys
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from kbcommon import (AI_OUT_CENTRAL, AI_OUT_DIR, CHANGELOG_FILE, DRAFT_ACTIONS, DRAFT_DIR, INVENTORY_FILE,  # noqa: E402
                      PENDING_ONGOING, SYSTEM, TEMP_DIR, FileLock, ai_out_mode, append_pending,
                      append_turn_entry, code_path, current_turn, ensure_ongoing_section, file_hash, fm_value,
                      is_shared, load_sources, long_path, now_str, parse_front_matter, read_json, require_kb,
                      resolve_code_path, turn_dir, utf8_io, write_json_atomic)

REGISTRY = SYSTEM / "AI產出清單.json"
AI = "AI 產出"
ORIGINAL = "原檔"


def text_digest(text):
    """文字內容指紋：去掉所有空白（換行、縮排、全形空白）後的 sha256；沒有文字時回傳 None。"""
    norm = re.sub(r"\s+", "", text or "")
    return hashlib.sha256(norm.encode("utf-8")).hexdigest() if norm else None


def extract_text(kb, path):
    """用 convert.py 的轉換取出文字；轉不出來回傳 None。"""
    from convert import convert_office, convert_pdf, convert_text
    ext = Path(path).suffix.lower()
    try:
        if ext in (".txt", ".md", ".csv"):
            return convert_text(path)[0]
        if ext == ".pdf":
            return convert_pdf(path, kb)[0]
        if ext in (".docx", ".pptx", ".xlsx", ".xls"):
            return convert_office(path, kb)
    except Exception:
        return None
    return None


def fingerprints(kb, path, text=None):
    """(文字指紋或 None, 檔案指紋)。text 已經轉好時直接用（convert.py 傳進來，不用再轉一次）。"""
    t = text if text is not None else extract_text(kb, path)
    return text_digest(t), file_hash(path)


def load(kb):
    return read_json(kb / REGISTRY, {}) or {"檔案": []}


def norm_loc(p):
    return os.path.normcase(os.path.abspath(str(p)))


def register(kb, path, refs=(), quiet=False, history=None):
    """登記一份 AI 存出去的文件。同一個位置內容沒變時只補參考；內容變了（又改過草稿）就加一筆，參考沿用上一筆。
    history：卡片的來歷（例如「AI 修改自〈合約.docx〉」，0.13.0）；沒給時製卡寫「AI 起草（日期）」。"""
    path = Path(os.path.abspath(str(path)))  # 相對路徑也轉成絕對路徑再記（和掛鉤、source_edit 一致，0.12.1）
    if not os.path.exists(long_path(path)):
        if not quiet:
            print(f"找不到檔案：{path}")
        return None
    td, fd = fingerprints(kb, path)
    kind, digest = ("文字", td) if td else ("檔案", fd)
    refs = split_refs(refs)
    reg_path = kb / REGISTRY
    with FileLock(reg_path):
        data = load(kb)
        recs = data.setdefault("檔案", [])
        same_loc = [r for r in recs if norm_loc(r.get("位置", "")) == norm_loc(path)]
        hit = next((r for r in same_loc if r.get("文字指紋") == digest), None)
        if hit:
            hit["參考"] = split_refs(hit.get("參考", []) + refs)  # 舊的接成一串的也順便拆開
            rec = hit
        else:
            prev = same_loc[-1] if same_loc else {}
            rec = {"文字指紋": digest, "指紋種類": kind, "時間": now_str(), "位置": str(path),
                   "參考": split_refs(prev.get("參考", []) + refs)}
            if prev.get("來歷"):
                rec["來歷"] = prev["來歷"]
            recs.append(rec)
        if history:
            rec["來歷"] = history
        write_json_atomic(reg_path, data)
    if not quiet:
        print(f"已登記 AI 產出：{path.name}（{kind}指紋）" + (f"；參考的原檔：{'、'.join(rec['參考'])}" if rec["參考"] else ""))
    return rec


def match(kb, td, fd, path=None):
    """在登記清單裡找內容一樣的文件（不看位置）。同樣內容登記過好幾處時（例如同一份另存了兩次），
    先用這個位置自己的那一筆，參考與來歷才不會借到別處的（0.13.0）。"""
    hits = [r for r in reversed(load(kb).get("檔案", []))
            if (r.get("指紋種類") == "文字" and td and r.get("文字指紋") == td)
            or (r.get("指紋種類") == "檔案" and r.get("文字指紋") == fd)]
    if path is not None:
        here = [r for r in hits if norm_loc(r.get("位置", "")) == norm_loc(path)]
        if here:
            return here[0]
    return hits[0] if hits else None


REVIEWER = "AI 助理"  # 改既有 Word 時修訂標記的作者（rules/office.md）


def has_ai_revisions(path, author=REVIEWER):
    """這份 .docx 裡還有沒有作者是「AI 助理」的修訂（w:ins／w:del）。只看壓縮檔裡的 XML，不用 Office。
    不是 .docx、打不開時回傳 None（看不出來，照原本的判斷）。"""
    import zipfile
    if Path(path).suffix.lower() != ".docx":
        return None
    pat = re.compile(r'<w:(?:ins|del)\b[^>]*\bw:author="' + re.escape(author) + '"')
    try:
        with zipfile.ZipFile(long_path(path)) as z:
            for n in z.namelist():
                if n.startswith("word/") and n.endswith(".xml") and pat.search(z.read(n).decode("utf-8", "ignore")):
                    return True
    except (OSError, zipfile.BadZipFile):
        return None
    return False


def split_refs(refs):
    """--參考 可以給多次、一次給多個；舊寫法把兩份用逗號或頓號接成一個字串的也拆開（0.12.1 會記成一個元素）。
    只在下一段是「{代號}/」開頭時才拆，檔名裡本來就有的逗號不受影響。"""
    out = []
    for r in refs or []:
        for x in re.split(r"\s*[,，、;；]\s*(?=\{)", str(r).strip()):
            x = x.strip().strip('"').strip()
            if x and x not in out:
                out.append(x)
    return out


def code_path_of(kb, path):
    p = os.path.normcase(os.path.abspath(str(path)))
    for s in load_sources(kb)["分區"]:
        root = os.path.normcase(os.path.abspath(s["路徑"])).rstrip("\\/")
        if p.startswith(root + os.sep):
            return code_path(s["代號"], os.path.relpath(str(path), s["路徑"]).replace("\\", "/"))
    return None


def lookup(kb, path, text=None):
    """這份檔案的卡片該寫什麼出處：回傳 {出處類別, 參考的原檔, 來歷}。
    內容和登記過的 AI 產出一樣 → AI 產出；原本的卡片是 AI 產出、內容改了 → 原檔，來歷「最初由 AI 起草（日期），客戶改過」。"""
    td, fd = fingerprints(kb, path, text)
    rec = match(kb, td, fd, path)
    if rec:
        what = rec.get("來歷") or "AI 起草"  # 「（AI 修改）」檔是「AI 修改自〈原檔〉」（4.9）
        refs, day = split_refs(rec.get("參考", [])), rec.get("時間", "")[:10]
        if what.startswith("AI 修改自") and has_ai_revisions(path) is False:
            # 客戶在 Word 按了「全部接受」：文字指紋不變，但修訂標記沒了，算採用（議題 B，0.13.1）
            return {"出處類別": ORIGINAL, "參考的原檔": refs, "來歷": f"最初由 {what}（{day}），客戶已接受修訂"}
        return {"出處類別": AI, "參考的原檔": refs, "來歷": f"{what}（{day}）"}
    cp = code_path_of(kb, path)
    e = ((read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})).get(cp or "", {})
    card = kb / e["卡片"] if e.get("卡片") else None
    if card and card.exists():
        m = parse_front_matter(card.read_text(encoding="utf-8"))
        hist = str(m.get("來歷", "") or "")
        refs = m.get("參考的原檔") or []
        if str(m.get("出處類別", "")) == AI:
            # 「AI 起草（日期）」→「最初由 AI 起草（日期），客戶改過」；「AI 修改自〈原檔〉（日期）」同樣接上（4.9）
            d = re.search(r"\d{4}-\d{2}-\d{2}", hist)
            if not hist.startswith("AI ") or not d:
                hist = f"AI 起草（{d.group(0) if d else '日期不明'}）"
            return {"出處類別": ORIGINAL, "參考的原檔": refs, "來歷": f"最初由 {hist}，客戶改過"}
        if hist:
            return {"出處類別": ORIGINAL, "參考的原檔": refs, "來歷": hist}
    return {"出處類別": ORIGINAL, "參考的原檔": [], "來歷": ""}


def header_lines(info):
    """給製卡代理照抄進卡片頁首的幾行。"""
    lines = [f"出處類別: {info['出處類別']}"]
    if info["參考的原檔"]:
        lines.append(f"參考的原檔: {fm_value(info['參考的原檔'])}")
    if info["來歷"]:
        lines.append(f"來歷: {info['來歷']}")
    return lines


class Refuse(Exception):
    """不能做：印出原因，結束碼 3。"""


def _ncase(p):
    return os.path.normcase(os.path.abspath(str(p)))


def _inside(child, parent):
    c, p = _ncase(child), _ncase(parent).rstrip(os.sep)
    return c == p or c.startswith(p + os.sep)


def unique(p):
    """同名檔案已經存在時在檔名後加「 (2)」「 (3)」……，不覆蓋（同 source_edit.py）。"""
    p = Path(p)
    if not os.path.exists(long_path(p)):
        return p
    i = 2
    while os.path.exists(long_path(p.parent / f"{p.stem} ({i}){p.suffix}")):
        i += 1
    return p.parent / f"{p.stem} ({i}){p.suffix}"


def link(p):
    return f"[{Path(p).name}](<file:///{str(p).replace(os.sep, '/')}>)"


# ---- 存放位置（spec 4.9 議題 C）----

def placement(kb, refs):
    """新文件該放哪裡。回傳 dict：種類（來源／成品區）、位置（實際資料夾）、代號路徑（來源時）、原因。"""
    sources = load_sources(kb)
    files = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    codes = []
    refs = split_refs(refs)
    for r in refs:
        if not r.startswith("{") or "}" not in r:
            raise Refuse(f"參考的原檔要寫成 {{代號}}/相對路徑：{r}")
        code = r[1:].split("}", 1)[0]
        if not any(s["代號"] == code for s in sources["分區"]):
            raise Refuse(f"來源清單沒有分區代號 {code}")
        if code not in codes:
            codes.append(code)
    out = sources.get("成品區") or ""
    if not codes:
        return {"種類": "成品區", "位置": Path(out) / "跨區", "原因": "沒有參考任何原檔"}
    if len(codes) > 1:
        return {"種類": "成品區", "位置": Path(out) / "跨區", "原因": "參考的原檔在不同分區（" + "、".join(codes) + "）"}
    sec = next(s for s in sources["分區"] if s["代號"] == codes[0])
    if ai_out_mode(sec, files) == AI_OUT_CENTRAL:
        why = "和別人共用" if is_shared(sec) else "設定為放中央成品區（雲端同步資料夾預設如此）"
        return {"種類": "成品區", "位置": Path(out) / sec["名稱"], "原因": f"「{sec['名稱']}」{why}"}
    return {"種類": "來源", "位置": Path(sec["路徑"]) / AI_OUT_DIR, "代號路徑": "{" + sec["代號"] + "}/" + AI_OUT_DIR + "/",
            "原因": f"參考的原檔都在「{sec['名稱']}」", "共用": is_shared(sec)}


def print_placement(kb, refs):
    refs = split_refs(refs)
    p = placement(kb, refs)
    ref_args = " ".join(f'--參考 "{r}"' for r in refs)
    print(f"目的地：{p['位置']}（{p['原因']}）")
    if p["種類"] == "來源":
        print(f"放進來源最上層的「{AI_OUT_DIR}」資料夾（不存在會自動建立；不用客戶親口要求，複述一句就好）。")
        if p.get("共用"):
            print("這一區和別人共用：source_edit.py 會先要你問客戶（其他人也會看到）。")
        print("下一步（暫存檔是技能寫在 .system/暫存/ 的 Word 或 Excel）：")
        print(f'  1. source_edit.py 新增 "<暫存檔>" "{p["代號路徑"]}" {ref_args}'.rstrip())
        print('  2. ai_output.py 定稿 "<草稿>" "<source_edit 印出的 {代號}/… 路徑>"')
    else:
        print("放進中央成品區（成品區不製卡、不在「退回上一版」的範圍）。")
        print("下一步（暫存檔是技能寫在 .system/暫存/ 的 Word 或 Excel）：")
        print(f'  ai_output.py 定稿 "<草稿>" "<暫存檔>" --放到 "{p["位置"]}" {ref_args}'.rstrip())


def move_into_output(kb, src, dest_dir):
    """把 .system/暫存/ 的檔案搬進成品區（AI 不能用 Write 寫 Word、Excel，也不自己 cp）。回傳新位置。"""
    sources = load_sources(kb)
    out = sources.get("成品區")
    if not out:
        raise Refuse("來源清單沒有成品區")
    d = Path(dest_dir)
    if not d.is_absolute():
        d = Path(out) / d
    if not _inside(d, out):
        raise Refuse(f"--放到 只能是成品區裡的資料夾（{out}）；要放進來源請用 source_edit.py 新增")
    if not _inside(src, kb / TEMP_DIR):
        raise Refuse("--放到 的檔案要在總資料夾的 .system/暫存/（技能產生的檔案先寫在那裡）")
    if not os.path.isfile(long_path(src)):
        raise Refuse(f"找不到檔案：{src}")
    os.makedirs(long_path(d), exist_ok=True)
    dest = unique(d / Path(src).name)
    shutil.move(long_path(src), long_path(dest))
    return dest


# ---- 定稿（spec 4.9 新文件流程第 6 步）----

def draft_refs(draft):
    try:
        m = parse_front_matter(Path(long_path(draft)).read_text(encoding="utf-8-sig"))
    except OSError:
        return []
    v = m.get("參考") or []
    return [x for x in (v if isinstance(v, list) else [v]) if str(x).startswith("{")]


def log_change(kb, text):
    with open(long_path(kb / CHANGELOG_FILE), "a", encoding="utf-8") as f:
        f.write(f"\n[{now_str()}] AI 產出｜{text}\n")


def finalize(kb, draft_arg, file_arg, refs, put=None, history=None):
    d = Path(draft_arg)
    if not d.is_absolute():
        d = Path.cwd() / d if (Path.cwd() / d).exists() else kb / d
    draft = Path(os.path.abspath(str(d)))
    if not _inside(draft, kb / DRAFT_DIR) or not draft.is_file():
        raise Refuse(f"草稿要在總資料夾的 .system/草稿/ 裡：{draft_arg}")
    path = resolve_code_path(kb, file_arg) if file_arg.startswith("{") else Path(os.path.abspath(file_arg))
    if put:
        path = move_into_output(kb, path, put)
    elif not os.path.isfile(long_path(path)):
        raise Refuse(f"找不到存好的檔案：{file_arg}")
    elif _inside(path, kb / SYSTEM):
        raise Refuse("檔案還在 .system/ 裡：目的地在來源用 source_edit.py 新增，在成品區加 --放到 <成品區的資料夾>")
    refs = split_refs(draft_refs(draft) + list(refs))
    rec = register(kb, path, refs, quiet=True, history=history)
    turn = current_turn(kb)
    dst = unique(turn_dir(kb, turn) / "草稿" / draft.name)  # 同一回合定稿兩份同名草稿時不互蓋
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(long_path(draft), long_path(dst))
    append_turn_entry(kb, turn, {"路徑": f"{DRAFT_DIR.as_posix()}/{dst.name}", "動作": "草稿歸檔",
                                 "備份": f"草稿/{dst.name}", "檔案": str(path)})
    where = code_path_of(kb, path) or str(path)
    log_change(kb, f"定稿〈{path.name}〉存到 {where}（草稿已歸檔，說「退回上一版」可以拿回草稿）")
    print(f"已定稿：{link(path)}")
    print(f"已登記 AI 產出（{rec['指紋種類']}指紋）" + (f"；參考的原檔：{'、'.join(rec['參考'])}" if rec["參考"] else "；沒有參考的原檔"))
    print("草稿已歸檔到這一回合的版本資料夾（退回時會搬回 .system/草稿/）")
    if code_path_of(kb, path):
        print("檔案在來源裡：照 source_edit.py 印出的「要製卡」在同一個回答製卡（出處類別會自動是 AI 產出）。")
    else:
        print("檔案在成品區：不製卡；成品區不在「退回上一版」的範圍，退回時告訴客戶檔案還在。")


def revert_drafts(kb, entries, vdir):
    """退回定稿：草稿從 版本/<回合>/草稿/ 搬回 .system/草稿/，〈做到一半的事〉補一列「等客戶回覆」。"""
    msgs = []
    out = load_sources(kb).get("成品區") or ""
    for e in entries:
        if e["動作"] not in DRAFT_ACTIONS:
            continue
        if out and e.get("檔案") and _inside(e["檔案"], out):
            # 成品區不在退回範圍：換了對話也要能告訴客戶檔案還在（0.13.1）
            msgs.append(f"  成品區的檔案還在：{e['檔案']}，需要的話請客戶自己刪")
        src = vdir / e["備份"]
        if not src.exists():
            msgs.append(f"  沒有拿回草稿（備份不見了）：{e['路徑']}")
            continue
        back = unique(kb / DRAFT_DIR / src.name)
        back.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(long_path(src), long_path(back))
        ensure_ongoing_section(kb)
        name = Path(e.get("檔案", "")).name or Path(src).stem
        append_pending(kb, PENDING_ONGOING, f"| {now_str()} | 問客戶：〔起草〕{name} 要不要修改（退回後草稿拿回來了） | "
                                            f"草稿 {DRAFT_DIR.as_posix()}/{back.name}；確定後照 rules/office.md 再定稿 | 等客戶回覆 |")
        msgs.append(f"  草稿拿回來了：{DRAFT_DIR.as_posix()}/{back.name}")
    return msgs


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["登記", "查詢", "列出", "存放位置", "定稿"])
    ap.add_argument("files", nargs="*")
    ap.add_argument("--參考", dest="refs", action="extend", nargs="+", default=[],
                    help="{代號}/路徑，可以給多次或一次給多個（逗號、頓號接起來的也會拆開）")
    ap.add_argument("--來歷", dest="history", help="卡片的來歷，例如「AI 修改自〈合約.docx〉」")
    ap.add_argument("--放到", dest="put", help="成品區裡的資料夾：先把 .system/暫存/ 的檔案搬過去再登記")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    try:
        if a.action == "列出":
            recs = load(kb).get("檔案", [])
            print(f"登記過的 AI 產出 {len(recs)} 筆：")
            for r in recs:
                print(f"- {r.get('時間')}｜{r.get('位置')}｜{r.get('指紋種類')}指紋" + (f"｜參考 {'、'.join(r['參考'])}" if r.get("參考") else "")
                      + (f"｜{r['來歷']}" if r.get("來歷") else ""))
            return
        if a.action == "存放位置":
            print_placement(kb, a.refs)
            return
        if a.action == "定稿":
            if len(a.files) != 2:
                raise Refuse("定稿要兩個參數：草稿、存好的檔案（成品區時是暫存檔加 --放到）")
            finalize(kb, a.files[0], a.files[1], a.refs, a.put, a.history)
            return
        if len(a.files) != 1:
            raise Refuse("請指定一個檔案")
        f = a.files[0]
        path = resolve_code_path(kb, f) if f.startswith("{") else Path(f)
        if a.action == "登記":
            if a.put:
                path = move_into_output(kb, Path(os.path.abspath(str(path))), a.put)
            if register(kb, path, a.refs, history=a.history) is None:
                sys.exit(3)
            if a.put:
                print(f"已放進成品區：{link(path)}")
        else:
            if not os.path.exists(long_path(path)):
                sys.exit(f"找不到檔案：{f}")
            print("卡片頁首要寫：")
            print("\n".join(header_lines(lookup(kb, path))))
    except Refuse as e:
        print(f"拒絕（什麼都沒改）：{e}")
        sys.exit(3)


if __name__ == "__main__":
    main()
