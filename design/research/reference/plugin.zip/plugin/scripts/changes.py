"""比對：來源資料夾和清冊（上次整理時）相比，有哪些變動。只讀，不改任何檔案。

開對話時由掛鉤 hooks/session.py 呼叫（快速比對：只比時間與大小，必要時才算指紋）；
服務人員也可以直接執行，看目前的變動。套用變動用 update.py。

用法：python changes.py [--知識庫 路徑] [--全部]
"""
import argparse
import os
import sys

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from inventory import scan  # noqa: E402
from kbcommon import INVENTORY_FILE, load_sources, read_json, require_kb, utf8_io  # noqa: E402

HASH_LIMIT = 200 * 1048576  # 快速比對最多讀 200 MB 算指紋，避免開對話時卡住
SHOW = 10
# 要告訴客戶的變動（「未整理」是上次沒做完的，不算新的變動）
NOTICE = ("整區不見", "原檔不見", "預期刪除", "新增", "修改", "搬動", "雲端占位")


def detect(kb, quick=True):
    """回傳各類變動的清單；還沒有清冊（尚未盤點）時回傳 None。"""
    inv = read_json(kb / INVENTORY_FILE)
    if inv is None:
        return None
    old = inv.get("檔案", {})
    r = scan(load_sources(kb), old, quick=quick, hash_limit=HASH_LIMIT if quick else None)
    c = {k: [] for k in NOTICE + ("未整理",)}
    for cp, e in r["檔案"].items():
        prev = old.get(cp, {}).get("狀態")
        s = e["狀態"]
        if s == "待處理":
            c["未整理" if prev in ("待處理", "處理中") else "新增"].append(cp)
        elif s == "已變動":
            c["未整理" if prev == "已變動" else "修改"].append(cp)
        elif s == "處理中":
            c["未整理"].append(cp)
        elif s == "原檔已不存在":
            c["原檔不見"].append(cp)
        elif s == "預期刪除":
            c["預期刪除"].append(cp)
        elif s == "雲端占位" and prev != "雲端占位":
            c["雲端占位"].append(cp)
    c["搬動"] = [f"{a} → {b}" for a, b in r["搬動"]]
    c["整區不見"] = [f"{s['名稱']}（{s['路徑']}）" for s in r["不見的分區"]]
    return c


LABELS = {
    "整區不見": "整個來源資料夾找不到（問客戶；其他資料夾照常處理）",
    "原檔不見": "原檔不見（先問客戶是不是自己刪的）",
    "預期刪除": "客戶說過要自己刪、現在已經刪了（不用問，更新時直接拿掉筆記）",
    "新增": "新增",
    "修改": "修改",
    "搬動": "搬動或改名",
    "雲端占位": "只在雲端、還沒下載到電腦",
    "未整理": "上次沒整理完",
}


def report(c, show=SHOW):
    lines = []
    for k in NOTICE + ("未整理",):
        items = sorted(c[k])
        if items:
            unit = "個" if k == "整區不見" else "份"
            more = f"……等 {len(items)} {unit}" if len(items) > show else ""
            lines.append(f"- {LABELS[k]} {len(items)} {unit}：" + "、".join(items[:show]) + more)
    return lines


def has_notice(c):
    return bool(c) and any(c[k] for k in NOTICE)


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("--知識庫", dest="kb")
    ap.add_argument("--全部", dest="all", action="store_true", help="列出全部檔名（預設每類最多 10 個）")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    c = detect(kb, quick=False)
    if c is None:
        print("還沒有清冊（尚未盤點），沒有可以比對的對象。")
        return
    lines = report(c, show=10 ** 9 if a.all else SHOW)
    if not lines:
        print("比對結果：來源資料夾和上次整理時相同，沒有變動。")
        return
    print("比對結果（還沒套用）：")
    print("\n".join(lines))
    todo = len(c["新增"]) + len(c["修改"]) + len(c["未整理"])
    print(f"\n要製卡的合計 {todo} 份（新增＋修改＋上次沒整理完）。")


if __name__ == "__main__":
    main()
