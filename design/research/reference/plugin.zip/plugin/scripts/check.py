"""結構檢查：找出知識庫裡壞掉或對不上的地方，只回報、不修改。

檢查項目：
  1. 卡片記錄的原檔是否還在
  2. 清冊標為完成的檔案，卡片是否存在；有沒有清冊裡找不到的卡片
  3. 索引列的卡片數是否和實際卡片數一致
  4. wiki 裡頁面之間的連結是否斷掉
  5. 索引是否接近大小上限

用法：python check.py [--知識庫 路徑]
"""
import argparse
import os
import re
import sys
from pathlib import Path
from urllib.parse import unquote

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import (INVENTORY_FILE, WIKI, load_sources, long_path, parse_front_matter, read_json,  # noqa: E402
                      require_kb, resolve_code_path, utf8_io)

INDEX_WARN_BYTES = 80_000  # 約兩萬多字，接近一次讀取的合理上限
LINK = re.compile(r"\]\(<?([^)>]+)>?\)")


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    problems = structure_problems(require_kb(a.kb))
    if not problems:
        print("結構檢查：沒有發現問題")
        return
    print(f"結構檢查：發現 {len(problems)} 個問題")
    for kind, where in problems:
        print(f"- {kind}：{where}")


def structure_problems(kb):
    """回傳 [(問題種類, 位置)]。健檢程式 health.py 也用這個函式。"""
    sources = load_sources(kb)
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    problems = []

    inv_cards = {e["卡片"] for e in inv.values() if e.get("卡片")}
    for e in inv.values():
        if e.get("狀態") == "完成" and e.get("卡片") and not (kb / e["卡片"]).exists():
            problems.append(("清冊有、卡片不見", e["卡片"]))

    for s in sources["分區"]:
        d = kb / WIKI / s["名稱"]
        cards = list((d / "卡片").glob("*.md"))
        for c in cards:
            rel = c.relative_to(kb).as_posix()
            m = parse_front_matter(c.read_text(encoding="utf-8"))
            if not m.get("主卡") and rel not in inv_cards:
                problems.append(("清冊裡找不到這張卡片", rel))
            src = m.get("原檔")
            if not src:
                problems.append(("卡片沒有記錄原檔", rel))
                continue
            try:
                if not os.path.exists(long_path(resolve_code_path(kb, src, sources))):
                    problems.append(("原檔路徑失效", f"{rel} → {src}"))
            except KeyError as err:
                problems.append(("原檔的分區代號不存在", f"{rel}：{err}"))

        idx = d / "索引.md"
        if idx.exists():
            listed = 0
            for f in [idx, *(d / "索引").glob("*.md")]:
                listed += sum(1 for ln in f.read_text(encoding="utf-8").splitlines()
                              if ln.startswith("| [") and "卡片/" in ln)
                if f.stat().st_size > INDEX_WARN_BYTES:
                    problems.append(("索引接近大小上限，考慮拆子分區", f.relative_to(kb).as_posix()))
            if listed != len(cards):
                problems.append(("索引與卡片數不一致，請重建索引", f"{s['名稱']}：索引 {listed}、卡片 {len(cards)}"))

    for p in (kb / WIKI).rglob("*.md"):
        rel = p.relative_to(kb)
        for target in LINK.findall(p.read_text(encoding="utf-8")):
            t = unquote(target.split("#")[0].strip())
            if not t or re.match(r"^[a-z]+:", t, re.I):  # 網址、file: 連結略過
                continue
            if not (p.parent / t).exists():
                problems.append(("連結斷掉", f"{rel.as_posix()} → {t}"))
    return problems


if __name__ == "__main__":
    main()
