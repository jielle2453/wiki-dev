"""改原資料夾：客戶親口要求時，新增、複製進來、改名、搬動、改純文字檔，或記下「預期刪除」（spec 4.6）。

AI 不能直接寫來源（掛鉤 guard.py 會擋），只能經由這支程式；掛鉤只放行「整個指令就是 python 執行這支程式」。
每個動作都先全部檢查，有要先問客戶的情況就什麼都不做；檢查通過才備份、執行。
改動記進同一回合的 .system/版本/<回合>/清單.jsonl（動作：來源新增、來源搬動、來源覆蓋），「退回上一版」會一起退回；
直接更新清冊（搬動、改名的卡片改原檔位置；新增與改過內容的標待製卡），所以下次開對話不會再報成變動；
改動紀錄由程式記一行。

用法（原檔寫成 {代號}/相對路徑，也可以寫完整路徑；<目標> 結尾加 / 表示資料夾，檔名沿用原本的）：
  python source_edit.py 新增 <暫存檔> <目標>              AI 起草的檔案先寫在 .system/暫存/，再放進來源（暫存檔會移走）
  python source_edit.py 複製 <外部檔案> <目標>            下載資料夾、拖進對話的檔案複製進來源（總資料夾裡的檔案不行）
  python source_edit.py 改名 <原檔或資料夾> <新名稱>       同一個資料夾裡改名；沒寫副檔名會補上原本的，不能改副檔名
  python source_edit.py 搬動 <原檔或資料夾> [...] <目標資料夾>
  python source_edit.py 覆蓋 <暫存檔> <原檔>              改純文字檔內容（只限 .txt .md .csv），沿用原檔編碼、換行與 BOM
  python source_edit.py 預期刪除 <原檔> [...]             客戶說要自己刪：記下來，之後不見了直接拿掉筆記、不再問
共同參數：
  --客戶已同意   要先問客戶的情況（超過 10 份、共用的分區、搬到來源以外或排除清單裡），客戶答應後才加
  --只檢查       只看要不要先問，什麼都不做（結束碼 0 可以直接做、4 要先問）
  --合計 <份數>  客戶這一個要求的總份數。要分幾次呼叫時，先在第一個指令加 --只檢查 --合計 試算（0.10.1）
  --參考 <{代號}/路徑>  新增時：起草參考了哪些原檔（可以給多次）。新增的檔案會自動登記成 AI 產出（0.12.0）
  --來歷 <文字>  新增時：卡片的來歷，例如「AI 修改自〈合約.docx〉」（另存「（AI 修改）」時用，0.13.0）
新增到分區最上層的「AI 產出」資料夾（spec 4.9）不算進超過 10 份的門檻，但共用分區、排除清單照樣先問；
新增的 Excel 還沒重算（沒有 Office、LibreOffice 時）清冊記「公式待重算」，客戶用 Excel 打開存檔後才製卡。
  --知識庫 <路徑>

結束碼：0 完成；3 拒絕（原因印在最後）；4 要先問客戶（什麼都還沒做）；5 檔案正在使用中（請客戶關掉後再說一次）
"""
import argparse
import errno
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, HERE)
from inventory import GONE, regroup, walk  # noqa: E402
from kbcommon import (AI_OUT_DIR, CHANGELOG_FILE, INVENTORY_FILE, RECALC_STATE, SOURCE_ACTIONS, SUPPORTED,  # noqa: E402
                      TEMP_DIR, FileLock, append_turn_entry, code_path, current_turn, file_hash, is_cloud_placeholder,
                      is_excluded, is_shared, is_skipped_name, load_sources, long_path, needs_recalc, now_str,
                      parse_front_matter, read_json, require_kb, stat_entry, turn_dir, turn_entries, utf8_io,
                      write_json_atomic)
from update import card_family, mark_stale, reindex, remove_notes, sync_card_paths  # noqa: E402

THRESHOLD = 10  # 一次動到超過這麼多份要先問客戶（推估，端到端實測後調整）
TEXT_EXTS = {".txt", ".md", ".csv"}
OFFICE_EXTS = {".docx", ".doc", ".xlsx", ".xls", ".xlsm"}
# 改名時看起來像副檔名的寫法（不在這裡的，例如「報價 v1.2」，當成檔名的一部分）
KNOWN_EXTS = SUPPORTED | OFFICE_EXTS | {".ppt", ".rtf", ".odt", ".ods", ".odp", ".jpg", ".jpeg", ".png", ".gif",
                                        ".bmp", ".tif", ".tiff", ".heic", ".zip", ".rar", ".7z", ".json", ".xml",
                                        ".html", ".htm", ".tsv", ".log", ".mp3", ".mp4", ".mov", ".wav"}
BAD_CHARS = '<>:"/\\|?*'
BOM = b"\xef\xbb\xbf"
MOVED_OUT = "原檔已移出"


class Refuse(Exception):
    """不能做：印出原因，結束碼 3。"""


class InUse(Exception):
    """檔案正在使用中：結束碼 5。"""


def ncase(p):
    return os.path.normcase(os.path.abspath(str(p)))


def inside(child, parent):
    c, p = ncase(child), ncase(parent).rstrip(os.sep)
    return c == p or c.startswith(p + os.sep)


def exists(p):
    return os.path.exists(long_path(p))


def is_dir(p):
    return os.path.isdir(long_path(p))


class Loc:
    """一個位置：實際路徑、所在分區（不在任何來源裡時是 None）、分區內的相對路徑。"""

    def __init__(self, ctx, path):
        self.path = Path(os.path.abspath(str(path)))
        self.section, self.rel = None, None
        for s in ctx.sources["分區"]:
            if inside(self.path, s["路徑"]):
                self.section = s
                rel = os.path.relpath(str(self.path), s["路徑"]).replace("\\", "/")
                self.rel = "" if rel == "." else rel
                break
        self.ctx = ctx

    @property
    def cp(self):
        """{代號}/相對路徑；不在來源裡時是完整路徑。"""
        if self.section is None:
            return str(self.path)
        return code_path(self.section["代號"], self.rel) if self.rel else "{" + self.section["代號"] + "}/"

    def in_kb(self):
        """會不會被整理進知識庫：在分區裡、不在排除清單裡（檔名規則由 add_new 逐份判斷）。"""
        return self.section is not None and not (self.rel and is_excluded(self.rel, self.ctx.sources["排除"], self.section["代號"]))

    def child(self, name):
        return Loc(self.ctx, self.path / name)


class Ctx:
    def __init__(self, kb, confirmed):
        self.kb = kb
        self.sources = load_sources(kb)
        self.confirmed = confirmed
        self.asks = []      # 要先問客戶的原因
        self.plan = []      # 要做的事（給客戶看的說明）
        self.count = 0      # 這次動到幾份檔案
        self.steps = []     # 檢查通過後才執行的動作
        self.refs = []      # 新增時起草參考的原檔（--參考）
        self.history = None  # 新增時卡片的來歷（--來歷，0.13.0）

    def ask(self, why):
        if why not in self.asks:
            self.asks.append(why)

    def locate(self, s, must_exist=False):
        if ".." in re.split(r"[\\/]", s):
            raise Refuse(f"路徑不能含「..」：{s}")
        if s.startswith("{"):
            code, sep, rel = s[1:].partition("}")
            if not sep:
                raise Refuse(f"原檔要寫成 {{代號}}/相對路徑：{s}")
            sec = next((x for x in self.sources["分區"] if x["代號"] == code), None)
            if not sec:
                raise Refuse(f"來源清單沒有分區代號 {code}")
            path = Path(sec["路徑"]) / rel.strip("/\\")
        else:
            path = Path(s)
            if not path.is_absolute():
                raise Refuse(f"請寫 {{代號}}/相對路徑 或完整路徑：{s}")
        loc = Loc(self, path)
        if must_exist and not exists(loc.path):
            raise Refuse(f"找不到：{s}")
        return loc

    def local_file(self, s, what):
        """暫存檔或外部檔案（完整路徑，或相對於目前資料夾、總資料夾）。"""
        if ".." in re.split(r"[\\/]", s):
            raise Refuse(f"路徑不能含「..」：{s}")
        p = Path(s)
        if not p.is_absolute():
            p = Path.cwd() / s if (Path.cwd() / s).exists() else self.kb / s
        p = Path(os.path.abspath(str(p)))
        if not exists(p) or is_dir(p):
            raise Refuse(f"找不到{what}：{s}")
        return p

    def check_target(self, loc, op):
        """目標位置的保護（spec 4.6〈程式的保護〉）與要先問的情況。"""
        if inside(loc.path, self.kb):
            raise Refuse("目標在總資料夾裡：總資料夾是 AI 的工作區，不能放來源的檔案。")
        out = self.sources.get("成品區")
        if out and inside(loc.path, out):
            raise Refuse("目標在成品區：成品區不是來源資料夾。給客戶的文件直接寫進成品區就好，不用經過這支程式。")
        if loc.section is None:
            if op in ("新增", "複製"):
                raise Refuse(f"目標不在任何來源資料夾裡（{loc.path}）。AI 起草的文件請寫進成品區。")
            self.ask(f"搬到來源資料夾以外（{loc.path}）：這些檔案會從知識庫拿掉，筆記也會刪除")
            return
        if loc.rel and is_excluded(loc.rel, self.sources["排除"], loc.section["代號"]):
            if op in ("新增", "複製"):
                self.ask(f"目標在排除清單裡（{loc.cp}）：放進去之後不會整理進知識庫")
            else:
                self.ask(f"目標在排除清單裡（{loc.cp}）：這些檔案會從知識庫拿掉，筆記也會刪除")
        self.check_shared(loc)

    def check_shared(self, loc):
        if loc.section is not None and is_shared(loc.section):
            self.ask(f"「{loc.section['名稱']}」是和別人共用的資料夾：改了其他人也會看到")


# ---- 共用的小工具 ----

def unique(p):
    """目的地已有同名檔案時，在檔名後加「 (2)」「 (3)」……，不覆蓋。"""
    p = Path(p)
    if not exists(p):
        return p
    stem, suf = (p.name, "") if is_dir(p) else (p.stem, p.suffix)
    i = 2
    while exists(p.parent / f"{stem} ({i}){suf}"):
        i += 1
    return p.parent / f"{stem} ({i}){suf}"


def make_parents(p):
    """建好 p 的上層資料夾，回傳這次新建的（由外到內），失敗時用 remove_made 收回。"""
    made, d = [], Path(p).parent
    while not exists(d):
        made.append(d)
        d = d.parent
    Path(long_path(Path(p).parent)).mkdir(parents=True, exist_ok=True)
    return list(reversed(made))


def remove_made(made):
    for d in reversed(made):
        try:
            os.rmdir(long_path(d))
        except OSError:
            break


def move_path(src, dst):
    """搬動檔案或資料夾，不留下改一半的結果。

    先用 os.rename（同一顆磁碟是一次完成）。檔案被 Word、Excel 開著時 rename 會被拒（PermissionError），
    直接往上丟、不改用複製：shutil.move 遇到失敗會先複製再刪原檔，刪不掉就留下一份沒登記的副本（0.10.1 修正）。
    只有跨磁碟才複製再刪；刪原檔失敗時把複製出來的收回。"""
    try:
        os.rename(long_path(src), long_path(dst))
        return
    except PermissionError:
        raise
    except OSError as e:
        if getattr(e, "winerror", None) != 17 and e.errno != errno.EXDEV:  # 17：不同的磁碟機
            raise
    copy = shutil.copytree if is_dir(src) else shutil.copy2
    copy(long_path(src), long_path(dst))
    try:
        if is_dir(src):
            shutil.rmtree(long_path(src))
        else:
            os.remove(long_path(src))
    except OSError:
        if is_dir(dst):
            shutil.rmtree(long_path(dst), ignore_errors=True)
        elif exists(dst):
            os.remove(long_path(dst))
        raise PermissionError(f"{Path(src).name} 正在使用中")


def count_files(p):
    if not is_dir(p):
        return 1
    return sum(len(fs) for _, _, fs in os.walk(long_path(p)))


def office_locked(p):
    """Word、Excel 開著檔案時，同一個資料夾會有 ~$ 開頭的暫存檔。"""
    p = Path(p)
    if p.suffix.lower() not in OFFICE_EXTS | {".pptx", ".ppt"}:
        return False
    n = p.name
    return any(exists(p.parent / c) for c in {"~$" + n, "~$" + n[1:], "~$" + n[2:]})


def check_not_open(p):
    if is_dir(p):
        return
    if office_locked(p):
        raise InUse(f"{Path(p).name} 正在使用中（Word 或 Excel 開著）")


def is_placeholder(p):
    try:
        return is_cloud_placeholder(os.stat(long_path(p)))
    except OSError:
        return False


def refresh(e, path, rehash=False):
    """清冊一筆跟著檔案目前的大小、修改時間更新；rehash 時重算指紋（雲端占位檔不算）。"""
    st = os.stat(long_path(path))
    e["大小"] = st.st_size
    e["修改時間"] = round(st.st_mtime, 1)
    if rehash and not is_cloud_placeholder(st):
        e["指紋"] = file_hash(path)


def add_new(ctx, files, loc):
    """還不在清冊裡的檔案記成待製卡（排除、暫存檔、不支援的格式照 inventory.scan 的規則）。回傳那一筆或 None。"""
    name = loc.path.name
    if not loc.in_kb() or is_skipped_name(name):
        return None
    e, st = stat_entry(loc.section["代號"], loc.rel, loc.path)
    if e["副檔名"] not in SUPPORTED:
        e["狀態"] = "不支援"
    elif is_cloud_placeholder(st):
        e["狀態"] = "雲端占位"
    else:
        e["指紋"] = file_hash(loc.path)
        e["狀態"] = "待處理"
    files[loc.cp] = e
    regroup(files, e.get("指紋"))
    return e


def files_under(files, cp, folder):
    """清冊裡這個原檔（或資料夾底下）還在的那幾筆。"""
    if folder:
        pre = cp.rstrip("/") + "/"
        return [c for c in files if c.startswith(pre) and files[c]["狀態"] not in GONE]
    return [cp] if cp in files and files[cp]["狀態"] not in GONE else []


def sub_loc(ctx, root_loc, root_cp, cp):
    """資料夾搬動時，底下某一份在新位置的 Loc。"""
    rest = cp[len(root_cp.rstrip("/")):].lstrip("/")
    return Loc(ctx, root_loc.path / rest) if rest else root_loc


class Result:
    def __init__(self):
        self.todo = []      # 要製卡的原檔
        self.cards = []     # 改了原檔位置的卡片
        self.removed = []   # 刪掉的卡片（搬出知識庫）
        self.done = []      # 改動紀錄與畫面上的說明


def relocate(ctx, files, res, src, dst, folder):
    """實際搬動之後，清冊跟著改。src、dst 是搬動前後的位置（退回時反過來呼叫）。"""
    touched = set()
    if dst.in_kb():
        if src.in_kb():
            for cp in files_under(files, src.cp, folder):
                new = sub_loc(ctx, dst, src.cp, cp)
                e = files.pop(cp)
                e["分區"] = new.section["代號"]
                refresh(e, new.path)
                files[new.cp] = e
                touched |= set(regroup(files, e.get("指紋"))) | {new.cp}
        # 原本不在知識庫裡的（從排除的資料夾搬進來、退回搬出去的檔案）
        targets = [(dst, dst.path)] if not folder else [(dst.child(rel), None) for rel, st, err in walk(dst.path) if st]
        for loc, _ in targets:
            e = files.get(loc.cp)
            if e and e.get("移到"):
                e.pop("移到")
                refresh(e, loc.path)
                if e.get("卡片") and (ctx.kb / e["卡片"]).exists():
                    e["狀態"] = "完成"
                else:
                    e.pop("卡片", None)
                    e["狀態"] = "待處理"
                touched |= set(regroup(files, e.get("指紋"))) | {loc.cp}
            elif loc.cp not in files or files[loc.cp]["狀態"] in GONE and not files[loc.cp].get("卡片"):
                e = add_new(ctx, files, loc)
                if e:
                    touched |= set(regroup(files, e.get("指紋"))) | {loc.cp}
    elif src.in_kb():
        # 搬到來源以外或排除清單裡：等於從知識庫拿掉（決策 #39，0.9.0）
        for cp in files_under(files, src.cp, folder):
            e = files[cp]
            new_path = sub_loc(ctx, dst, src.cp, cp).path
            others = [c for c in files if c != cp and e.get("指紋") and files[c].get("指紋") == e["指紋"]
                      and files[c]["狀態"] not in GONE and not files[c].get("卡片")]
            if e.get("卡片") and others:
                # 另一處還有一模一樣的檔案：卡片交給它（和 inventory.scan 的搬動判斷相同）
                heir = sorted(others, key=lambda c: (len(c), c))[0]
                files[heir]["卡片"] = e["卡片"]
                files[heir]["狀態"] = "已變動" if e["狀態"] == "已變動" else "完成"
                files[heir].pop("同", None)
                files.pop(cp)
                touched |= set(regroup(files, e.get("指紋"))) | {heir}
            elif e.get("卡片"):
                cards, _ = remove_notes(ctx.kb, e, MOVED_OUT)
                e["移到"] = str(new_path)
                res.removed += cards
                regroup(files, e.get("指紋"))
            else:
                files.pop(cp)
                touched |= set(regroup(files, e.get("指紋")))
    touched = {c for c in touched if c in files}
    res.cards += sync_card_paths(ctx.kb, {c: files[c] for c in touched})
    res.todo += [c for c in touched if files[c]["狀態"] in ("待處理", "已變動")]


# ---- 各個動作：plan_* 只檢查並排進 ctx.steps，真正執行在檢查全部通過之後 ----

def target_file(ctx, target, name):
    """新增、複製的目標：結尾是 / 或已經是資料夾時，檔名沿用原本的。"""
    loc = ctx.locate(target)
    if target.endswith(("/", "\\")) or is_dir(loc.path):
        loc = loc.child(name)
    if not loc.path.suffix:
        raise Refuse(f"目標要寫檔名與副檔名：{target}")
    return loc


def plan_add(ctx, op, src_arg, target):
    if op == "新增":
        src = ctx.local_file(src_arg, "暫存檔")
        if not inside(src, ctx.kb / TEMP_DIR):
            raise Refuse("新增的內容要先寫在總資料夾的 .system/暫存/，再用這支程式放進來源。")
    else:
        src = ctx.local_file(src_arg, "要複製的檔案")
        if inside(src, ctx.kb):
            raise Refuse("總資料夾裡的檔案不能複製進來源：AI 的筆記不能被當成原始資料。")
    loc = target_file(ctx, target, src.name)
    ctx.check_target(loc, op)
    ai_out = op == "新增" and loc.section is not None and loc.rel.split("/")[0] == AI_OUT_DIR
    if not ai_out:
        ctx.count += 1  # 存進「AI 產出」是我們自己的資料夾，不算改原資料夾的份數（spec 4.9）
    ctx.plan.append(f"{op} {loc.cp}" + ("" if op == "新增" else f"（從 {src}）"))

    def run(files, res, turn):
        dest = Loc(ctx, unique(loc.path))
        data = Path(long_path(src)).read_bytes()  # 外部檔案開著時在這裡就停（還沒建任何資料夾）
        make_parents(dest.path)
        if dest.path.suffix.lower() == ".csv" and not data.startswith(BOM) and _decodes(data, "utf-8"):
            data = BOM + data  # 新的 .csv 加 BOM，Excel 打開才不會變亂碼
        with open(long_path(dest.path), "wb") as f:
            f.write(data)
        if op == "複製":
            shutil.copystat(long_path(src), long_path(dest.path))
        else:
            os.remove(long_path(src))  # 暫存檔用完刪除
        digest = file_hash(dest.path)
        entry = {"路徑": dest.cp, "動作": "來源新增", "實際路徑": str(dest.path), "指紋": digest}
        if ai_out:
            entry["AI產出"] = True
        append_turn_entry(ctx.kb, turn, entry)
        if op == "新增":  # AI 起草的內容：登記成 AI 產出，製卡時才不會被當成客戶自己的資料（spec 4.8）
            from ai_output import register
            register(ctx.kb, dest.path, refs=ctx.refs, quiet=True, history=ctx.history)
        e = add_new(ctx, files, dest)
        if e and e["狀態"] == "待處理" and op == "新增" and needs_recalc(dest.path):
            e["狀態"] = RECALC_STATE  # 公式結果還沒算出來：不製卡，客戶用 Excel 打開存檔後才製卡（spec 4.9）
            res.done.append(f"{dest.cp} 的公式還沒重算（{RECALC_STATE}）：客戶用 Excel 打開、存檔後才會整理進筆記")
        if e and e["狀態"] == "待處理":
            res.todo.append(dest.cp)
        if e and e.get("指紋"):  # 和既有的檔案一模一樣時，主檔卡片的「其他位置」要補上
            group = regroup(files, e["指紋"])
            res.cards += sync_card_paths(ctx.kb, {c: files[c] for c in group})
        res.done.append(f"{op} {dest.cp}" + ("（檔名重複，改名為 " + dest.path.name + "）" if dest.path != loc.path else ""))
    ctx.steps.append(run)


def plan_move(ctx, src_arg, dest_path, how):
    src = ctx.locate(src_arg, must_exist=True)
    if src.section is None:
        raise Refuse(f"要{how}的檔案不在來源資料夾裡：{src_arg}。外面的檔案請用「複製」。")
    if not src.rel:
        raise Refuse("不能搬動或改名整個來源資料夾（改來源清單是服務人員的事）。")
    folder = is_dir(src.path)
    dst = Loc(ctx, dest_path)
    if folder and inside(dst.path, src.path):
        raise Refuse("不能把資料夾搬進它自己裡面。")
    if ncase(dst.path) == ncase(src.path) and dst.path.name == src.path.name:
        raise Refuse(f"已經在那裡了：{src.cp}")
    ctx.check_target(dst, "搬動")
    ctx.check_shared(src)
    n = count_files(src.path)
    ctx.count += n
    ctx.plan.append(f"{how} {src.cp} → {dst.cp}" + (f"（資料夾，{n} 份檔案）" if folder else ""))

    def run(files, res, turn):
        case_only = ncase(dst.path) == ncase(src.path)
        target = Loc(ctx, dst.path if case_only else unique(dst.path))
        check_not_open(src.path)
        made = make_parents(target.path)
        try:
            move_path(src.path, target.path)
        except PermissionError:
            remove_made(made)  # 沒搬成，剛建的空資料夾也收回
            raise InUse(f"{src.path.name} 正在使用中")
        append_turn_entry(ctx.kb, turn, {"路徑": target.cp, "動作": "來源搬動", "舊": str(src.path),
                                         "新": str(target.path), "舊位置": src.cp, "資料夾": folder, "份數": n})
        relocate(ctx, files, res, src, target, folder)
        res.done.append(f"{how} {src.cp} → {target.cp}")
    ctx.steps.append(run)


def plan_rename(ctx, src_arg, new_name):
    if any(c in BAD_CHARS for c in new_name) or new_name.strip(" .") != new_name or not new_name:
        raise Refuse(f"新名稱只寫名稱，不能有 {BAD_CHARS} 這些字元、不能以空白或句點結尾；要換資料夾請用「搬動」：{new_name}")
    src = ctx.locate(src_arg, must_exist=True)
    if not is_dir(src.path):
        old_ext = src.path.suffix
        new_ext = Path(new_name).suffix
        if new_ext.lower() == old_ext.lower():
            pass
        elif new_ext.lower() in KNOWN_EXTS:
            raise Refuse(f"改名不能改副檔名（{old_ext} → {new_ext}）：改了格式檔案會打不開，筆記也會對不上。")
        else:
            new_name += old_ext  # 沒寫副檔名，補上原本的
    plan_move(ctx, src_arg, src.path.parent / new_name, "改名")


def detect_encoding(raw):
    """回傳 (編碼, 有沒有 BOM)；看不出來時回傳 (None, False)。"""
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return "utf-16", False
    if raw.startswith(BOM):
        return "utf-8", True
    for enc in ("utf-8", "cp950", "big5hkscs"):
        if _decodes(raw, enc):
            return enc, False
    return None, False


def _decodes(raw, enc):
    try:
        raw.decode(enc)
        return True
    except UnicodeDecodeError:
        return False


def plan_overwrite(ctx, src_arg, target):
    src = ctx.local_file(src_arg, "暫存檔")
    if not inside(src, ctx.kb / TEMP_DIR):
        raise Refuse("改過的內容要先寫在總資料夾的 .system/暫存/，再用這支程式覆蓋。")
    loc = ctx.locate(target, must_exist=True)
    if loc.section is None:
        raise Refuse(f"要改的檔案不在來源資料夾裡：{target}")
    if is_dir(loc.path):
        raise Refuse(f"要改的是資料夾，不是檔案：{target}")
    ext = loc.path.suffix.lower()
    if ext in OFFICE_EXTS:
        raise Refuse("Word、Excel 不覆蓋原檔：照 rules/office.md 在暫存的副本上改，再用「新增」另存成「原檔名（AI 修改）」，原檔不動。")
    if ext not in TEXT_EXTS:
        raise Refuse(f"{ext or '這種'} 檔不能覆蓋：只能改純文字檔（.txt、.md、.csv）。PDF、PowerPoint、圖片請改成產出新檔。")
    if is_placeholder(loc.path):
        raise Refuse("這份檔案只在雲端、還沒下載到電腦。請客戶在檔案上按右鍵，選「一律保留在此裝置上」，下載好再說一次。")
    raw = Path(long_path(loc.path)).read_bytes()
    enc, bom = detect_encoding(raw)
    if not enc:
        raise Refuse("看不出原檔的編碼，為了避免變成亂碼，不覆蓋。")
    old_text = raw.decode("utf-16" if enc == "utf-16" else enc)
    if bom:
        old_text = old_text[1:] if old_text.startswith("﻿") else old_text
    new_text = Path(long_path(src)).read_bytes().decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    if "\r\n" in old_text:
        new_text = new_text.replace("\n", "\r\n")
    try:
        data = new_text.encode(enc)
    except UnicodeEncodeError:
        bad = sorted({ch for ch in new_text if not _encodable(ch, enc)})
        raise Refuse(f"原檔是 {'Big5' if enc != 'utf-8' else enc} 編碼，新內容有寫不進去的字：{''.join(bad[:20])}。請換成其他寫法。")
    if bom:
        data = BOM + data
    ctx.check_target(loc, "覆蓋")
    ctx.count += 1
    ctx.plan.append(f"改 {loc.cp} 的內容")

    def run(files, res, turn):
        if data == Path(long_path(loc.path)).read_bytes():
            os.remove(long_path(src))
            res.done.append(f"{loc.cp} 內容沒有變，沒有改")
            return
        try:
            with open(long_path(loc.path), "r+b"):
                pass
        except PermissionError:
            raise InUse(f"{loc.path.name} 正在使用中")
        # 覆蓋前備份原檔；同一回合改第二次時沿用第一次的備份（保留最初的版本）
        vdir = turn_dir(ctx.kb, turn)
        rel_backup = f"來源/{loc.section['代號']}/{loc.rel}"
        earlier = [e for e in turn_entries(ctx.kb, turn) if e["動作"] == "來源覆蓋" and e["路徑"] == loc.cp]
        if not earlier:
            (vdir / rel_backup).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(long_path(loc.path), long_path(vdir / rel_backup))
        fd, tmp = tempfile.mkstemp(dir=long_path(loc.path.parent), suffix=".tmp")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        try:
            os.replace(tmp, long_path(loc.path))
        except PermissionError:
            os.remove(tmp)
            raise InUse(f"{loc.path.name} 正在使用中")
        os.remove(long_path(src))
        digest = file_hash(loc.path)
        append_turn_entry(ctx.kb, turn, {"路徑": loc.cp, "動作": "來源覆蓋", "實際路徑": str(loc.path),
                                         "指紋": digest, "備份": rel_backup})
        e = files.get(loc.cp)
        if e is None or e["狀態"] in GONE:
            e = add_new(ctx, files, loc)
            if e and e["狀態"] == "待處理":
                res.todo.append(loc.cp)
        else:
            old_digest = e.get("指紋")
            refresh(e, loc.path, rehash=True)
            e.pop("原因", None)
            e.pop("同", None)
            e["狀態"] = "已變動" if e.get("卡片") else "待處理"
            touched = set(regroup(files, old_digest)) | set(regroup(files, e["指紋"])) | {loc.cp}
            res.cards += sync_card_paths(ctx.kb, {c: files[c] for c in touched if c in files})
            res.todo += [c for c in touched if c in files and files[c]["狀態"] in ("待處理", "已變動")]
            if e.get("卡片"):
                mark_stale(ctx.kb, card_family(ctx.kb, e["卡片"]))
        res.done.append(f"改了 {loc.cp} 的內容（編碼 {'Big5' if enc in ('cp950', 'big5hkscs') else enc}"
                        + ("、保留 BOM" if bom else "") + "）")
    ctx.steps.append(run)


def _encodable(ch, enc):
    try:
        ch.encode(enc)
        return True
    except UnicodeEncodeError:
        return False


def expect_delete(ctx, args):
    """客戶說要自己刪：清冊記「預期刪除」，之後不見了 update.py 套用直接拿掉筆記（spec 4.6）。"""
    inv_path = ctx.kb / INVENTORY_FILE
    lines = []
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        files = inv["檔案"]
        for a in args:
            loc = ctx.locate(a)
            if loc.section is None:
                raise Refuse(f"不在來源資料夾裡：{a}")
            link = "file:///" + str(loc.path).replace("\\", "/")
            folder = is_dir(loc.path)
            # 資料夾：展開成底下有卡片的檔案（沒有卡片的不見了也不會問，不用記）
            cps = [c for c in files_under(files, loc.cp, folder) if files[c].get("卡片")] \
                if folder else ([loc.cp] if loc.cp in files else [])
            if not cps:
                lines.append(f"- {loc.cp}：沒有筆記，客戶自己刪掉就好（{link}）")
                continue
            for c in cps:
                files[c]["預期刪除"] = now_str()
            what = f"資料夾裡 {len(cps)} 份有筆記的檔案" if folder else "已記下"
            lines.append(f"- {loc.cp}：{what}，客戶刪掉後下次更新會直接拿掉筆記、不再問（{link}）")
        write_json_atomic(inv_path, inv)
    log_change(ctx.kb, "記下預期刪除（請客戶自己刪）：" + "、".join(args))
    print("已記下預期刪除。請客戶自己刪除（把下面的位置給客戶，可以點開）：")
    print("\n".join(lines))


def busy_name(e):
    """PermissionError 是哪一份檔案（給客戶看檔名就好）。"""
    name = getattr(e, "filename", None) or str(e)
    return Path(str(name)).name or "檔案"


def log_change(kb, text):
    with open(long_path(kb / CHANGELOG_FILE), "a", encoding="utf-8") as f:
        f.write(f"\n[{now_str()}] 改原資料夾｜{text}\n")


# ---- 退回（versions.py 呼叫）----

def revert(kb, entries, vdir):
    """退回一個回合裡的來源改動。entries 是那一回合的 清單.jsonl（全部，非來源的動作會略過）。
    頁面要先由 versions.py 還原，這裡才把清冊接回去。回傳給客戶看的說明。"""
    ctx = Ctx(kb, True)
    msgs, seen = [], set()
    res = Result()
    inv_path = kb / INVENTORY_FILE
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        files = inv["檔案"]
        for e in reversed([x for x in entries if x["動作"] in SOURCE_ACTIONS]):
            a = e["動作"]
            try:
                if a == "來源新增":
                    p = Path(e["實際路徑"])
                    if not exists(p):
                        msgs.append(f"  已經不在：{e['路徑']}")
                    elif file_hash(p) != e["指紋"]:
                        msgs.append(f"  保留（客戶之後又改過）：{e['路徑']}")
                    else:
                        os.remove(long_path(p))
                        old = files.pop(Loc(ctx, p).cp, None)
                        regroup(files, (old or {}).get("指紋"))
                        msgs.append(f"  移除來源的檔案：{e['路徑']}")
                elif a == "來源搬動":
                    old, new = Path(e["舊"]), Path(e["新"])
                    if not exists(new):
                        msgs.append(f"  沒有搬回（找不到 {e['路徑']}）")
                    elif exists(old) and ncase(old) != ncase(new):
                        msgs.append(f"  沒有搬回（原位置已經有同名的檔案）：{e['舊位置']}")
                    else:
                        old.parent.mkdir(parents=True, exist_ok=True)
                        move_path(new, old)
                        relocate(ctx, files, res, Loc(ctx, new), Loc(ctx, old), e.get("資料夾", False))
                        msgs.append(f"  搬回：{e['路徑']} → {e['舊位置']}")
                elif a == "來源覆蓋":
                    if e["路徑"] in seen:
                        continue  # 同一回合改了兩次：最後一次的紀錄已經還原到最初的版本
                    seen.add(e["路徑"])
                    p = Path(e["實際路徑"])
                    if not exists(p):
                        msgs.append(f"  沒有還原（檔案不見了）：{e['路徑']}")
                    elif file_hash(p) != e["指紋"]:
                        msgs.append(f"  沒有還原（客戶之後又改過）：{e['路徑']}")
                    else:
                        shutil.copy2(long_path(vdir / e["備份"]), long_path(p))
                        cp = Loc(ctx, p).cp
                        ent = files.get(cp)
                        if ent:
                            old_digest = ent.get("指紋")
                            refresh(ent, p, rehash=True)
                            card = ent.get("卡片")
                            if card and (kb / card).exists():
                                fm = parse_front_matter((kb / card).read_text(encoding="utf-8")).get("指紋")
                                ent["狀態"] = "完成" if fm == ent["指紋"] else "已變動"
                            else:
                                ent.pop("卡片", None)
                                ent["狀態"] = "待處理"
                            regroup(files, old_digest)
                            regroup(files, ent["指紋"])
                        msgs.append(f"  還原來源的檔案內容：{e['路徑']}")
            except PermissionError:
                msgs.append(f"  沒有退回（檔案正在使用中，請關掉後再退回一次）：{e['路徑']}")
        write_json_atomic(inv_path, inv)
    if res.removed:
        reindex(kb)
    return msgs


# ---- 主程式 ----

def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["新增", "複製", "改名", "搬動", "覆蓋", "預期刪除"])
    ap.add_argument("args", nargs="+")
    ap.add_argument("--客戶已同意", dest="confirmed", action="store_true")
    ap.add_argument("--只檢查", dest="check_only", action="store_true", help="只檢查要不要先問，什麼都不做")
    ap.add_argument("--參考", dest="refs", action="extend", nargs="+", default=[],
                    help="新增：起草時參考的原檔（{代號}/路徑，可以給多個），登記 AI 產出用")
    ap.add_argument("--來歷", dest="history", help="新增：卡片的來歷，例如「AI 修改自〈合約.docx〉」")
    ap.add_argument("--合計", dest="total", type=int, help="客戶這一個要求的總份數（要分幾次呼叫時，先用來試算）")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    ctx = Ctx(kb, a.confirmed)
    ctx.refs = a.refs
    ctx.history = a.history
    if not (kb / INVENTORY_FILE).exists():
        print("拒絕：還沒有清冊（建置還沒完成），先不要改原資料夾。")
        sys.exit(3)
    try:
        if a.action == "預期刪除":
            expect_delete(ctx, a.args)
            return
        need = {"新增": 2, "複製": 2, "改名": 2, "覆蓋": 2}
        if a.action in need and len(a.args) != need[a.action]:
            raise Refuse(f"「{a.action}」要兩個參數，見程式開頭的用法。")
        if a.action in ("新增", "複製"):
            plan_add(ctx, a.action, *a.args)
        elif a.action == "改名":
            plan_rename(ctx, *a.args)
        elif a.action == "覆蓋":
            plan_overwrite(ctx, *a.args)
        else:
            if len(a.args) < 2:
                raise Refuse("「搬動」要寫要搬的檔案與目標資料夾。")
            dest = ctx.locate(a.args[-1])
            if exists(dest.path) and not is_dir(dest.path):
                raise Refuse(f"搬動的目標要是資料夾：{a.args[-1]}")
            for s in a.args[:-1]:
                src = ctx.locate(s, must_exist=True)
                plan_move(ctx, s, dest.path / src.path.name, "搬動")
    except Refuse as e:
        print(f"拒絕（什麼都沒改）：{e}")
        sys.exit(3)
    except PermissionError as e:
        print(f"沒做（什麼都沒改）：{busy_name(e)} 正在使用中（Word、Excel 或其他程式開著）。請客戶把檔案關掉後再說一次；不要自己重試。")
        sys.exit(5)

    turn = current_turn(kb)
    before = sum(x.get("份數", 1) for x in turn_entries(kb, turn) if x["動作"] in SOURCE_ACTIONS and not x.get("AI產出"))
    total = max(ctx.count, a.total or 0)  # --合計：客戶這一個要求的總份數（要分幾次呼叫時）
    if before + total > THRESHOLD:
        ctx.asks.insert(0, f"一次動到 {before + total} 份檔案（超過 {THRESHOLD} 份"
                        + (f"，含這個問題前面已經改的 {before} 份" if before else "") + "）")
    if a.check_only:
        if ctx.asks and not ctx.confirmed:
            print("只檢查（什麼都沒做）：要先問客戶")
            print("\n".join(f"- {x}" for x in ctx.asks))
            sys.exit(4)
        print("只檢查（什麼都沒做）：可以直接做，不用先問。要做的事：")
        print("\n".join(f"- {x}" for x in ctx.plan))
        return
    if ctx.asks and not ctx.confirmed:
        print("要先問客戶（什麼都還沒做）：")
        print("\n".join(f"- {x}" for x in ctx.asks))
        print("要做的事：")
        print("\n".join(f"- {x}" for x in ctx.plan))
        print("把上面的事列給客戶、記進〈做到一半的事〉（等客戶回覆）；客戶答應後，同一個指令加 --客戶已同意 再執行一次。")
        sys.exit(4)

    res = Result()
    code = 0
    inv_path = kb / INVENTORY_FILE
    with FileLock(inv_path):
        inv = read_json(inv_path, {}) or {"檔案": {}}
        try:
            for step in ctx.steps:
                step(inv["檔案"], res, turn)
        except InUse as e:
            code = 5
            busy = str(e)
        except PermissionError as e:
            code = 5
            busy = f"{busy_name(e)} 正在使用中"
        write_json_atomic(inv_path, inv)
    if res.removed:
        reindex(kb)
    if res.done:
        log_change(kb, "；".join(res.done))
        print("已改原資料夾（可以說「退回上一版」還原）：")
        print("\n".join(f"- {x}" for x in res.done))
    todo = sorted(c for c in set(res.todo) if inv["檔案"].get(c, {}).get("狀態") in ("待處理", "已變動"))
    if todo:
        print(f"要製卡 {len(todo)} 份（清冊已標待製卡）：" + "、".join(todo))
        print("只取這幾份派 card-maker：batch.py 下一批 " + " ".join(f'--原檔 "{c}"' for c in todo))
    if res.cards:
        print(f"卡片的原檔位置已改寫 {len(set(res.cards))} 張")
    if res.removed:
        print(f"搬出知識庫，筆記已拿掉 {len(res.removed)} 張（綜合頁出處標「{MOVED_OUT}」，索引已重建）")
    if code == 5:
        print(f"沒做完：{busy}。請客戶把檔案關掉後再說一次；不要自己重試。")
    sys.exit(code)


if __name__ == "__main__":
    main()
