"""索引重建：讀分區內所有卡片的頁首，重新產生 wiki/<名稱>/索引.md。

卡片超過 SPLIT 張時，依文件日期的年份拆成 索引/<年份>.md，索引.md 只列年份。
索引是由卡片推導出來的，壞掉或對不上時重跑即可。

用法：python reindex.py [分區代號 ...] [--知識庫 路徑]   不指定分區就重建全部
"""
import argparse
import os
import re
import sys
from collections import defaultdict

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import WIKI, load_sources, parse_front_matter, require_kb, utf8_io, write_text_atomic  # noqa: E402

SPLIT = 400


def cell(v):
    if isinstance(v, list):
        v = "、".join(v)
    return str(v or "").replace("|", "／").replace("\n", " ").strip()


def row(link, m):
    status = m.get("讀取狀態", "")
    note = "" if status in ("", "完整") else f"（{status}）"
    if m.get("主卡"):
        note += "（子卡）"
    if str(m.get("出處類別", "")) == "AI 產出":
        note = "〔AI 起草〕" + note  # 回答時不能當成客戶自己的資料（spec 4.8）
    elif m.get("來歷"):
        note += "（最初由 AI 起草）"
    return (f"| [{cell(m.get('標題') or m.get('_name'))}](<{link}>) | {cell(m.get('摘要'))}{note} "
            f"| {cell(m.get('文件日期'))} | {cell(m.get('文件類型'))} |")


HEADER = "| 卡片 | 一句話說明 | 文件日期 | 文件類型 |\n|---|---|---|---|\n"


def build(kb, s):
    d = kb / WIKI / s["名稱"]
    cards = []
    for p in sorted((d / "卡片").glob("*.md")):
        m = parse_front_matter(p.read_text(encoding="utf-8"))
        m["_name"] = p.stem
        cards.append((p.name, m))
    cards.sort(key=lambda c: str(c[1].get("文件日期", "")), reverse=True)

    title = f"# {s['名稱']}：索引\n\n共 {len(cards)} 張卡片。由索引程式產生，請勿手動修改。\n\n"
    idx_dir = d / "索引"
    if len(cards) <= SPLIT:
        body = HEADER + "\n".join(row(f"卡片/{n}", m) for n, m in cards) + "\n"
        write_text_atomic(d / "索引.md", title + body)
        if idx_dir.exists():
            for old in idx_dir.glob("*.md"):
                old.unlink()
        return len(cards), 1

    by_year = defaultdict(list)
    for n, m in cards:
        y = re.match(r"(\d{4})", str(m.get("文件日期", "")))
        by_year[y.group(1) if y else "未標日期"].append((n, m))
    idx_dir.mkdir(exist_ok=True)
    for old in idx_dir.glob("*.md"):
        if old.stem not in by_year:
            old.unlink()
    lines = []
    for y in sorted(by_year, reverse=True):
        items = by_year[y]
        write_text_atomic(idx_dir / f"{y}.md",
                          f"# {s['名稱']}：索引（{y}）\n\n共 {len(items)} 張。\n\n" + HEADER +
                          "\n".join(row(f"../卡片/{n}", m) for n, m in items) + "\n")
        lines.append(f"- [{y}](<索引/{y}.md>)：{len(items)} 張")
    write_text_atomic(d / "索引.md", title + "依文件日期的年份分成多份：\n\n" + "\n".join(lines) + "\n")
    return len(cards), len(by_year)


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("codes", nargs="*")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    for s in load_sources(kb)["分區"]:
        if a.codes and s["代號"] not in a.codes:
            continue
        n, parts = build(kb, s)
        print(f"{s['名稱']}：{n} 張卡片" + (f"，拆成 {parts} 份索引" if parts > 1 else ""))


if __name__ == "__main__":
    main()
