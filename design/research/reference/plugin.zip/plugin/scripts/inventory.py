"""清冊：走訪來源資料夾，產生（或更新）.system/檔案清冊.json，並印出統計。

只看結構、檔名、大小、時間與指紋，不讀檔案內容，也不顯示內容。
重複執行時，大小與修改時間沒變的檔案沿用上次的指紋與處理狀態；
修改時間變了但指紋相同（假變動）的檔案維持完成，不重做卡片；
做過卡片的檔案搬動或改名（指紋相同、位置不同）時，卡片跟著移到新位置。

用法：python inventory.py [--知識庫 路徑] [--樹 層數]
"""
import argparse
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import (INVENTORY_FILE, RECALC_STATE, SUPPORTED, FileLock, code_path, file_hash,  # noqa: E402
                      is_cloud_placeholder, is_excluded, is_skipped_name, load_sources,
                      long_path, now_str, read_json, require_kb, utf8_io, write_json_atomic)

# 粗估用：每份檔案製卡約 5,500 輸入、600 輸出 token（實測結果，合成樣本）
EST_IN, EST_OUT = 5500, 600

# 原檔不在資料夾裡、但保留紀錄的狀態
#   原檔已不存在：做過卡片、原檔不見了，等客戶確認是不是刪掉的
#   保留：客戶說不是他刪的（或退回了刪除），卡片不動、不再詢問
#   已刪除：客戶確認刪除，卡片已刪；留著紀錄供退回
#   已排除：排除規則涵蓋了做過卡片的檔案，由服務人員處理
#   預期刪除：客戶說要自己刪（source_edit.py 預期刪除），現在真的不見了；update.py 套用時直接刪卡片、不問
GONE = ("原檔已不存在", "保留", "已刪除", "已排除", "預期刪除")
# 沿用上次狀態的情況（大小與修改時間都沒變）。公式待重算（0.13.0）：AI 改的 Excel 還沒重算，
# 客戶用 Excel 打開存檔後修改時間變了，就當成新檔照常製卡
KEEP_IF_SAME = ("完成", "失敗", "待處理", "已變動", "處理中", RECALC_STATE)


def walk(root):
    """以長路徑走訪，回傳 (相對路徑, stat)。跳過隱藏與系統資料夾。"""
    stack = [""]
    while stack:
        rel_dir = stack.pop()
        try:
            entries = list(os.scandir(long_path(Path(root) / rel_dir)))
        except OSError as e:
            yield rel_dir, None, f"無法開啟資料夾：{e.strerror}"
            continue
        for e in entries:
            rel = f"{rel_dir}/{e.name}" if rel_dir else e.name
            try:
                if e.is_dir(follow_symlinks=False):
                    attrs = getattr(e.stat(follow_symlinks=False), "st_file_attributes", 0)
                    if e.name.startswith(".") or attrs & 0x6:  # 隱藏或系統
                        continue
                    stack.append(rel)
                elif e.is_file(follow_symlinks=False):
                    yield rel, e.stat(follow_symlinks=False), None
            except OSError as err:
                yield rel, None, f"無法讀取：{err.strerror}"


def scan(sources, old, quick=False, hash_limit=None, tree=0):
    """走訪來源資料夾，依上次的清冊 old 算出新的清冊內容。不寫入任何檔案。

    quick：只為判斷變動需要的檔案算指紋（做過卡片且時間或大小變了的、大小和某份不見的檔案相同的），
           新檔案不算指紋。給開對話時的快速比對用。
    hash_limit：最多讀多少位元組來算指紋；超過的檔案不算指紋（做過卡片的就當成已變動）。
    回傳 dict：檔案、錯誤、略過、格式、不支援、資料夾、不見的分區、搬動 [(舊, 新)]。
    """
    budget = [hash_limit]
    r = {"檔案": {}, "錯誤": [], "略過": defaultdict(Counter), "格式": defaultdict(Counter),
         "不支援": Counter(), "資料夾": defaultdict(Counter), "不見的分區": [], "搬動": []}
    files = r["檔案"]

    found = []
    for s in sources["分區"]:
        code = s["代號"]
        if not Path(long_path(s["路徑"])).is_dir():
            r["錯誤"].append(f"整個來源資料夾不見了：{s['名稱']} ← {s['路徑']}")
            r["不見的分區"].append(s)
            continue
        for rel, st, err in walk(s["路徑"]):
            name = rel.rsplit("/", 1)[-1]
            if err:
                r["錯誤"].append(f"{code_path(code, rel)}：{err}")
                continue
            if is_skipped_name(name):
                r["略過"][code]["跳過（暫存或系統檔）"] += 1
                continue
            if is_excluded(rel, sources["排除"], code):
                r["略過"][code]["排除"] += 1
                continue
            found.append((s, rel, st))

    missing_codes = {s["代號"] for s in r["不見的分區"]}
    present = {code_path(s["代號"], rel) for s, rel, _ in found}
    # 做過卡片、這次找不到的檔案大小：新檔案大小相同時才值得算指紋判斷是不是搬動
    missing_sizes = {e.get("大小") for cp, e in old.items()
                     if cp not in present and e.get("卡片") and e.get("狀態") != "已刪除"
                     and e.get("分區") not in missing_codes}

    def hash_of(path, size):
        if budget[0] is not None:
            if budget[0] < size:
                return None
            budget[0] -= size
        return file_hash(path)

    for s, rel, st in found:
        code = s["代號"]
        name = rel.rsplit("/", 1)[-1]
        ext = Path(name).suffix.lower()
        cp = code_path(code, rel)
        if tree:
            top = "/".join(rel.split("/")[:-1][:tree]) or "（最上層）"
            r["資料夾"][code][top] += 1
        prev = old.get(cp, {})
        card = prev.get("卡片") if prev.get("狀態") != "已刪除" else None
        entry = {"分區": code, "副檔名": ext, "大小": st.st_size, "修改時間": round(st.st_mtime, 1)}
        same = prev.get("大小") == st.st_size and prev.get("修改時間") == entry["修改時間"]

        if ext not in SUPPORTED:
            entry["狀態"] = "不支援"
            r["不支援"][ext or "（無副檔名）"] += 1
        elif is_cloud_placeholder(st):
            # 不算指紋：讀取占位檔會觸發下載。做過卡片的（例如客戶按了「釋放空間」）沿用原本的紀錄
            if card:
                for k in ("狀態", "卡片", "指紋", "其他位置"):
                    if k in prev:
                        entry[k] = prev[k]
                if entry["狀態"] in GONE:
                    entry["狀態"] = "完成"
            else:
                entry["狀態"] = "雲端占位"
        else:
            if same and prev.get("指紋"):
                entry["指紋"] = prev["指紋"]
            elif not (quick and not card and st.st_size not in missing_sizes):
                try:
                    digest = hash_of(Path(s["路徑"]) / rel, st.st_size)
                    if digest:
                        entry["指紋"] = digest
                except OSError as e:
                    entry["狀態"] = "失敗"
                    entry["原因"] = f"無法讀取：{e.strerror}"
            if "狀態" not in entry:
                if same and prev.get("狀態") in KEEP_IF_SAME:
                    for k in ("狀態", "卡片", "原因", "處理前狀態"):
                        if k in prev:
                            entry[k] = prev[k]
                elif card:
                    entry["卡片"] = card
                    unchanged = entry.get("指紋") and entry["指紋"] == prev.get("指紋") and prev.get("狀態") != "已變動"
                    entry["狀態"] = "完成" if unchanged else "已變動"
                else:
                    entry["狀態"] = "待處理"
            r["格式"][code][ext] += 1
        if prev.get("預期刪除"):
            entry["預期刪除"] = prev["預期刪除"]  # 客戶還沒刪，記號留著
        files[cp] = entry

    # 這次找不到的舊紀錄：搬動、不見、排除
    no_card = defaultdict(list)
    for cp, e in files.items():
        if e.get("指紋") and not e.get("卡片") and e["狀態"] == "待處理":
            no_card[e["指紋"]].append(cp)
    for cp, prev in old.items():
        if cp in files:
            continue
        if prev.get("分區") in missing_codes or prev.get("狀態") == "已刪除":
            files[cp] = prev  # 整區不見時原封不動；已刪除的留著供退回
            continue
        if not prev.get("卡片"):
            continue  # 沒做過卡片（重複、不支援、失敗……）就不用記
        cands = no_card.get(prev.get("指紋"))
        if cands:
            cands.sort(key=lambda c: (len(c), c))
            new = cands.pop(0)
            files[new]["卡片"] = prev["卡片"]
            files[new]["狀態"] = "已變動" if prev.get("狀態") == "已變動" else "完成"
            r["搬動"].append((cp, new))
            continue
        if prev.get("預期刪除"):
            files[cp] = {**prev, "狀態": "預期刪除"}
            continue
        rel = cp.split("}/", 1)[1]
        if is_excluded(rel, sources["排除"], prev.get("分區")):
            files[cp] = {**prev, "狀態": "已排除"}
        else:
            files[cp] = {**prev, "狀態": "保留" if prev.get("狀態") == "保留" else "原檔已不存在"}

    # 重複檔：同指紋只製一張卡，其餘記為重複
    by_hash = defaultdict(list)
    for cp, e in files.items():
        e.pop("其他位置", None)
        if e.get("指紋") and e["狀態"] not in GONE:
            by_hash[e["指紋"]].append(cp)
    for cps in by_hash.values():
        mark_duplicates(files, cps)
    return r


def mark_duplicates(files, cps):
    """同一個指紋的一組檔案：有卡片的（其次路徑最短的）當主檔，其餘記為重複。scan 與 source_edit.py 共用。"""
    if len(cps) < 2:
        return
    cps.sort(key=lambda c: (not files[c].get("卡片"), len(c), c))
    primary = cps[0]
    files[primary]["其他位置"] = cps[1:]
    for c in cps[1:]:
        if files[c].get("卡片"):
            continue  # 兩份原本不同、改成一樣的檔案，各自保留卡片
        files[c]["狀態"] = "重複"
        files[c]["同"] = primary


def regroup(files, digest):
    """只重算一個指紋的重複關係，結果和整份 scan 相同。回傳這一組的原檔（可能是空的）。"""
    if not digest:
        return []
    cps = [cp for cp, e in files.items() if e.get("指紋") == digest and e["狀態"] not in GONE]
    for cp in cps:
        e = files[cp]
        e.pop("其他位置", None)
        if e["狀態"] == "重複":  # scan 每次重新判斷重複，先還原成沒做過卡片的狀態
            e["狀態"] = "待處理"
            e.pop("同", None)
    mark_duplicates(files, cps)
    return cps


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("--知識庫", dest="kb")
    ap.add_argument("--樹", dest="tree", type=int, default=0, help="印出資料夾結構與檔案數，指定層數")
    a = ap.parse_args()

    kb = require_kb(a.kb)
    sources = load_sources(kb)
    inv_path = kb / INVENTORY_FILE

    with FileLock(inv_path):
        old = (read_json(inv_path, {}) or {}).get("檔案", {})
        r = scan(sources, old, tree=a.tree)
        write_json_atomic(inv_path, {"更新時間": now_str(), "檔案": r["檔案"]})
    print_stats(inv_path, sources, r, a.tree)


def print_stats(inv_path, sources, r, tree=0):
    """印出統計（只有數字與結構）。"""
    files = r["檔案"]
    status = Counter(e["狀態"] for e in files.values())
    print(f"清冊已更新：{inv_path}")
    print(f"總計 {len(files)} 份；" + "、".join(f"{k} {v}" for k, v in status.most_common()))
    for s in sources["分區"]:
        code = s["代號"]
        sec = [e for e in files.values() if e["分區"] == code]
        size_mb = sum(e.get("大小", 0) for e in sec) / 1048576
        st = Counter(e["狀態"] for e in sec)
        print(f"\n【{s['名稱']}】{{{code}}} {len(sec)} 份，{size_mb:.1f} MB")
        print("  格式：" + "、".join(f"{k} {v}" for k, v in r["格式"][code].most_common()))
        print("  狀態：" + "、".join(f"{k} {v}" for k, v in st.most_common()))
        if r["略過"][code]:
            print("  略過：" + "、".join(f"{k} {v}" for k, v in r["略過"][code].items()))
        if tree:
            print("  資料夾：")
            for folder, n in sorted(r["資料夾"][code].items()):
                print(f"    {folder}：{n}")
    if r["不支援"]:
        print("\n不支援的格式：" + "、".join(f"{k} {v}" for k, v in r["不支援"].most_common(15)))
    pending = status["待處理"] + status["已變動"]
    print(f"\n待製卡 {pending} 份。粗估 token：輸入約 {pending * EST_IN / 1e6:.1f} 百萬、"
          f"輸出約 {pending * EST_OUT / 1e6:.2f} 百萬（以每份 5,500／600 估，實際依檔案大小差異很大）")
    if r["搬動"]:
        print(f"\n搬動或改名 {len(r['搬動'])} 份（卡片已跟著移到新位置）")
    if r["錯誤"]:
        print(f"\n問題 {len(r['錯誤'])} 項：")
        for e in r["錯誤"][:30]:
            print("  " + e)


if __name__ == "__main__":
    main()
