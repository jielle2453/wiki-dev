"""製卡排程：從清冊取出下一批待製卡的檔案，並記錄每份的結果。可從斷點續做。

用法：
  python batch.py 下一批 [--數量 10] [--分區 代號] [--原檔 {代號}/路徑 ...]
                                                      取出一批並標為「處理中」，印出 JSON（--原檔：只取這幾份）
  python batch.py 抽樣 [--每區 12] [--分區 代號]      試讀用：每區挑不同格式、不同資料夾的檔案
  python batch.py 完成 <{代號}/相對路徑> <卡片相對路徑>
  python batch.py 失敗 <{代號}/相對路徑> <原因>        同時記入 admin/待處理.md〈讀不到的檔案〉
  python batch.py 重設                                把殘留的「處理中」改回「待處理」
  python batch.py 進度

「公式待重算」（AI 改過、還沒重算的 Excel，spec 4.9）不取：客戶用 Excel 打開存檔後變回待處理才製卡。
"""
import argparse
import json
import os
import random
import sys
from collections import Counter, defaultdict

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import (INVENTORY_FILE, PENDING_UNREADABLE, RECALC_STATE, FileLock, append_pending, card_name, load_sources, now_str, read_json,  # noqa: E402
                      require_kb, resolve_code_path, utf8_io, write_json_atomic)

TODO = ("待處理", "已變動")


def load(kb):
    return read_json(kb / INVENTORY_FILE, {}) or {"檔案": {}}


def item(kb, sources, cp, e):
    name = next(s["名稱"] for s in sources["分區"] if s["代號"] == e["分區"])
    rel = cp.split("}/", 1)[1]
    card = e.get("卡片") or f"wiki/{name}/卡片/{card_name(rel, e['指紋'])}"
    return {
        "原檔": cp,
        "實際路徑": str(resolve_code_path(kb, cp, sources)),
        "指紋": e["指紋"],
        "原檔修改時間": e["修改時間"],
        "其他位置": e.get("其他位置", []),
        "卡片": card,
        "狀態": e["狀態"],
    }


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["下一批", "抽樣", "完成", "失敗", "重設", "進度"])
    ap.add_argument("args", nargs="*")
    ap.add_argument("--數量", dest="n", type=int, default=10)
    ap.add_argument("--分區", dest="code")
    ap.add_argument("--原檔", dest="only", action="append", help="只取這幾份（改原資料夾後製卡用），可以給多次")
    ap.add_argument("--每區", dest="per", type=int, default=12)
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()

    kb = require_kb(a.kb)
    sources = load_sources(kb)
    inv_path = kb / INVENTORY_FILE

    if a.action == "進度":
        files = load(kb)["檔案"]
        by = defaultdict(Counter)
        for e in files.values():
            by[e["分區"]][e["狀態"]] += 1
        for s in sources["分區"]:
            c = by[s["代號"]]
            print(f"{s['名稱']}：" + "、".join(f"{k} {v}" for k, v in c.most_common()))
        total = Counter(e["狀態"] for e in files.values())
        print("總計：" + "、".join(f"{k} {v}" for k, v in total.most_common()))
        if total[RECALC_STATE]:
            print(f"{RECALC_STATE} {total[RECALC_STATE]} 份：AI 改過的 Excel 還沒重算，客戶用 Excel 打開、存檔後才製卡（不算還沒整理完）")
        return

    if a.action == "抽樣":
        files = load(kb)["檔案"]
        picked = []
        rnd = random.Random(42)
        for s in sources["分區"]:
            if a.code and s["代號"] != a.code:
                continue  # 建置後加的一區只試讀那一區（folders.py 加入，spec 4.7）
            cands = [(cp, e) for cp, e in files.items()
                     if e["分區"] == s["代號"] and e.get("指紋") and e["狀態"] in TODO + ("完成",)]
            # 依（格式, 第一層資料夾）分組，輪流各取一份，盡量分散
            groups = defaultdict(list)
            for cp, e in cands:
                rel = cp.split("}/", 1)[1]
                groups[(e["副檔名"], rel.split("/")[0] if "/" in rel else "")].append((cp, e))
            for g in groups.values():
                rnd.shuffle(g)
            keys = sorted(groups)
            sec = []
            while len(sec) < a.per and any(groups[k] for k in keys):
                for k in keys:
                    if groups[k] and len(sec) < a.per:
                        sec.append(groups[k].pop())
            picked += [item(kb, sources, cp, e) for cp, e in sec]
        print(json.dumps(picked, ensure_ascii=False, indent=1))
        return

    with FileLock(inv_path):
        inv = load(kb)
        files = inv["檔案"]

        if a.action == "下一批":
            out = []
            # 建置後新加、還沒試讀的一區（folders.py 加入），只有指定 --分區 時才取
            waiting = {s["代號"] for s in sources["分區"] if s.get("待試讀")} if not a.code else set()
            for cp, e in sorted(files.items()):
                if e["狀態"] in TODO and (not a.code or e["分區"] == a.code) and (not a.only or cp in a.only) \
                        and e["分區"] not in waiting:
                    out.append(item(kb, sources, cp, e))
                    e["處理前狀態"] = e["狀態"]
                    e["狀態"] = "處理中"
                    if len(out) >= a.n:
                        break
            write_json_atomic(inv_path, inv)
            print(json.dumps(out, ensure_ascii=False, indent=1))

        elif a.action == "完成":
            cp, card = a.args[0], a.args[1].replace("\\", "/")
            if cp not in files:
                sys.exit(f"清冊裡沒有：{cp}")
            if not (kb / card).exists():
                sys.exit(f"卡片不存在：{card}")
            e = files[cp]
            e.update({"狀態": "完成", "卡片": card, "製卡時間": now_str()})
            e.pop("處理前狀態", None)
            e.pop("原因", None)
            write_json_atomic(inv_path, inv)
            print(f"完成：{cp}")

        elif a.action == "失敗":
            cp, reason = a.args[0], " ".join(a.args[1:]) or "未說明"
            if cp not in files:
                sys.exit(f"清冊裡沒有：{cp}")
            files[cp].update({"狀態": "失敗", "原因": reason})
            files[cp].pop("處理前狀態", None)
            write_json_atomic(inv_path, inv)
            log_problem(kb, cp, reason)
            print(f"已記錄失敗：{cp}")

        elif a.action == "重設":
            n = 0
            for e in files.values():
                if e["狀態"] == "處理中":
                    e["狀態"] = e.pop("處理前狀態", "待處理")
                    n += 1
            write_json_atomic(inv_path, inv)
            print(f"已重設 {n} 份")


SUGGEST = {
    "密碼": "請客戶提供沒有密碼的版本，或決定不納入",
    ".doc": "請客戶用 Word 另存為 .docx",
    "找不到": "原檔可能已搬走或刪除，下次更新會重新比對",
}


def log_problem(kb, cp, reason):
    suggest = next((v for k, v in SUGGEST.items() if k in reason or cp.lower().endswith(k)), "")
    append_pending(kb, PENDING_UNREADABLE, f"| {now_str()} | {cp} | {reason} | {suggest} |")


if __name__ == "__main__":
    main()
