"""建立或補齊總資料夾與成品區。重複執行是安全的：已存在的檔案不會被覆寫。

用法：
  python init_kb.py <總資料夾路徑> --成品區 <路徑> --分區 "名稱|代號|來源路徑|說明|共用|AI 產出放哪" [--分區 ...] [--排除 規則 ...]
  「共用」寫 是 或 否（這個資料夾是否和別人共用，訪談第 2.5 題）；不寫當作「否」。
  「AI 產出放哪」寫 資料夾內 或 中央（spec 4.9，0.13.0）；不寫照預設：共用、雲端同步資料夾 → 中央，其他 → 資料夾內。
  重跑時沒寫就沿用來源清單原本的值。

會做的事：
  1. 把 plugin 的 skeleton/ 複製到總資料夾（skeleton/成品區/ 的內容改複製到成品區）
  2. 寫入（或合併）admin/來源清單.json：分區、排除規則、成品區位置
  3. 為每個分區建立 wiki/<名稱>/卡片、綜合，以及成品區/<名稱>/
  4. 寫入 CLAUDE.md（填入 plugin 與成品區路徑）與 .claude/settings.json
     （允許讀取來源、寫入成品區；放行 python 執行 plugin scripts/ 裡的程式；0.13.0 加：讀 ~/.claude/skills/、
     node 執行 .system/node/ 的腳本、python 執行技能資料夾裡的程式）
  5. 建立 .system/（含 0.13.0 的 草稿/、node/；npm 的 docx 套件由 build-setup 裝進 node/）
  6. 客戶設定檔補「辦公軟體」一節（0.13.0 以前建的）

plugin 改版後路徑會變：重新執行一次（只給總資料夾路徑即可），放行規則會換成新路徑。
CLAUDE.md 不會被覆寫，裡面的路徑以技能提供的為準。
"""
import argparse
import os
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from kbcommon import (AI_OUT_CENTRAL, AI_OUT_IN, DRAFT_DIR, JOURNAL_DIR, NODE_DIR, PROFILE_FILE, SOURCES_FILE,  # noqa: E402
                      add_basis_column, TEMP_DIR, VERSIONS_DIR, WIKI, ensure_ongoing_section, RESERVED_NAMES,
                      ai_out_mode, default_ai_out, free_code, is_shared, load_sources, path_problems, read_json,
                      utf8_io, write_json_atomic, write_text_atomic)

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKELETON = PLUGIN_ROOT / "skeleton"
OUTPUT_SKELETON = SKELETON / "成品區"
CROSS_OUTPUT = "跨區"


def fill(text, output):
    return text.replace("{{PLUGIN_ROOT}}", PLUGIN_ROOT.as_posix()).replace("{{OUTPUT}}", output)


def copy_tree(src_root, dst_root, output, skip=None):
    for src in src_root.rglob("*"):
        if skip and (src == skip or skip in src.parents):
            continue
        dst = dst_root / src.relative_to(src_root)
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        elif not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            write_text_atomic(dst, fill(src.read_text(encoding="utf-8"), output))


def path_inside(parent, child):
    try:
        Path(child).resolve().relative_to(Path(parent).resolve())
        return True
    except ValueError:
        return False


# 本程式寫入的放行規則：python 執行 plugin scripts/ 裡的程式。plugin 改版後路徑會變，重跑時先拿掉舊的再寫新的
OWN_RULE = re.compile(r'^(Bash|PowerShell)\(python "[^"]*[\\/]scripts[\\/]\*\)$')


def plugin_rules():
    """讓客戶不必對 plugin 自己的程式逐一按允許（自動模式也不會擋）。只放行這個 plugin 的 scripts/。"""
    roots = [f"{PLUGIN_ROOT.as_posix()}/scripts/*", f"{PLUGIN_ROOT}\\scripts\\*"]
    return [f'{tool}(python "{r})' for tool in ("Bash", "PowerShell") for r in dict.fromkeys(roots)]


def read_rule(root):
    """plugin 資料夾的唯讀放行（讀 rules/、templates/、技能）。Claude Code 在 Windows 把 C:\\x 寫成 //c/x；
    不用 additionalDirectories，那會連寫入一起給（0.10.1）。Read 規則也套用到 Glob、Grep。"""
    p = Path(root).as_posix()
    m = re.match(r"^([A-Za-z]):/(.*)", p)
    if m:
        p = f"/{m.group(1).lower()}/{m.group(2)}"
    return f"Read(/{p.rstrip('/')}/**)"


def old_plugin_roots(allow):
    """舊版放行規則裡的 plugin 路徑（從 Bash(python "<plugin>/scripts/*) 取出），改版時一起拿掉它們的 Read 規則。"""
    roots = set()
    for r in allow:
        m = re.match(r'^(?:Bash|PowerShell)\(python "(.*)[\\/]scripts[\\/]\*\)$', r)
        if m:
            roots.add(read_rule(m.group(1).replace("\\", "/")))
    return roots


def office_rules(kb):
    """Word、Excel（spec 4.9）：AI 要讀技能（docx／xlsx 的說明與 validate.py）、用 node 跑 .system/node/ 的腳本
    （那裡有 docx 套件）、用 python 跑技能資料夾裡的程式與 .system/node/ 裡 AI 寫的工作腳本（guard.py 會先看腳本內容，
    碰到來源或知識庫頁面就擋）。路徑不跟 plugin 改版變動，重跑時不重複加。"""
    skills = Path.home() / ".claude" / "skills"
    node = Path(kb) / NODE_DIR
    rules = [read_rule(skills)]
    for tool in ("Bash", "PowerShell"):
        for s in dict.fromkeys([skills.as_posix(), str(skills)]):
            sep = "/" if "/" in s else "\\"
            rules.append(f'{tool}(python "{s}{sep}*)')
        for n in dict.fromkeys([node.as_posix(), str(node)]):
            sep = "/" if "/" in n else "\\"
            rules.append(f'{tool}(node "{n}{sep}*)')
            # AI 自己寫的 Python 工作腳本（解開、改 XML、打包）只能放 .system/node/；guard.py 執行前檢查腳本內容
            rules.append(f'{tool}(python "{n}{sep}*)')
        rules.append(f"{tool}(node .system/node/*)")
    return list(dict.fromkeys(rules))


PROFILE_OFFICE = """## 辦公軟體

客戶平常用什麼辦公軟體（訪談時問）：Microsoft 365 桌面版、只有網頁版、Google 文件，或其他（LibreOffice、WPS）。
AI 只用來決定怎麼跟客戶說；能不能重算 Excel、轉 PDF，由程式每次自己偵測（office_tools.py）。

- 辦公軟體：
"""


def add_office_section(text):
    """0.13.0 以前的客戶設定檔沒有〈辦公軟體〉：插在〈回答偏好〉前（找不到就加在最後）。已經有就不動。"""
    if "## 辦公軟體" in text:
        return text
    i = text.find("## 回答偏好")
    if i < 0:
        return text.rstrip("\n") + "\n\n" + PROFILE_OFFICE
    return text[:i] + PROFILE_OFFICE + "\n" + text[i:]


def write_settings(kb, sources):
    """讓 Claude Code 可以讀取來源資料夾、寫入成品區，並放行 plugin 附帶的程式。"""
    path = kb / ".claude" / "settings.json"
    data = read_json(path, {}) or {}
    perms = data.setdefault("permissions", {})
    dirs = perms.setdefault("additionalDirectories", [])
    for p in [s["路徑"] for s in sources["分區"]] + ([sources["成品區"]] if sources["成品區"] else []):
        p = Path(p).as_posix()
        if p not in dirs:
            dirs.append(p)
    old = perms.get("allow", [])
    stale = old_plugin_roots(old)
    allow = [r for r in old if not OWN_RULE.match(r) and r not in stale]
    extra = office_rules(kb)
    allow = [r for r in allow if r not in extra]
    perms["allow"] = allow + plugin_rules() + [read_rule(PLUGIN_ROOT)] + extra
    write_json_atomic(path, data)


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("kb")
    ap.add_argument("--成品區", dest="output")
    ap.add_argument("--分區", dest="sections", action="append", default=[])
    ap.add_argument("--排除", dest="excludes", action="append", default=[])
    a = ap.parse_args()

    kb = Path(a.kb).resolve()
    kb.mkdir(parents=True, exist_ok=True)
    sources = load_sources(kb) if (kb / SOURCES_FILE).exists() else {"分區": [], "排除": [], "成品區": ""}

    for spec in a.sections:
        parts = spec.split("|")
        if len(parts) < 3:
            sys.exit(f"分區格式錯誤（要 名稱|代號|路徑|說明）：{spec}")
        name, code, path = (x.strip() for x in parts[:3])
        desc = parts[3].strip() if len(parts) > 3 else ""
        shared = parts[4].strip() if len(parts) > 4 and parts[4].strip() else "否"
        if shared not in ("是", "否"):
            sys.exit(f"分區的「共用」只能寫 是 或 否：{spec}")
        ai_out = parts[5].strip() if len(parts) > 5 and parts[5].strip() else None
        if ai_out and ai_out not in (AI_OUT_IN, AI_OUT_CENTRAL):
            sys.exit(f"分區的「AI 產出放哪」只能寫 {AI_OUT_IN} 或 {AI_OUT_CENTRAL}：{spec}")
        if not Path(path).is_dir():
            sys.exit(f"來源資料夾不存在：{path}")
        if path_inside(kb, path) or path_inside(path, kb):
            sys.exit("總資料夾和來源資料夾不能互相包含，請把總資料夾放在獨立位置。")
        # 同代號、同路徑是重跑（更新說明、共用）；同代號、不同路徑是新的一區，自動換代號、不取代（0.10.0）
        same = next((s for s in sources["分區"] if s["代號"] == code), None)
        if same and Path(same["路徑"]).resolve() != Path(path).resolve():
            new_code = free_code(sources, code)
            print(f"代號 {code} 已經是「{same['名稱']}」在用，新的一區改用代號 {new_code}。要換舊分區的位置請用 folders.py 改路徑。")
            code = new_code
        problems = path_problems(kb, {"分區": sources["分區"]}, path, ignore_code=code)
        if problems:
            sys.exit("；".join(problems))
        if any(s["名稱"] == name and s["代號"] != code for s in sources["分區"]) or name in RESERVED_NAMES:
            sys.exit(f"分區名稱「{name}」已經有人用了，請換一個名稱。")
        sec = {"名稱": name, "代號": code, "路徑": str(Path(path).resolve()), "說明": desc, "共用": shared}
        if not ai_out and same and same.get("AI 產出放哪"):
            ai_out = same["AI 產出放哪"]  # 重跑沒寫就沿用
        sec["AI 產出放哪"] = ai_out or default_ai_out(sec)
        sources["分區"] = [s for s in sources["分區"] if s["代號"] != code]
        sources["分區"].append(sec)
    for r in a.excludes:
        if r not in sources["排除"]:
            sources["排除"].append(r)

    if a.output:
        sources["成品區"] = str(Path(a.output).resolve())
    if not sources["成品區"]:
        sys.exit("請用 --成品區 指定成品區位置（例如 文件\\AI 產出）。")
    out = Path(sources["成品區"])
    if path_inside(kb, out) or path_inside(out, kb):
        sys.exit("成品區不能放在總資料夾裡，也不能包含總資料夾。")
    for s in sources["分區"]:
        if path_inside(s["路徑"], out) or path_inside(out, s["路徑"]):
            sys.exit(f"成品區不能和來源資料夾互相包含：{s['路徑']}")

    copy_tree(SKELETON, kb, out.as_posix(), skip=OUTPUT_SKELETON)
    copy_tree(OUTPUT_SKELETON, out, out.as_posix())
    write_json_atomic(kb / SOURCES_FILE, sources)

    for d in (TEMP_DIR, VERSIONS_DIR, JOURNAL_DIR, DRAFT_DIR, NODE_DIR, WIKI / "跨區綜合"):
        (kb / d).mkdir(parents=True, exist_ok=True)
    ensure_ongoing_section(kb)  # 舊版建的待處理.md 補第五節
    profile = kb / PROFILE_FILE
    if profile.exists():  # 0.11.0 以前的客戶設定檔：推測表格補「依據」欄
        old = profile.read_text(encoding="utf-8")
        new = add_office_section(add_basis_column(old))
        if new != old:
            write_text_atomic(profile, new)
    (out / CROSS_OUTPUT).mkdir(parents=True, exist_ok=True)
    for s in sources["分區"]:
        d = kb / WIKI / s["名稱"]
        (d / "卡片").mkdir(parents=True, exist_ok=True)
        (d / "綜合").mkdir(parents=True, exist_ok=True)
        (out / s["名稱"]).mkdir(parents=True, exist_ok=True)
    write_settings(kb, sources)

    print(f"總資料夾：{kb}")
    print(f"成品區：{out}")
    for s in sources["分區"]:
        shared = "，和別人共用" if is_shared(s) else ""
        print(f"  分區 {s['名稱']}（{{{s['代號']}}}{shared}，AI 產出放{ai_out_mode(s)}）← {s['路徑']}")
    print(f"  排除規則 {len(sources['排除'])} 條")


if __name__ == "__main__":
    main()
