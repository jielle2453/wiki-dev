"""健檢：把程式能做的檢查一次做完，整理成 lint 技能（每週檢查）需要判斷的清單。資料夾變動由 ingest 技能處理。
不改任何頁面（總目錄沒填時只印提醒，AI 自己補）。

  1. 結構：原檔路徑、清冊與卡片、索引、斷掉的連結、索引大小（同 check.py）
  2. 待更新的綜合頁
  3. 沒有出處的句子：逐句檢查句尾有沒有〔出處〕（不花 token，AI 只修找到的句子）
  4. 有交集的綜合頁分組：引用同一張卡片，或引用卡片的「相關主題」「相關的人」重疊。AI 每組讀一次找矛盾
  5. 待處理裡沒解決的事、設定檔裡待確認的推測（依在卡片中出現的次數排序）
  6. 一模一樣的檔案組（清冊已有的重複判斷，只建議不動手，0.11.0）
  7. 沒有卡片支持的推測：來源為「推測」、但現在沒有任何卡片提到（0.11.0）
  8. AI 起草的筆記與它參考的原檔、引用 AI 起草筆記的綜合頁（0.12.0，spec 4.8）

用法：
  python health.py 檢查     印出上面的清單
  python health.py 完成     記下這次健檢的日期（.system/健檢.json），開對話時的掛鉤據此判斷是否滿 7 天
  python health.py 不再提重複 <{代號}/路徑> ...   客戶說不用整理的重複檔組，之後不再列（記在 .system/重複檔不再提.json）
  python health.py 留著推測 "表名|名稱" ...      客戶說留著的「沒有卡片支持的推測」，之後不再問（.system/推測不再問.json）
"""
import argparse
import os
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote

sys.dont_write_bytecode = True  # 不在 plugin 資料夾留下 __pycache__
sys.path.insert(0, os.path.dirname(__file__))
from check import structure_problems  # noqa: E402
from inventory import GONE as GONE_STATES  # noqa: E402
from kbcommon import (INVENTORY_FILE, PENDING_APPROVE, PENDING_FILE, PENDING_STAFF, PENDING_UNREADABLE,  # noqa: E402
                      PROFILE_FILE, SYSTEM, WIKI, append_pending, budget_line, card_texts, mentioned, now_str, parse_front_matter, read_json,
                      require_kb, utf8_io, write_json_atomic)

HEALTH_FILE = SYSTEM / "健檢.json"
DUE_DAYS = 7
DONE = ("已同意", "已拒絕", "已完成")
LINK = re.compile(r"\]\(<?([^)>]+)>?\)")
CITE = re.compile(r"〔[^〕]*〕")
# 一句：到句號為止，連同緊接在後的〔出處〕
SENTENCE = re.compile(r"[^。！？]*[。！？]?(?:\s*〔[^〕]*〕)*")


def last_check(kb):
    """上次健檢的時間（datetime）；沒有紀錄（建置還沒收尾）回傳 None。"""
    rec = read_json(kb / HEALTH_FILE)
    try:
        return datetime.strptime(rec["上次"], "%Y-%m-%d %H:%M")
    except (TypeError, KeyError, ValueError):
        return None


def days_since(kb):
    last = last_check(kb)
    return None if last is None else (datetime.now() - last).days


def synthesis_pages(kb):
    w = kb / WIKI
    pages = sorted((w / "跨區綜合").glob("*.md"))
    for d in sorted(w.iterdir()) if w.exists() else []:
        if d.is_dir() and (d / "綜合").is_dir():
            pages += sorted((d / "綜合").glob("*.md"))
    return pages


def body_lines(text):
    """頁首之後的內文，回傳 [(行號, 內容)]。"""
    lines = text.split("\n")
    start = 0
    if text.startswith("---"):
        end = next((i for i, ln in enumerate(lines[1:], 1) if ln.strip() == "---"), 0)
        start = end + 1
    return [(i + 1, ln.rstrip("\r")) for i, ln in enumerate(lines) if i >= start]


def has_source(segment):
    """這一句有沒有出處：〔〕裡有連結，或標了「原檔已刪除」。"""
    return any("](" in c or "原檔已刪除" in c for c in CITE.findall(segment))


def uncited(text):
    """沒有出處的句子：[(行號, 句子開頭)]。標題、表格分隔線、範本說明（全形括號包住的整行）不算。"""
    out = []
    lines = body_lines(text)
    for i, (no, line) in enumerate(lines):
        s = line.strip()
        if not s or s.startswith(("#", "|-", "<!--")) or re.fullmatch(r"[（(].*[)）]", s):
            continue
        nxt = lines[i + 1][1].strip() if i + 1 < len(lines) else ""
        if s.startswith("|") and nxt.startswith("|-"):
            continue  # 表格的表頭
        s = re.sub(r"^([-*]|\d+\.)\s+", "", s)  # 條列記號
        for seg in SENTENCE.findall(s):
            plain = CITE.sub("", seg).strip(" 。！？，、：；")
            if len(plain) < 4:  # 只有標點或出處
                continue
            if not has_source(seg):
                out.append((no, plain[:40]))
    return out


def cited_cards(kb, page, text, meta):
    """綜合頁引用的卡片（以總資料夾為準的路徑）：頁首「引用的卡片」加上內文連到卡片/的連結。"""
    cards = {str(c).replace("\\", "/") for c in (meta.get("引用的卡片") or []) if str(c).strip()}
    for t in LINK.findall(text):
        t = unquote(t.split("#")[0].strip())
        if "/卡片/" in "/" + t.replace("\\", "/") and not re.match(r"^[a-z]+:", t, re.I):
            try:
                cards.add((page.parent / t).resolve().relative_to(kb.resolve()).as_posix())
            except ValueError:
                pass
    return cards


# 出現在四成以上卡片、且至少 30 張的人或主題（例如老闆、公司名）太常見，不拿來分組，免得全部頁面併成一組。
# 小型知識庫不會觸發（推估值，實際規模下再調）
COMMON_SHARE = 0.4
COMMON_MIN = 30


def common_tags(kb):
    """太常見、不拿來分組的「主題：…」「人：…」。"""
    count, total = defaultdict(int), 0
    for c in (kb / WIKI).glob("*/卡片/*.md"):
        m = parse_front_matter(c.read_text(encoding="utf-8"))
        total += 1
        for t in {f"主題：{x}" for x in (m.get("相關主題") or [])} | {f"人：{x}" for x in (m.get("相關的人") or [])}:
            count[t] += 1
    return {t for t, n in count.items() if n >= COMMON_MIN and n >= total * COMMON_SHARE}


WAITING = {"已變動": "還在等重做", "處理中": "正在重做", "失敗": "重做失敗", "原檔已不存在": "原檔不見", "預期刪除": "原檔不見"}


def stale_pages(kb, pages=None):
    """狀態為「待更新」的綜合頁：[(路徑, 註記)]。引用的卡片還在等重做、重做失敗或原檔不見時加註記，
    這些頁先不要重寫（依舊筆記重寫會寫錯）。"""
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    card_status = {e["卡片"]: e["狀態"] for e in inv.values() if e.get("卡片")}
    out = []
    for p in pages if pages is not None else synthesis_pages(kb):
        text = p.read_text(encoding="utf-8")
        meta = parse_front_matter(text)
        if str(meta.get("狀態", "")) != "待更新":
            continue
        waiting = sorted({WAITING[card_status[c]] for c in cited_cards(kb, p, text, meta)
                          if card_status.get(c) in WAITING})
        note = f"（引用的筆記{'、'.join(waiting)}，先不重寫）" if waiting else ""
        out.append((p.relative_to(kb).as_posix(), note))
    return out


def overlap_groups(kb, pages, skip_tags=frozenset()):
    """有交集的綜合頁分組（同一組至少兩頁）。回傳 [(頁面清單, 交集說明)]。
    已停用、待更新（內容等重寫，拿來比會比出假矛盾）的頁不分組；skip_tags 裡太常見的人與主題不算交集。"""
    info = {}
    card_meta = {}
    for p in pages:
        text = p.read_text(encoding="utf-8")
        meta = parse_front_matter(text)
        if str(meta.get("狀態", "")) in ("已停用", "待更新"):
            continue
        rel = p.relative_to(kb).as_posix()
        cards = cited_cards(kb, p, text, meta)
        tags = set()
        for c in cards:
            if c not in card_meta:
                f = kb / c
                card_meta[c] = parse_front_matter(f.read_text(encoding="utf-8")) if f.exists() else {}
            m = card_meta[c]
            tags |= {f"主題：{t}" for t in (m.get("相關主題") or []) if str(t).strip()}
            tags |= {f"人：{t}" for t in (m.get("相關的人") or []) if str(t).strip()}
        info[rel] = ({f"卡片：{Path(c).stem}" for c in cards}, tags - skip_tags)

    parent = {r: r for r in info}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    by_key = defaultdict(list)
    for r, (cards, tags) in info.items():
        for k in cards | tags:
            by_key[k].append(r)
    for rs in by_key.values():
        for r in rs[1:]:
            parent[find(r)] = find(rs[0])

    groups = defaultdict(list)
    for r in info:
        groups[find(r)].append(r)
    out = []
    for members in groups.values():
        if len(members) < 2:
            continue
        shared = sorted(k for k, rs in by_key.items() if len(set(rs) & set(members)) >= 2)
        out.append((sorted(members), shared))
    return sorted(out, key=lambda g: (-len(g[0]), g[0]))


def ai_cards(kb):
    """AI 起草的卡片（出處類別「AI 產出」）與有來歷的原檔（AI 起草、客戶改過），以及它們參考的原檔的卡片（spec 4.8）。
    回傳 {卡片: (類別說明, [參考的卡片或原檔])}。找矛盾、判斷依據時，這些卡片和參考的原檔不算兩份互相印證的資料。"""
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    out = {}
    for c in (kb / WIKI).glob("*/卡片/*.md"):
        m = parse_front_matter(c.read_text(encoding="utf-8"))
        kind = str(m.get("出處類別", ""))
        if kind != "AI 產出" and not m.get("來歷"):
            continue
        refs = [inv.get(str(r), {}).get("卡片") or str(r) for r in (m.get("參考的原檔") or [])]
        label = "AI 起草" if kind == "AI 產出" else str(m.get("來歷"))
        out[c.relative_to(kb).as_posix()] = (label, refs)
    return out


def unmarked_ai_citations(kb, page, text, meta, drafts):
    """這頁引用了哪些 AI 起草的卡片、而且那個出處還沒寫成〔AI 起草：[名稱](<…>)〕（寫好的不再列，免得每週重做）。
    頁首「引用的卡片」有、內文卻沒有連結的也算（還沒處理）。"""
    out = set()
    linked = set()
    for m in re.finditer(r"\]\(<?([^)>]+)>?\)", text):
        t = unquote(m.group(1).split("#")[0].strip())
        if re.match(r"^[a-z]+:", t, re.I) or "/卡片/" not in "/" + t.replace("\\", "/"):
            continue
        try:
            c = (page.parent / t).resolve().relative_to(kb.resolve()).as_posix()
        except ValueError:
            continue
        if c not in drafts:
            continue
        linked.add(c)
        start = text.rfind("〔", 0, m.start())
        if start < 0 or "AI 起草" not in text[start:m.start()]:
            out.add(c)
    for c in cited_cards(kb, page, text, meta):
        if c in drafts and c not in linked:
            out.add(c)
    return out


def table_rows(text, section):
    """待處理.md 或設定檔某一節表格的資料列（不含表頭與分隔線），每列是儲存格清單。"""
    rows, inside, seen_head = [], False, False
    for ln in text.split("\n"):
        if ln.startswith("## "):
            inside, seen_head = ln.strip() == f"## {section}", False
            continue
        if inside and ln.strip().startswith("|"):
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if not seen_head:
                seen_head = True
                continue
            if set("".join(cells)) <= set("-: "):
                continue
            rows.append(cells)
    return rows


def pending_items(kb, since):
    text = (kb / PENDING_FILE).read_text(encoding="utf-8") if (kb / PENDING_FILE).exists() else ""
    approve = [r for r in table_rows(text, PENDING_APPROVE) if r and not any(r[-1].startswith(d) for d in DONE)]
    staff = [r for r in table_rows(text, PENDING_STAFF) if r and not any(r[-1].startswith(d) for d in DONE)]
    unreadable = table_rows(text, PENDING_UNREADABLE)
    if since:
        cutoff = since.strftime("%Y-%m-%d %H:%M")
        unreadable = [r for r in unreadable if r and r[0] > cutoff]
    return approve, unreadable, staff


def note_unfinished_toc(kb):
    """總目錄還是範本（分區表沒有資料列）、但檔案都已製卡時，提醒 AI 自己補上（0.10.1：客戶可能自己用 AI 建置，
    不一定有服務人員在場，所以不再記給服務人員）。回傳要印的一行說明；沒事時回傳空字串。這件事 AI 常漏，所以交給程式提醒。"""
    toc = kb / WIKI / "總目錄.md"
    if not toc.exists() or table_rows(toc.read_text(encoding="utf-8"), "分區"):
        return ""
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    if not inv or any(e["狀態"] in ("待處理", "已變動", "處理中") for e in inv.values()):
        return ""  # 還在建置或整理中，總目錄本來就還沒填
    return ("總目錄還沒填（檔案都已整理好）：這個回答照 query 技能〈開始前〉補上 wiki/總目錄.md"
            "（格式與規則同 build-finish 寫總目錄那一步，含「可以這樣問」），改動紀錄記一行；不用跟客戶說還在整理")


PROFILE_TABLES = ("詞彙表", "文件類型", "重要的人與組織", "專案或案件")


def guesses(kb):
    """設定檔裡來源是「推測」、卡片有提到的條目，依在卡片中出現的次數由多到少：[(表, 名稱, 次數)]。"""
    p = kb / PROFILE_FILE
    if not p.exists():
        return []
    text = p.read_text(encoding="utf-8")
    cards = [c.read_text(encoding="utf-8") for c in (kb / WIKI).glob("*/卡片/*.md")]
    types = [str(parse_front_matter(c).get("文件類型", "")) for c in cards]
    lowered = [c.lower() for c in cards]
    out = []
    for table in PROFILE_TABLES:
        for r in table_rows(text, table):
            if len(r) < 2 or not r[-1].startswith("推測") or not r[0]:
                continue
            name = r[0]
            if not mentioned(name, lowered):
                continue  # 沒有卡片支持的另外列（第 10 項），不再問對不對
            n = types.count(name) if table == "文件類型" else sum(1 for c in cards if name in c)
            out.append((table, name, n))
    return sorted(out, key=lambda x: -x[2])


KEEP_GUESS_FILE = SYSTEM / "推測不再問.json"  # 客戶說留著的「沒有卡片支持的推測」（記「表|名稱」）


def unsupported_guesses(kb):
    """來源為「推測」、但現在任何一張卡片都沒提到的條目（健檢第 10 項，0.11.0）：原檔刪了、排除了，推測還留著。
    比對方式同 kbcommon.mentioned。訪談、客戶確認、客戶糾正的不查；客戶說留著的不再列。回傳 [(表, 名稱)]。"""
    p = kb / PROFILE_FILE
    if not p.exists():
        return []
    keep = set(read_json(kb / KEEP_GUESS_FILE, []) or [])
    texts = card_texts(kb)
    text = p.read_text(encoding="utf-8")
    out = []
    for table in PROFILE_TABLES:
        for r in table_rows(text, table):
            if len(r) < 2 or not r[-1].startswith("推測") or not r[0]:
                continue
            if f"{table}|{r[0]}" not in keep and not mentioned(r[0], texts):
                out.append((table, r[0]))
    return out


def keep_guesses(kb, items):
    keep = list(read_json(kb / KEEP_GUESS_FILE, []) or [])
    for x in items:
        t, sep, n = x.replace("｜", "|").partition("|")
        if not sep or t.strip() not in PROFILE_TABLES:
            sys.exit(f"要寫成「表名|名稱」，表名是 {'、'.join(PROFILE_TABLES)} 其中一個：{x}")
        key = f"{t.strip()}|{n.strip()}"
        if key not in keep:
            keep.append(key)
    write_json_atomic(kb / KEEP_GUESS_FILE, keep)
    print(f"已記下：這 {len(items)} 條推測留著，之後不再問。")


DUP_FILE = SYSTEM / "重複檔不再提.json"  # 客戶說不用整理的重複檔組（記指紋）
DUP_SHOW = 3


def duplicate_groups(kb):
    """清冊裡內容一模一樣的檔案組（主檔加「其他位置」，inventory 已判斷好），客戶說過不用整理的不列（決策 #42）。
    回傳 [[{代號}/路徑, …], …]，份數多的組在前。"""
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    skip = set(read_json(kb / DUP_FILE, []) or [])
    groups = []
    for cp, e in inv.items():
        others = [o for o in e.get("其他位置", []) if o in inv]
        if any(inv.get(c, {}).get("預期刪除") for c in [cp, *others]):
            continue  # 客戶已經說要刪掉其中幾份（預期刪除），等他刪
        if others and e.get("指紋") not in skip and e["狀態"] not in GONE_STATES:
            groups.append([cp, *others])
    return sorted(groups, key=lambda g: (-len(g), g[0]))


def dismiss_duplicates(kb, cps):
    inv = (read_json(kb / INVENTORY_FILE, {}) or {}).get("檔案", {})
    skip = list(read_json(kb / DUP_FILE, []) or [])
    done = []
    for cp in cps:
        d = (inv.get(cp) or {}).get("指紋")
        if not d:
            print(f"清冊裡沒有這一份（或還沒有指紋）：{cp}")
            continue
        if d not in skip:
            skip.append(d)
        done.append(cp)
    write_json_atomic(kb / DUP_FILE, skip)
    print(f"已記下：這 {len(done)} 組重複檔之後不再提。")


def show(title, items, limit=30):
    print(f"\n## {title}（{len(items)}）")
    for x in items[:limit]:
        print(f"- {x}")
    if len(items) > limit:
        print(f"- ……其餘 {len(items) - limit} 項")


def check(kb):
    since = last_check(kb)
    pages = synthesis_pages(kb)
    print(f"健檢資料（{now_str()}）｜上次健檢：{since.strftime('%Y-%m-%d') if since else '沒有紀錄'}"
          f"｜綜合頁 {len(pages)} 頁、卡片 {len(list((kb / WIKI).glob('*/卡片/*.md')))} 張")
    print(budget_line(kb))
    toc = note_unfinished_toc(kb)
    if toc:
        print(toc)

    show("結構問題", [f"{k}：{w}" for k, w in structure_problems(kb)])

    conflicted, no_source = [], []
    for p in pages:
        text = p.read_text(encoding="utf-8")
        status = str(parse_front_matter(text).get("狀態", ""))
        rel = p.relative_to(kb).as_posix()
        if status == "已停用":
            continue
        for no, s in uncited(text):
            no_source.append(f"{rel} 第 {no} 行：{s}" + ("（客戶確認過的頁）" if status.startswith("客戶確認") else ""))
        if status == "有矛盾":
            conflicted.append(rel)
    show("待更新的綜合頁", [r + n for r, n in stale_pages(kb, pages)])
    show("沒有出處的句子", no_source, limit=60)
    show("已標「有矛盾」、等客戶判斷的綜合頁", conflicted)

    common = common_tags(kb)
    groups = overlap_groups(kb, pages, common)
    print(f"\n## 有交集的綜合頁分組（{len(groups)} 組；每組讀一次，組內互相比對；待更新的頁不比對）")
    if common:
        print("太常見、不拿來分組：" + "、".join(sorted(common)))
    for i, (members, shared) in enumerate(groups, 1):
        print(f"- 第 {i} 組（{len(members)} 頁）：" + "、".join(members))
        print("    交集：" + "、".join(shared[:8]) + ("……" if len(shared) > 8 else ""))

    ai = ai_cards(kb)
    drafts = {c: v for c, v in ai.items() if v[0] == "AI 起草"}
    show("AI 起草的筆記（和它參考的原檔不算兩份互相印證；說法不同時以原檔為準，是草稿過時、不算矛盾）",
         [f"{c} ← 參考：{'、'.join(refs) or '沒有記'}" for c, (label, refs) in sorted(drafts.items())])
    show("客戶改過的 AI 起草文件（出處類別是原檔；和它參考的原檔說法一樣不算互相印證，說法不同算矛盾）",
         [f"{c}（{label}）← 參考：{'、'.join(refs) or '沒有記'}" for c, (label, refs) in sorted(ai.items()) if c not in drafts])
    citing = []
    for p in pages:
        text = p.read_text(encoding="utf-8")
        meta = parse_front_matter(text)
        if str(meta.get("狀態", "")) == "已停用":
            continue
        used = sorted(c for c in unmarked_ai_citations(kb, p, text, meta, drafts))
        if used:
            citing.append(f"{p.relative_to(kb).as_posix()} → " + "、".join(used))
    show("引用 AI 起草筆記、還沒處理的綜合頁（盡量改引它參考的原檔；只有 AI 起草能支持的句子寫〔AI 起草：[名稱](<…>)〕，"
         "已經這樣寫的不再列）", citing)

    approve, unreadable, staff = pending_items(kb, since)
    show("等你同意的改動（還沒回覆）", [" | ".join(r) for r in approve])
    show("上次健檢後新增的讀不到的檔案", [" | ".join(r[:3]) for r in unreadable])
    show("等服務人員處理（不跟客戶提）", [" | ".join(r) for r in staff])
    g = guesses(kb)
    show("待確認的推測（依出現次數）", [f"{t}｜{n}｜出現在 {c} 張卡片" for t, n, c in g])
    lost = unsupported_guesses(kb)
    show("沒有卡片支持的推測（照問客戶最多 3 件排隊，問要不要刪；不要自己刪；客戶說留著就用 health.py 留著推測）",
         [f"{t}｜{n}" for t, n in lost])
    dups = duplicate_groups(kb)
    print(f"\n## 一模一樣的檔案（{len(dups)} 組；只建議、不動手；一次最多提 {DUP_SHOW} 組，不佔問客戶 3 件的名額）")
    for cps in dups[:DUP_SHOW]:
        print("- " + "、".join(cps))
    if len(dups) > DUP_SHOW:
        print(f"- ……其餘 {len(dups) - DUP_SHOW} 組下次再提")
    if dups:
        print("客戶說不用整理的那一組：health.py 不再提重複 \"<其中一個位置>\"，之後就不再提")

    print(f"\n要客戶回應的事：有矛盾的頁 {len(conflicted)}（一件矛盾通常跨兩頁，問之前先讀頁裡〈說法不一致的地方〉算件數）、"
          f"等你同意 {len(approve)}、推測 {len(g)}、沒有卡片支持的推測 {len(lost)}；不含這次新找到的矛盾")


def main():
    utf8_io()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["檢查", "完成", "不再提重複", "留著推測"])
    ap.add_argument("files", nargs="*")
    ap.add_argument("--知識庫", dest="kb")
    a = ap.parse_args()
    kb = require_kb(a.kb)
    if a.action == "檢查":
        check(kb)
    elif a.action == "不再提重複":
        if not a.files:
            sys.exit("請指定那一組裡任一份的位置，例如「{行政}/報價單.xlsx」")
        dismiss_duplicates(kb, a.files)
    elif a.action == "留著推測":
        if not a.files:
            sys.exit("請寫「表名|名稱」")
        keep_guesses(kb, a.files)
    else:
        write_json_atomic(kb / HEALTH_FILE, {"上次": now_str()})
        print(f"已記下健檢時間：{now_str()}（{DUE_DAYS} 天後開對話時會再提醒）")


if __name__ == "__main__":
    main()
