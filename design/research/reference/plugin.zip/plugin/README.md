# LLM-wiki plugin（0.13.1）

把客戶既有的資料夾建成 AI 維護的知識庫，答案都指回原檔。規格見 [design/spec.md](../design/spec.md)。

## 組成

| 部分 | 位置 | 給誰 |
|---|---|---|
| 建置指令 | `commands/`：build-setup → build-inventory → build-sample → build-cards → build-finish | 服務人員（要輸入 `/llm-wiki:<指令>` 才會執行） |
| 問答技能 | `skills/query/`：問答、找檔案、起草 Word／Excel、退回；客戶親口要求時改原資料夾（0.9.0，改既有 Word／Excel 另存「（AI 修改）」0.13.0）、管理資料夾（0.10.0） | 客戶（用一般的話問就會觸發） |
| 納入技能 | `skills/ingest/`：把來源資料夾的新增、修改、搬動、刪除整理進知識庫（開對話時自動，或客戶說「更新」） | 客戶 |
| 健檢技能 | `skills/lint/`：每週檢查（補出處、更新過時整理、找矛盾、分批問待確認的事）。滿 7 天時 AI 在回答末尾問客戶，客戶回「檢查」或說「幫我檢查一下」才做（決策 #36） | 客戶 |
| 製卡代理 | `agents/card-maker.md` | 建置指令與維護技能派出；檔案內容只在代理裡讀，主畫面看不到 |
| 掛鉤 | `hooks/`：開對話時檢查資料夾變動與健檢是否到期、帶入〈做到一半的事〉與最近的工作日誌；對話摺疊後提醒重讀規則；每個問題記進工作日誌；原檔保護（只放行單獨呼叫的 `source_edit.py`；`.system/node/` 的工作腳本先看內容，0.13.0）、改動前自動備份（每個問題一個版本）、大改動攔截；寫進成品區之後登記 AI 產出（0.12.0） | 自動執行 |
| 核心規則 | `rules/core-rules.md`（每次讀）、`rules/maintenance.md`（ingest、lint 共用）、`rules/page-formats.md`（寫卡片與綜合頁時才讀）、`rules/office.md`（產生與修改 Word、Excel 時才讀，0.13.0） | 所有技能與代理共用 |
| 程式 | `scripts/`（只用標準函式庫，加 MarkItDown 與 pdfplumber；掃描 PDF 轉圖用 pdfplumber 附帶的 pypdfium2）。Word、Excel 由 Anthropic 的 docx／xlsx 技能產生（不包進 plugin）；重算與轉 PDF 用客戶原本的 Office 或 LibreOffice（`office_tools.py`） | 技能與指令呼叫 |
| 骨架 | `skeleton/`：只用一次的頁面，建立總資料夾時整個複製（`skeleton/成品區/` 的內容複製到成品區） | init_kb.py 使用 |
| 範本 | `templates/`：卡片、綜合頁、總覽，重複使用，標有範本版本；`templates/自檢/`：envcheck 的 Office 自檢用的小檔（0.13.0） | 製卡代理、問答技能、收尾指令、envcheck |

## 第一版尚未包含

磨合調整；mod 介面（spec 13.2）。

0.4.0 以前建的總資料夾沒有健檢紀錄，開對話時不會提醒健檢：執行一次 `python "<plugin 路徑>/scripts/health.py" 完成` 即可開始計算。起草文件：0.13.0 起產出 Word、Excel（要客戶帳號開啟 docx／xlsx 技能、裝 Node.js 與 docx 套件）。

日常環境是桌面版 Claude Code（Claude 桌面程式的 Code 分頁），不支援 Cowork（spec 決策 #22）。開對話時的自動檢查在 CLI 版以模擬輸入測過，桌面版待端到端實測。

## 試用方式

1. 在任一資料夾開 Claude Code，載入 plugin：`claude --plugin-dir "<本資料夾路徑>"`
2. 依序執行建置指令：`/llm-wiki:build-setup`（指定總資料夾、成品區與來源資料夾）。
3. 依指示改在總資料夾重新開啟（同樣加 `--plugin-dir`），再執行 build-inventory、build-sample、build-cards、build-finish。
4. 建置完成後，在總資料夾直接問問題；起草的文件在成品區。

**plugin 改版後：** 在客戶電腦上重跑一次 `python "<新 plugin 路徑>/scripts/init_kb.py" "<總資料夾>"`。總資料夾 `.claude/settings.json` 裡放行 plugin 程式的規則會換成新路徑（舊路徑的規則自動拿掉），否則客戶每次執行程式都會被詢問。

每個版本改了什麼、舊版建的總資料夾要怎麼跟上，見 [design/版本紀錄.md](../design/版本紀錄.md)。
