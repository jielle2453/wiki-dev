#!/usr/bin/env python3
"""偵測 vault 成熟度，輸出對應深度的指導。

設計原則：等級掛在 vault 上，不掛在人身上。
人的等級是自陳的、不會主動升級；vault 的成熟度是可測的、會自己長大。

用法：
    python vault_state.py            # 人看的報告
    python vault_state.py --json     # 機器讀的完整訊號
    python vault_state.py --brief    # SessionStart hook 用（極簡）
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _lib import derived as _derived  # noqa: E402
from _lib.vaultpaths import (find_vault_root, load_manifest,  # noqa: E402
                             manifest_sources, resolve_repo_path, resolve_source)
try:
    import _guard_status  # noqa: E402
except ImportError:      # 守門留痕模組缺席不該讓開場量測掛掉
    _guard_status = None

def _this_host():
    """本機名稱，和 `wiki/meta/_guard-status/<機器>.json` 用的是同一套正規化。

    讀不到就回 ""，呼叫端當作「分不出是誰的機器」處理（照舊回報，不要靜音）。
    """
    try:
        import platform
        name = platform.node()
    except Exception:
        return ""
    if _guard_status is not None and hasattr(_guard_status, "_safe_host"):
        return _guard_status._safe_host(name)
    return name or ""


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# --- 門檻（集中在此，方便調整） ---
SEED_MAX = 20            # 頁數 < 此值 = 新生 vault
GROWING_MAX = 100        # 頁數 < 此值 = 成長中
LOG_WARN_KB = 200        # log.md 超過此大小 = 讀不動了
PAGE_WARN_KB = 100       # 單頁超過此大小 = 該拆
HOT_WARN_LINES = 150     # hot.md 超過此行數 = 輪替沒執行
CLAUDE_WARN_LINES = 150  # CLAUDE.md 超過此行數 = 該把按需規則拆到 wiki/ops/
RULING_MAX = 5           # CLAUDE.md 🔴／⚠️ 區各最多幾條，多的搬 wiki/ops/rulings.md
LINT_STALE_DAYS = 60     # 距上次健檢超過此天數 = 該跑了
# hot.md 的 mtime 日期比 log 最後一條舊 = 收尾協議沒跑（不是「幾天沒動」，是「落後於實際操作」）
DAY = 86400
# 不算「知識頁」的東西：系統骨架與規則層。剛 init 的 vault 頁數應為 0，不是 8。
NON_PAGE_TYPES = {"meta", "ops-rule", "fold"}
NON_PAGE_FILES = {"log.md", "hot.md", "index.md"}
GUARD_ALWAYS = ("tidy-check", "stale-check")   # 這兩支任何 vault 都該跑；其餘只在留痕過才追蹤
_TYPE_RE = re.compile(r"^type:\s*([\w\-]+)", re.M)


def _fm_type(p: Path):
    """frontmatter 的 type:，沒有回 None。只讀檔頭。"""
    try:
        with p.open(encoding="utf-8", errors="replace") as f:
            head = f.read(600)
    except OSError:
        return None
    if not head.startswith("---"):
        return None
    m = _TYPE_RE.search(head.split("---", 2)[1] if head.count("---") >= 2 else head)
    return m.group(1) if m else None


def _count_pages(wiki: Path):
    """回傳 (頁數, 最大的幾頁)。頁數排除 meta／ops-rule／fold 與 log／hot／index。"""
    pages, sizes = 0, []
    for p in wiki.rglob("*.md"):
        # 只看 wiki/ 內的相對路徑——絕對路徑可能含 . 開頭的父目錄（會被誤判成隱藏檔）
        rel = p.relative_to(wiki)
        if any(part.startswith(".") for part in rel.parts):
            continue
        try:
            sizes.append((p.stat().st_size, p))
        except OSError:
            pass
        if str(rel).replace("\\", "/") in NON_PAGE_FILES or _fm_type(p) in NON_PAGE_TYPES:
            continue
        pages += 1
    sizes.sort(reverse=True)
    return pages, sizes[:5]


def _guard_stale(root: Path):
    """守門失聯清單。只列「留痕過」或 GUARD_ALWAYS 的腳本，免得沒 agenda 的 vault 被唸。"""
    if _guard_status is None:
        return []
    try:
        known = _guard_status.known_scripts()
    except OSError:
        known = set()
    track = known | set(GUARD_ALWAYS)
    return [h for h in _guard_status.stale_report() if h.split("：", 1)[0] in track]


def _git_last_commit_age(root: Path):
    """距最後一次 commit 幾天。非 git 或無 commit 回 None。"""
    try:
        out = subprocess.run(
            ["git", "-C", str(root), "log", "-1", "--format=%ct"],
            capture_output=True, text=True, timeout=5,
        )
        if out.returncode == 0 and out.stdout.strip():
            return (time.time() - int(out.stdout.strip())) / DAY
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return None


def _git_presence(root: Path):
    """vault 根有沒有自己的 .git，以及有沒有用過 git 的痕跡。

    只看 root/.git 本身：用 `git rev-parse` 會往上找到外層 repo（例如家目錄本身是 repo），
    把「vault 自己的 .git 被刪」誤判成有版控。
    痕跡＝.gitignore 或 Obsidian 的 obsidian-git 外掛：有痕跡卻沒 .git，幾乎一定是 .git 被刪或沒還原。
    """
    has_git = (root / ".git").exists()  # 目錄，或 worktree／submodule 的 .git 檔
    traces = [t for t in (".gitignore", ".obsidian/plugins/obsidian-git") if (root / t).exists()]
    return has_git, traces


def _newest_mtime(paths):
    best = None
    for p in paths:
        try:
            m = p.stat().st_mtime
        except OSError:
            continue
        if best is None or m > best:
            best = m
    return best


def _ruling_overflow(text):
    """CLAUDE.md 的 🔴／⚠️ 區各數條目（以 - 或 ### 開頭），超過 RULING_MAX 就回報。"""
    out, sec, n = [], None, 0
    for line in text.splitlines() + ["## END"]:
        if line.startswith("## "):
            if sec and n > RULING_MAX:
                out.append((sec, n))
            sec = "🔴 鐵律／裁示" if line.startswith("## 🔴") else "⚠️ 踩過的雷" if line.startswith("## ⚠️") else None
            n = 0
        elif sec and (line.startswith("- ") or line.startswith("### ")):
            n += 1
    return out


INGESTABLE = {".pdf", ".md", ".docx", ".doc", ".xlsx", ".pptx", ".txt"}


def _raw_pending(root: Path, manifest):
    """raw/ 底下還沒 ingest 的檔數。

    只為了回答「開場該不該推 /wiki-ingest」—— 素材都編完了還在推，
    等於每個 session 開頭都叫人做一件已經做完的事（2026-09-21 驗收發現）。
    `_README.md` 是資料夾儀表板、不是來源，不計。
    """
    raw = root / "raw"
    if not raw.is_dir():
        return 0
    done = set(manifest_sources(manifest))
    n = 0
    try:
        for p in raw.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in INGESTABLE:
                continue
            # 🔴 只看 raw/ 內的相對路徑：絕對路徑可能含 . 開頭的父目錄（ISS-015）。
            # 同一支檔的 :84 早就這樣寫、註解也寫了這個坑，這裡仍犯了 —— 靠守門不靠註解。
            if p.name == "_README.md" or any(
                    x.startswith(".") for x in p.relative_to(raw).parts):
                continue
            if str(p.relative_to(root)).replace("\\", "/") not in done:
                n += 1
    except OSError:
        return 0
    return n


def collect(root: Path):
    wiki = root / "wiki"
    manifest = load_manifest(root)

    s = {
        "root": str(root),
        "has_wiki": wiki.is_dir(),
        "pages": 0,
        "big_pages": [],
        "log_kb": 0,
        "hot_lines": None,
        "claude_lines": None,
        "ruling_overflow": [],
        "sources": len(manifest_sources(manifest)),
        "repos": [k for k in manifest.get("repos", {}) if not k.startswith("_")],
        "days_since_lint": None,
        "days_since_commit": _git_last_commit_age(root),
        "git_repo": None,
        "git_traces": [],
        "broken_sources": [],
        "broken_repos": [],
        "foreign_repos": [],      # (alias, 機器名)：路徑不在，但 owner 標明是別人的機器
        "orphan_cards": [],
        "cards_no_scope": [],
        "cards_abs_path": [],
        "hot_behind_log": None,
        "index_missing": [],
        "index_dead_refs": [],
        "guard_stale": [],
        "guard_trend": [],
        "derived_stale": None,
        "raw_pending": 0,
        "addons": [],            # 已裝且不是最新的模組（addons.py）
        "addons_new": [],        # 沒裝、也沒 dismiss 的模組
    }

    if not s["has_wiki"]:
        return s

    s["raw_pending"] = _raw_pending(root, manifest)

    s["pages"], big = _count_pages(wiki)
    s["guard_stale"] = _guard_stale(root)
    s["guard_trend"] = _guard_status.trend_report(root) if _guard_status else []
    try:
        s["derived_stale"] = _derived.summarize(root)
    except Exception:      # noqa: BLE001 —— 開場量測不因單一檢查壞掉而整個掛
        s["derived_stale"] = None
    s["big_pages"] = [
        {"path": str(p.relative_to(root)).replace("\\", "/"), "kb": round(n / 1024)}
        for n, p in big if n > PAGE_WARN_KB * 1024
    ]

    log = wiki / "log.md"
    if log.is_file():
        s["log_kb"] = round(log.stat().st_size / 1024)

    hot = wiki / "hot.md"
    if hot.is_file():
        try:
            s["hot_lines"] = sum(1 for _ in hot.open(encoding="utf-8", errors="replace"))
        except OSError:
            pass

    cm = root / "CLAUDE.md"
    if cm.is_file():
        try:
            text = cm.read_text(encoding="utf-8", errors="replace")
            s["claude_lines"] = text.count("\n") + 1
            s["ruling_overflow"] = _ruling_overflow(text)
        except OSError:
            pass

    # 健檢時間：找任何叫 lint-report* 的檔，取最新
    reports = (list(wiki.rglob("doctor-report*")) + list(wiki.rglob("lint-report*"))
               + list(wiki.rglob("*lint*.md")))
    newest = _newest_mtime(reports)
    if newest:
        s["days_since_lint"] = (time.time() - newest) / DAY

    # 來源完整性：抽查 manifest 指向的檔還在不在
    repos_cfg = manifest.get("repos", {})
    srcs = manifest_sources(manifest)
    for key in list(srcs)[:400]:
        if "::" in key:
            alias, rel = key.split("::", 1)
            base = repos_cfg.get(alias, {}).get("path")
            if not base:
                s["broken_sources"].append(key)
                continue
            target = resolve_repo_path(root, base) / rel   # #27
        else:
            target = root / key
        if not target.exists():
            s["broken_sources"].append(key)

    here = _this_host()
    for alias in s["repos"]:
        cfg = repos_cfg.get(alias, {})
        p = cfg.get("path", "")
        if not p or resolve_repo_path(root, p).exists():   # #27
            continue
        # 🔴 掛載路徑是相對 vault 根的，而 manifest 是 tracked —— 共用 vault 之後，
        # 除了註冊者以外每個人每場都會看到「路徑失效」。那不是壞了，是別人機器上的（ISS-004）。
        owner_machine = (cfg.get("owner") or {}).get("machine") or ""
        if owner_machine and here and owner_machine != here:
            s["foreign_repos"].append((alias, owner_machine))
        else:
            s["broken_repos"].append(alias)                # 分不出是誰的 → 照舊報，不靜音

    # 🔴 #28 反向對帳：catalog 卡存在、manifest 卻沒有對應的 sources 條目。
    # broken_sources 抓的是 manifest → 檔案不見；這裡抓的是卡 → 沒有來源紀錄。
    # 後者更陰險：卡看起來在，但 scan 永遠不會說它過期 —— 死卡，會無聲腐爛。
    # （2026-09-21 踩到：AS9100 指標卡手寫進 catalog/ 卻漏了 ingest 的 Step 4。）
    cited = {v.get("catalog_page", "").replace("\\", "/") for v in srcs.values()}
    cat = root / "wiki" / "catalog"
    if cat.is_dir():
        for f in sorted(cat.glob("*.md")):
            rel = f.relative_to(root).as_posix()
            if rel not in cited:
                s["orphan_cards"].append(rel)
            try:
                head = f.read_text(encoding="utf-8", errors="replace")[:2000]
            except OSError:
                head = ""
            if not re.search(r"(?m)^scope:", head):
                s["cards_no_scope"].append(rel)
            if re.search(r'(?m)^(?:current_file|source_file|source_path|source_abs):[ \t]*"?(?:[A-Za-z]:[\\/]|/(?:Users|home|mnt|Volumes)/)', head):
                s["cards_abs_path"].append(rel)

    # 🔴 #30 index.md 雙向對帳。`wiki/repos.md` 由 repo.py 自動重建，但 `wiki/index.md`
    # 只靠 ingest Step 5 手動加，也沒有 maintenance 宣告 → tidy_check 不看它。
    # 兩種腐爛都實際發生過（2026-09-21）：建了卡忘了進目錄；alias 重掛後目錄裡的
    # source key 變死連結。目錄是給人讀的入口，錯了比沒有更糟。
    idx = root / "wiki" / "index.md"
    if idx.is_file():
        try:
            itext = idx.read_text(encoding="utf-8", errors="replace")
        except OSError:
            itext = ""
        if itext:
            for f in sorted((root / "wiki" / "catalog").glob("*.md"))                     if (root / "wiki" / "catalog").is_dir() else []:
                if f.stem not in itext:
                    s["index_missing"].append(f.relative_to(root).as_posix())
            for key in set(re.findall(r"`([^`\s]+::[^`]+)`", itext)):
                tgt = resolve_source(root, key)
                if tgt is None or not tgt.exists():
                    s["index_dead_refs"].append(key)

    s["hot_behind_log"] = _hot_behind_log(root)
    s["git_repo"], s["git_traces"] = _git_presence(root)
    try:
        import addons as _addons
        s["addons"] = [{**m, "hint": _addons.HINT[m["state"]]}
                       for m in _addons.statuses(root) if m["state"] != _addons.UP_TO_DATE]
        s["addons_new"] = [mid for mid, _ in _addons.undecided(root)]
    except Exception:      # noqa: BLE001 —— 同上
        s["addons"], s["addons_new"] = [], []
    return s


def _hot_behind_log(root: Path):
    """hot.md 的 mtime 日期 vs log.md 最後一條的日期。落後回 (hot_day, log_day)，否則 None。

    為什麼看日期不看天數：收尾協議是「這次做完就更新 hot」，隔一天才發現已經太晚 ——
    下個 session 開場讀 hot.md 會接到錯的地方。門檻放在「有沒有落後」，不是「落後幾天」。
    """
    hot = root / "wiki" / "hot.md"
    log = root / "wiki" / "log.md"
    if not hot.is_file() or not log.is_file():
        return None
    try:
        hot_day = time.strftime("%Y-%m-%d", time.localtime(hot.stat().st_mtime))
        text = log.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    days = re.findall(r"^##\s+(20\d{2}-\d{2}-\d{2})", text, flags=re.M)
    if not days:
        return None
    last = max(days)
    return (hot_day, last) if last > hot_day else None


def tier_of(s):
    if not s["has_wiki"]:
        return "absent"
    if s["pages"] < SEED_MAX:
        return "seed"
    if s["pages"] < GROWING_MAX:
        return "growing"
    return "mature"


def critical_flags(s):
    """紅燈：會讓資料無法還原的狀況，排在老化訊號前面、開場一定講。"""
    f = []
    if s.get("git_repo") is False and s.get("git_traces"):
        f.append(("vault 不是 git repo", f"根目錄沒有 .git，但有用過 git 的痕跡（{'、'.join(s['git_traces'])}）"
                  " — .git 可能被刪或沒還原；先查資源回收筒／備份還原，還原前不要寫入 vault（沒有退路）"))
    return f


def aging_flags(s):
    """老化訊號。與 tier 無關，任何成熟度都可能出現。"""
    f = []
    if s.get("git_repo") is False and not s.get("git_traces") and tier_of(s) == "mature":
        f.append(("沒有版本控制", "成熟 vault 卻沒有 .git — 建議 git init，改壞了才有退路"))
    if s["log_kb"] > LOG_WARN_KB:
        f.append(("log 過大", f"wiki/log.md {s['log_kb']}KB — 已無法整份讀，查詢改用 Grep 帶關鍵字"))
    for bp in s["big_pages"]:
        if bp["path"].endswith("wiki/log.md") and s["log_kb"] > LOG_WARN_KB:
            continue  # 已由上一條報過
        f.append(("單頁過大", f"{bp['path']} {bp['kb']}KB — 考慮拆頁"))
    if s["hot_lines"] and s["hot_lines"] > HOT_WARN_LINES:
        f.append(("hot 沒輪替", f"wiki/hot.md {s['hot_lines']} 行（上限 {HOT_WARN_LINES}）— 該修剪"))
    if s["claude_lines"] and s["claude_lines"] > CLAUDE_WARN_LINES:
        f.append(("CLAUDE.md 過大", f"{s['claude_lines']} 行（上限 {CLAUDE_WARN_LINES}）— 每 session 都載入；把按需規則拆到 wiki/ops/，本檔留指標"))
    for sec, n in s["ruling_overflow"]:
        f.append((f"{sec} 區溢出", f"CLAUDE.md 該區 {n} 條（上限 {RULING_MAX}）— 最舊的搬到 wiki/ops/rulings.md，本區只留一句話"))
    if s["days_since_lint"] is None and s["pages"] >= SEED_MAX:
        f.append(("從未健檢", f"{s['pages']} 頁但找不到健檢紀錄 — 跑 /wiki-doctor 並存 doctor-report"))
    elif s["days_since_lint"] and s["days_since_lint"] > LINT_STALE_DAYS:
        f.append(("健檢過期", f"上次健檢在 {int(s['days_since_lint'])} 天前 — 跑 /wiki-doctor"))
    if s["index_missing"]:
        n = len(s["index_missing"])
        head = "、".join(Path(c).stem for c in s["index_missing"][:3])
        f.append(("目錄漏卡",
                  f"{n} 張 catalog 卡沒出現在 wiki/index.md（{head}{'…' if n > 3 else ''}）"
                  f" — 目錄是入口，漏了等於查不到"))
    if s["index_dead_refs"]:
        n = len(s["index_dead_refs"])
        f.append(("目錄死連結",
                  f"wiki/index.md 有 {n} 個 source key 解析不開"
                  f"（{s['index_dead_refs'][0]}{'…' if n > 1 else ''}）"
                  f" — alias 多半被 remove 或改名過，跑 /wiki-repo rename"))
    if s.get("derived_stale"):
        f.append(("綜合頁過期", s["derived_stale"]))
    for m in s.get("addons", []):
        f.append((f"模組：{m['state']}", f"{m['id']}（vault {m.get('installed') or '?'}／plugin {m['latest']}）— {m['hint']}"))
    if s.get("addons_new"):
        f.append(("有新模組可裝", f"{'、'.join(s['addons_new'])} — 跑 addons.py 看說明；要裝 install，不要 dismiss（之後不再提醒）"))
    if s.get("hot_behind_log"):
        hot_day, log_day = s["hot_behind_log"]
        f.append(("收尾沒跑",
                  f"wiki/hot.md 停在 {hot_day}，log 已有 {log_day} 的條目"
                  " — hot.md 是每 session 第一份讀的檔，落後就會接錯地方；"
                  "把最近操作與待確認寫進 hot.md「目前狀態」，舊的移進 log"))
    if s["cards_abs_path"]:
        n = len(s["cards_abs_path"])
        head = "、".join(Path(c).stem for c in s["cards_abs_path"][:3])
        f.append(("卡有絕對路徑",
                  f"{n} 張卡的 current_file／source_file 是 C:/Users… 這種絕對路徑（{head}{'…' if n > 3 else ''}）"
                  " — 換機器就開不到正本；跑 repo.py fixpaths 改成 alias::rel"))
    if s["cards_no_scope"]:
        n = len(s["cards_no_scope"])
        head = "、".join(Path(c).stem for c in s["cards_no_scope"][:3])
        f.append(("卡無 scope",
                  f"{n} 張 catalog 卡沒有 frontmatter `scope:`（{head}{'…' if n > 3 else ''}）"
                  " — 查詢無法判斷它屬於哪個對象，會被撈進任何問題；跑 repo.py scope 回填"))
    if s["orphan_cards"]:
        n = len(s["orphan_cards"])
        head = "、".join(Path(c).stem for c in s["orphan_cards"][:3])
        f.append(("孤兒卡",
                  f"{n} 張 catalog 卡沒有 manifest 紀錄（{head}{'…' if n > 3 else ''}）"
                  f" — scan 追不到它們過期，補 sources 條目或刪卡"))
    if s["broken_repos"]:
        f.append(("repo 路徑失效", f"{', '.join(s['broken_repos'])} — 跑 /wiki-repo scan"))
    n = len(s["broken_sources"])
    if n:
        f.append(("來源檔消失", f"{n} 筆 manifest 紀錄指向不存在的檔 — 跑 /wiki-repo scan"))
    for t in s.get("guard_trend", []):
        f.append(("守門結果變差", t))
    for h in s["guard_stale"]:
        if "從未留痕" in h and s["pages"] < SEED_MAX:
            continue  # 新生 vault 還沒東西可守，與「從未健檢」同一門檻
        f.append(("守門失聯", f"{h} — 沒有東西驗證守門還在跑，它就會靜靜死掉"))
    return f


GUIDANCE = {
    "absent": [
        "**這個資料夾還不是 wiki vault。** 第一次用的話照這三步：",
        "",
        "1. `/wiki-init` —— 會問你三題（管什麼對象／`raw/` 怎麼分／有沒有制度或散在別處的專案），然後產出骨架",
        "2. 把第一份文件丟進 `raw/`，跑 `/wiki-ingest raw/`",
        "3. 之後任何時候不知道下一步 → `/wiki-coach`（它看你的 vault 現況，只講一件該做的事）",
        "",
        "檔案在別的資料夾、不想搬 → `/wiki-repo add <路徑>`，檔案留原地只記指標。",
    ],
    "seed": [
        "**新生 vault** — 以下是這套系統的運作方式（vault 長大後這段會自動消失）：",
        "",
        "- `raw/` 放原始檔（你維護），`wiki/` 放 Claude 編譯出的知識（Claude 維護）",
        "- 鐵律：**wiki 只存指標，不抄會變動的內容** — 抄了就會過期，變成「看起來有、其實錯」的垃圾",
        "- 每個 wiki 頁必須標來源，非資料庫的資訊必須標 `[⚠️ 非資料庫：...]`",
        "- 檔案不必搬進來：`/wiki-repo add <路徑>` 可以把散在各處的專案掛進同一個 wiki",
    ],
    "growing": [
        "**成長中 vault** — 這個階段最容易累積的問題是「重複與孤島」。",
        "建議：`/wiki-doctor` 找出老化訊號與孤立頁；用 `/wiki-query` 查詢而不是自己翻檔案。",
    ],
    "mature": [],  # 成熟 vault 不解說，只在有老化訊號時出聲
}


def next_action(s, tier):
    """開場那句「現在最值得做的」。看實際狀態，不是固定字串。"""
    if tier not in ("seed", "growing"):
        return None
    n = s["raw_pending"]
    if n:
        return f"現在最值得做的：`/wiki-ingest raw/` 把 {n} 份還沒編的素材編一次，看它長什麼樣。"
    if not s["sources"]:
        return ("現在最值得做的：把第一份文件丟進 `raw/`，再 `/wiki-ingest raw/`；"
                "檔案在別的資料夾就用 `/wiki-repo add <路徑>`。")
    if not s["repos"]:
        return ("`raw/` 都編完了。下一步：`/wiki-query <問題>` 試查一次，"
                "或 `/wiki-repo discover <上層資料夾>` 把別處的專案掛進來。")
    return "`raw/` 都編完了。下一步：`/wiki-query <問題>` 試查，或 `/wiki-repo scan` 看外部 repo 有無變更。"


COACH_MODES = ("auto", "on", "off")


def coach_mode(root):
    """教練模式：auto（依成熟度）／on（每次開場都講）／off（開場不講，只報老化訊號）。

    兩個來源，個人設定優先於 vault 設定：
      1. 環境變數 LLM_WIKI_COACH —— 個人偏好，用 settings.json 的 `env` 設，跟著人走
      2. manifest `config.coach` —— vault 預設，跟著 repo 走，同事 clone 下來也是這個
    """
    env = os.environ.get("LLM_WIKI_COACH", "").strip().lower()
    if env in COACH_MODES:
        return env
    if not root:
        return "auto"
    m = load_manifest(Path(root)).get("config", {}).get("coach", "auto")
    return m if m in COACH_MODES else "auto"


def _coach_top(root):
    """on 模式：開場附上 coach 最優先的一項。延遲 import，coach 反向依賴本模組。"""
    try:
        import coach
        _, fs = coach.findings(Path(root))
        return coach.render_one(fs[0]) if fs else coach.green_for(tier_of(collect(Path(root))), Path(root))
    except Exception:  # noqa: BLE001 — 開場 hook 不能因 coach 壞掉而掛
        return None


def render(s, brief=False):
    tier = tier_of(s)
    flags = aging_flags(s)
    out = []

    if brief:
        # SessionStart 注入：沒事就安靜，有事才講
        if tier == "absent":
            return ""  # 不是 vault，完全不打擾
        head = f"[llm-wiki] {tier} · {s['pages']} 頁 · {s['sources']} 筆來源"
        if s["repos"]:
            head += f" · {len(s['repos'])} 個外部 repo"
        mode = coach_mode(s["root"])
        if mode != "auto":
            head += f" · coach {mode}"
        out.append(head)
        if mode == "on":
            top = _coach_top(s["root"])
            if top:
                out += ["", "🧭 教練：", top]
        elif mode == "auto" and tier in ("seed", "growing"):
            out += ["", *GUIDANCE[tier]]
            act = next_action(s, tier)
            if act:
                out += ["", act]
        crit = critical_flags(s)
        if crit:
            out.append("")
            out.append(f"🔴 紅燈 {len(crit)} 項（先處理）：")
            out += [f"  - {k}：{v}" for k, v in crit]
        if flags:
            out.append("")
            out.append(f"⚠️ 老化訊號 {len(flags)} 項（開場提一句，不必當場處理）：")
            out += [f"  - {k}：{v}" for k, v in flags[:5]]
        return "\n".join(out)

    out.append(f"Vault：{s['root']}")
    out.append(f"成熟度：{tier}　頁數：{s['pages']}　來源：{s['sources']}"
               f"　raw/ 待編：{s['raw_pending']}")
    if s["repos"]:
        foreign = dict(s["foreign_repos"])
        names = [f"{a}（{foreign[a]} 上，本機沒有）" if a in foreign else a for a in s["repos"]]
        out.append(f"外部 repo：{', '.join(names)}")
    if s["days_since_commit"] is not None:
        out.append(f"最後 commit：{int(s['days_since_commit'])} 天前")
    mode = coach_mode(s["root"])
    if mode != "auto":
        out.append(f"教練模式：{mode}（改：/wiki-coach auto|on|off）")
    elif tier in ("seed", "growing"):
        out.append(f"（{tier} 階段的操作指導只在 session 開場印；要看：/wiki-coach。長開／長關：/wiki-coach on|off）")
    out.append("")
    crit = critical_flags(s)
    if crit:
        out.append(f"🔴 紅燈 {len(crit)} 項（先處理）：")
        out += [f"  - {k}：{v}" for k, v in crit]
        out.append("")
    if flags:
        out.append(f"🟡 老化訊號 {len(flags)} 項：")
        out += [f"  - {k}：{v}" for k, v in flags]
    else:
        out.append("🟢 無老化訊號")
    return "\n".join(out)


def main():
    args = sys.argv[1:]
    start = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
    root = find_vault_root(Path(start))
    if root is None:
        # --brief 是 SessionStart hook 在跑：非 vault 目錄一律靜默，不吵人。
        # 其他情況（使用者自己跑 /wiki）要給指導 —— 只印「找不到」等於把新手丟在原地。
        if "--json" in args:
            print(json.dumps({"has_wiki": False, "root": None, "tier": "absent"}, ensure_ascii=False))
        elif "--brief" not in args:
            print("找不到 vault（往上找不到含 wiki/ 或 raw/.manifest.json 的目錄）")
            print()
            print("\n".join(GUIDANCE["absent"]))
        return 0

    s = collect(root)
    if "--json" in args:
        s["tier"] = tier_of(s)
        s["critical"] = [{"kind": k, "detail": v} for k, v in critical_flags(s)]
        s["aging"] = [{"kind": k, "detail": v} for k, v in aging_flags(s)]
        print(json.dumps(s, ensure_ascii=False, indent=2))
    else:
        text = render(s, brief="--brief" in args)
        if text:
            print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
